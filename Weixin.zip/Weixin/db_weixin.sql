/*
Navicat MySQL Data Transfer

Source Server         : Local
Source Server Version : 50620
Source Host           : localhost:3306
Source Database       : db_weixin

Target Server Type    : MYSQL
Target Server Version : 50620
File Encoding         : 65001

Date: 2016-09-03 10:13:43
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `app2_admin`
-- ----------------------------
DROP TABLE IF EXISTS `app2_admin`;
CREATE TABLE `app2_admin` (
  `userid` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `roleid` smallint(5) DEFAULT '0',
  `encrypt` varchar(6) DEFAULT NULL,
  `lastloginip` varchar(15) DEFAULT NULL,
  `lastlogintime` int(10) unsigned DEFAULT '0',
  `email` varchar(40) DEFAULT NULL,
  `realname` varchar(50) NOT NULL DEFAULT '',
  `isdelete` int(11) NOT NULL DEFAULT '0',
  `inserttime` int(11) NOT NULL DEFAULT '0',
  `updatetime` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_admin
-- ----------------------------
INSERT INTO `app2_admin` VALUES ('1', 'admin', '9b929c59088ae4210ca451d0dd8f1d1a', '1', 'xqtTWi', '119.251.34.10', '1472782942', 'admin@admin.com', 'admin', '0', '0', '0');

-- ----------------------------
-- Table structure for `app2_admin_log`
-- ----------------------------
DROP TABLE IF EXISTS `app2_admin_log`;
CREATE TABLE `app2_admin_log` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL,
  `httpuseragent` text NOT NULL,
  `sessionid` varchar(30) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` varchar(30) NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=353 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for `app2_admin_role`
-- ----------------------------
DROP TABLE IF EXISTS `app2_admin_role`;
CREATE TABLE `app2_admin_role` (
  `roleid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `rolename` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleid`),
  KEY `listorder` (`listorder`),
  KEY `disabled` (`disabled`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_admin_role
-- ----------------------------
INSERT INTO `app2_admin_role` VALUES ('1', '总管理员', '总管理员', '0', '0');

-- ----------------------------
-- Table structure for `app2_admin_role_priv`
-- ----------------------------
DROP TABLE IF EXISTS `app2_admin_role_priv`;
CREATE TABLE `app2_admin_role_priv` (
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `c` varchar(20) NOT NULL,
  `a` varchar(20) NOT NULL,
  PRIMARY KEY (`roleid`),
  KEY `roleid` (`roleid`,`c`,`a`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_admin_role_priv
-- ----------------------------

-- ----------------------------
-- Table structure for `app2_log`
-- ----------------------------
DROP TABLE IF EXISTS `app2_log`;
CREATE TABLE `app2_log` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `controller` varchar(15) NOT NULL,
  `action` varchar(20) NOT NULL,
  `querystring` mediumtext NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`logid`),
  KEY `module` (`controller`,`action`),
  KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_log
-- ----------------------------

-- ----------------------------
-- Table structure for `app2_menu`
-- ----------------------------
DROP TABLE IF EXISTS `app2_menu`;
CREATE TABLE `app2_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `c` varchar(20) NOT NULL DEFAULT '',
  `a` varchar(20) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  `display` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `parentid` (`parentid`),
  KEY `module` (`c`,`a`)
) ENGINE=MyISAM AUTO_INCREMENT=218 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_menu
-- ----------------------------
INSERT INTO `app2_menu` VALUES ('200', '系统管理', '0', 'System', 'top', '', '200', '1');
INSERT INTO `app2_menu` VALUES ('201', '管理员管理', '200', 'Admin', 'top', '', '201', '1');
INSERT INTO `app2_menu` VALUES ('202', '管理员列表', '201', 'Admin', 'memberList', '', '202', '1');
INSERT INTO `app2_menu` VALUES ('203', '系统菜单', '200', 'System', 'menuList', '', '203', '1');
INSERT INTO `app2_menu` VALUES ('205', '微信设置', '200', 'Weixin', 'wxconnect', '', '205', '1');
INSERT INTO `app2_menu` VALUES ('204', '系统菜单', '203', 'System', 'menuList', '', '204', '1');
INSERT INTO `app2_menu` VALUES ('206', '微信接口', '205', 'Weixin', 'wxconnect', '', '206', '1');
INSERT INTO `app2_menu` VALUES ('207', '自定义菜单', '205', 'Weixin', 'wxmenu', '', '207', '1');

-- ----------------------------
-- Table structure for `app2_system_setting`
-- ----------------------------
DROP TABLE IF EXISTS `app2_system_setting`;
CREATE TABLE `app2_system_setting` (
  `ssid` int(11) NOT NULL AUTO_INCREMENT,
  `ss_key` varchar(50) NOT NULL,
  `ss_value` varchar(5192) DEFAULT '',
  PRIMARY KEY (`ssid`)
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_system_setting
-- ----------------------------
INSERT INTO `app2_system_setting` VALUES ('1', 'wx_app_id', 'wx354654675675673534');
INSERT INTO `app2_system_setting` VALUES ('2', 'wx_app_secret', 'a878c0fedca42348747d9892323');
INSERT INTO `app2_system_setting` VALUES ('3', 'wx_app_token', 'wexin');
INSERT INTO `app2_system_setting` VALUES ('4', 'wx_app_encoding_key', 'FRtsffvvxds90dsfMALKDP5654654cqpkvke');
INSERT INTO `app2_system_setting` VALUES ('5', 'wx_app_mchid', '5464523423');
INSERT INTO `app2_system_setting` VALUES ('6', 'wx_app_paysignkey', 'yanjiaozaixian123456789yuyingjs1');

-- ----------------------------
-- Table structure for `app2_wxcontent`
-- ----------------------------
DROP TABLE IF EXISTS `app2_wxcontent`;
CREATE TABLE `app2_wxcontent` (
  `wxcid` int(11) NOT NULL AUTO_INCREMENT,
  `wcname` varchar(50) NOT NULL,
  `createtime` int(11) NOT NULL,
  `isdelete` int(11) NOT NULL,
  PRIMARY KEY (`wxcid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_wxcontent
-- ----------------------------

-- ----------------------------
-- Table structure for `app2_wxcontent_detail`
-- ----------------------------
DROP TABLE IF EXISTS `app2_wxcontent_detail`;
CREATE TABLE `app2_wxcontent_detail` (
  `wxcdid` int(11) NOT NULL AUTO_INCREMENT,
  `text` text,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `picurl` varchar(255) DEFAULT NULL,
  `contenturl` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `readcount` int(11) DEFAULT '0',
  `createtime` int(11) DEFAULT NULL,
  `isdelete` int(11) DEFAULT '0',
  PRIMARY KEY (`wxcdid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_wxcontent_detail
-- ----------------------------
INSERT INTO `app2_wxcontent_detail` VALUES ('1', null, '测试01', '测试01用图文', '/Public/upload/weixin/images/large/56b6dd08cfed6.png', '/Public/upload/weixin/html/getcontent.php?content=wxcontent_20151119-180031.html', '/Public/upload/weixin/html/getcontent.php?content=wxcontent_20151119-180031.html', '0', '1447927237', '1');
INSERT INTO `app2_wxcontent_detail` VALUES ('2', null, '燕郊在线苹果手机版本上线', '恭喜燕郊在线苹果手机版本上线', '/Public/upload/weixin/images/large/56b6dd08cfed6.png', '/Public/upload/weixin/html/getcontent.php?content=wxcontent_2.html', '', '0', '1447929656', '0');
INSERT INTO `app2_wxcontent_detail` VALUES ('3', null, '燕郊在线安卓手机版本上线', '恭喜燕郊在线安卓手机版本上线', '/Public/upload/weixin/images/large/56b6dd08cfed6.png', '/Public/upload/weixin/html/getcontent.php?content=wxcontent_3.html', '', '0', '1447929656', '0');
INSERT INTO `app2_wxcontent_detail` VALUES ('4', null, '关注回复', '欢迎您关注燕郊在线', '/Public/upload/weixin/images/large/56b6d4c71b441.png', '/Public/upload/weixin/html/getcontent.php?content=wxcontent_4.html', '', '0', '1447929656', '0');

-- ----------------------------
-- Table structure for `app2_wxcontent_relation`
-- ----------------------------
DROP TABLE IF EXISTS `app2_wxcontent_relation`;
CREATE TABLE `app2_wxcontent_relation` (
  `wxcrid` int(11) NOT NULL AUTO_INCREMENT,
  `wxcid` int(11) DEFAULT NULL,
  `wxcdid` int(11) DEFAULT NULL,
  PRIMARY KEY (`wxcrid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_wxcontent_relation
-- ----------------------------

-- ----------------------------
-- Table structure for `app2_wxfunction`
-- ----------------------------
DROP TABLE IF EXISTS `app2_wxfunction`;
CREATE TABLE `app2_wxfunction` (
  `wxfuncid` int(11) NOT NULL AUTO_INCREMENT,
  `functype` int(11) NOT NULL,
  `keyword` varchar(50) NOT NULL,
  `appfuncid` int(11) NOT NULL DEFAULT '0',
  `wxcid` int(11) NOT NULL DEFAULT '0',
  `wxcdid` int(11) NOT NULL DEFAULT '0',
  `lwid` int(11) NOT NULL DEFAULT '0',
  `cp_id` int(11) NOT NULL DEFAULT '0',
  `wzid` int(11) NOT NULL DEFAULT '0',
  `createtime` int(11) NOT NULL,
  `isdelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wxfuncid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_wxfunction
-- ----------------------------
INSERT INTO `app2_wxfunction` VALUES ('1', '0', '燕郊动态', '4', '0', '0', '0', '0', '0', '1449913869', '0');
INSERT INTO `app2_wxfunction` VALUES ('2', '0', '闪送超市', '2', '0', '0', '0', '0', '0', '1449913787', '0');
INSERT INTO `app2_wxfunction` VALUES ('3', '0', '今日特惠', '3', '0', '0', '0', '0', '0', '1449913749', '0');
INSERT INTO `app2_wxfunction` VALUES ('4', '1', '微信', '0', '0', '1', '0', '0', '0', '1449913531', '1');
INSERT INTO `app2_wxfunction` VALUES ('5', '1', '苹果', '0', '0', '2', '0', '0', '0', '1449913519', '0');
INSERT INTO `app2_wxfunction` VALUES ('6', '1', '安卓', '0', '0', '3', '0', '0', '0', '1449913493', '0');
INSERT INTO `app2_wxfunction` VALUES ('7', '2', '关注', '0', '0', '4', '0', '0', '0', '1451545796', '1');
INSERT INTO `app2_wxfunction` VALUES ('8', '3', '大转盘01', '0', '0', '0', '3', '0', '0', '1453527082', '0');
INSERT INTO `app2_wxfunction` VALUES ('9', '3', '幸运大转盘', '0', '0', '0', '1', '0', '0', '1449913910', '0');
INSERT INTO `app2_wxfunction` VALUES ('10', '4', '优惠券', '0', '0', '0', '0', '3', '0', '1454824101', '0');
INSERT INTO `app2_wxfunction` VALUES ('11', '4', '代金券', '0', '0', '0', '0', '9', '0', '1453532106', '1');
INSERT INTO `app2_wxfunction` VALUES ('12', '5', '分享助力', '0', '0', '0', '0', '0', '1', '1449913992', '0');
INSERT INTO `app2_wxfunction` VALUES ('13', '5', '微助力', '0', '0', '0', '0', '0', '2', '1449914018', '0');
INSERT INTO `app2_wxfunction` VALUES ('14', '0', '首页', '1', '0', '0', '0', '0', '0', '1449913815', '0');
INSERT INTO `app2_wxfunction` VALUES ('15', '0', '登陆', '12', '0', '0', '0', '0', '0', '1453538415', '0');
INSERT INTO `app2_wxfunction` VALUES ('16', '2', '关注回复', '0', '0', '4', '0', '0', '0', '1454080682', '1');
INSERT INTO `app2_wxfunction` VALUES ('17', '2', '关注', '0', '0', '4', '0', '0', '0', '1454083576', '1');

-- ----------------------------
-- Table structure for `app2_wxmenu`
-- ----------------------------
DROP TABLE IF EXISTS `app2_wxmenu`;
CREATE TABLE `app2_wxmenu` (
  `wxmid` int(11) NOT NULL AUTO_INCREMENT,
  `mainindex` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `keyword` varchar(50) DEFAULT NULL,
  `app` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`wxmid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_wxmenu
-- ----------------------------
INSERT INTO `app2_wxmenu` VALUES ('1', '0', '0', 'NONE', '一级菜单：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('2', '0', '1', 'NONE', '二级菜单  1：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('3', '0', '2', 'NONE', '二级菜单  2：', '', '', '', '3');
INSERT INTO `app2_wxmenu` VALUES ('4', '0', '3', 'NONE', '二级菜单  3：', '', '', '', '2');
INSERT INTO `app2_wxmenu` VALUES ('5', '0', '4', 'NONE', '二级菜单  4：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('6', '0', '5', 'NONE', '二级菜单  5：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('7', '1', '0', 'NONE', '一级菜单：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('8', '1', '1', 'NONE', '二级菜单  1：', '', '', '', '4');
INSERT INTO `app2_wxmenu` VALUES ('9', '1', '2', 'NONE', '二级菜单  2：', '', '', '', '5');
INSERT INTO `app2_wxmenu` VALUES ('10', '1', '3', 'NONE', '二级菜单  3：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('11', '1', '4', 'NONE', '二级菜单  4：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('12', '1', '5', 'NONE', '二级菜单  5：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('13', '2', '0', 'NONE', '一级菜单：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('14', '2', '1', 'NONE', '二级菜单  1：', '', '', '', '7');
INSERT INTO `app2_wxmenu` VALUES ('15', '2', '2', 'NONE', '二级菜单  2：', '', '', '', '8');
INSERT INTO `app2_wxmenu` VALUES ('16', '2', '3', 'NONE', '二级菜单  3：', '', '', '', '6');
INSERT INTO `app2_wxmenu` VALUES ('17', '2', '4', 'NONE', '二级菜单  4：', '', '', '', '1');
INSERT INTO `app2_wxmenu` VALUES ('18', '2', '5', 'NONE', '二级菜单  5：', '', '', '', '1');

-- ----------------------------
-- Table structure for `app2_wxmessage`
-- ----------------------------
DROP TABLE IF EXISTS `app2_wxmessage`;
CREATE TABLE `app2_wxmessage` (
  `wxmsgid` int(11) NOT NULL AUTO_INCREMENT,
  `msgname` varchar(50) NOT NULL,
  `wxcdid` int(11) DEFAULT NULL,
  `createtime` int(11) DEFAULT NULL,
  `isdelete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wxmsgid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of app2_wxmessage
-- ----------------------------
INSERT INTO `app2_wxmessage` VALUES ('1', '新版本来了', '2', '1454824837', '0');
