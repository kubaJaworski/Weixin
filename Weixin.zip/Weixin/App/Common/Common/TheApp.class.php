<?php
namespace Common\Common;
use Think\Crypt\Driver\YCrypt;
//use Common\Common\TheWeixin;
use Common\Model\OrderModel;
use Common\Model\SystemSettingModel;
use Think\Log;

class TheApp  {
    
    // 免费咨询
    const FUNCID_MIANFEIQUESTION  = 1;    
    // 付费咨询
    const FUNCID_FUFEIQUESTION    = 2;
    // 付费电话
    const FUNCID_FUFEIDIANHUA     = 3;
    // 案件委托
    const FUNCID_ANJIANWEITUO    = 4;
    // 律师列表
    const FUNCID_LVSHILIEBIAO    = 5;
    // 个人中心
    const FUNCID_WODEZHONGXIN    = 6;    
    // 律师登陆
    const FUNCID_LVSHIDENGLV     = 7;    
    // 我的咨询
    const FUNCID_WODEZIXUN      = 8;
    const DEFAULT_FUNCNAME = '未知功能';
    
    ////////////////////////////////////////////////////////////////////////////

    public static function GetAppFuncList()
    {
        $list = array();        
        $list[] = array('id'=>1, 'funcname'=>"免费咨询");
        $list[] = array('id'=>2, 'funcname'=>"付费咨询");
        $list[] = array('id'=>3, 'funcname'=>"付费电话");
        $list[] = array('id'=>4, 'funcname'=>"案件委托");
        $list[] = array('id'=>5, 'funcname'=>"律师列表");
        $list[] = array('id'=>6, 'funcname'=>"个人中心");
        $list[] = array('id'=>7, 'funcname'=>"律师登陆");
        $list[] = array('id'=>8, 'funcname'=>"我的咨询");
       
        //$list[] = array('id'=>self::DEFAULT_FUNCID, 'funcname'=>self::DEFAULT_FUNCNAME);
        return $list;
    }
    
    public static function GetAppFuncName($vFuncId)
    {
        $list = self::GetAppFuncList();
        
        foreach( $list as $func)
        {
            if( $func['id'] == $vFuncId )
                return $func['funcname'];
        }
        
        return self::DEFAULT_FUNCNAME ;
    }
    
    public static function GetFuncWeixinURL( $appfuncid )
    {
        $resultUrl = "Home/User/mianfeiwen";
        switch($appfuncid)
        {
            case self::FUNCID_MIANFEIQUESTION:
                $resultUrl = "Home/User/mianfeiwen";
                break;
            case self::FUNCID_FUFEIQUESTION:
                $resultUrl = "Home/User/fufeiwen";
                break;
            case self::FUNCID_FUFEIDIANHUA:
                $resultUrl = "Home/User/dianhuawen";
                break;
            case self::FUNCID_ANJIANWEITUO:
                $resultUrl = "Home/User/anjianweituo";
                break;
            case self::FUNCID_LVSHILIEBIAO:
                $resultUrl = "Home/User/zhaolvshi";
                break;
            case self::FUNCID_WODEZHONGXIN:
                $resultUrl = "Home/User/gerenzhongxin";
                break;
            case self::FUNCID_LVSHIDENGLV:
                $resultUrl = "Home/Lawyer/lvshirukou";
                break;
            case self::FUNCID_WODEZIXUN:
                $resultUrl = "Home/User/wxwodezixun";
                break;
            
            default:
                break;
        }
        
        return $resultUrl;
    }
    
    public static function GetWeixinResponse($theWeixin, $appfuncid, $fromUserName, $toUserName, $eventKey, $event, $msgType, $content)
    {
        $title          = '110法律微信在线';
        $description    = '欢迎您110法律微信在线微信平台';
        
        $rooturl        = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $picurl         = $rooturl . '/Public/static/img/default_banner.png';
        //$url            = $rooturl . U( TheApp::GetFuncWeixinURL($appfuncid) ) . '?client=wx&openid=' . $fromUserName ;
        
        $setting_db = D('Common/SystemSetting');
        $wx_app_id = $setting_db->GetSettingValue('wx_app_id', '');
            
        $appUrl = $rooturl . U( 'Home/wechat/appBind' ) . '?funcid='. $appfuncid;
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" 
                            . $wx_app_id 
                            . "&redirect_uri=" 
                            . $appUrl
                            . "&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
        
        $responseString = $theWeixin->weChat->transmitToNews($text, $title, $description, $picurl,  $url, $toUserName, $fromUserName);
        return $responseString;
    }
    
    public static function CreateQRCode($imagePath, $encURL, $level='L', $size=6 )
    {
        try {
            vendor("phpqrcode.phpqrcode");
            $data = $encURL; 
            $filename = $imagePath; 
            
            // contents check
            if(file_exist($filename))
                return 1;
            
            \QRcode::png($data, $filename, $level, $size);
            
            return 1;
        } catch (Exception $ex) {            
        }
        return 0;
    }
    
    public static function SendPostRequest($url, $data = '')
    {        
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $fullurl = $rooturl . $url;
                
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $fullurl);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        if($data != '')
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        if(curl_errno($ch))
        {
            return '';
        }
        return $result;
    }
    
    public static function updateQuestion($q_id, $status) {
        $db_question = D('Common/Order');
        return $db_question->updateQuestion($q_id, $status);
    }
    
    public static function processPayment($question) {
        $db_pay = D('Common/Transaction');
        return $db_pay->savePayment($question);
    }

    public static function getCategory() {
        $db_categories = D('Common/Category');
        
        $category_list = array('main'=>$db_categories->getMainCategory(), 'sub'=>array());
        foreach ($category_list['main'] as &$item) {
            $sub = $db_categories->getSubCategory($item['c_id']);
            $sub_category = array();
            foreach ($sub as $id=>&$item_sub) {
//                $item_sub['sc_id'] = $id + 1;
                $sub_category[] = $item_sub;
            }
            $category_list['sub'][] = $sub_category;
        } 
        
        return $category_list;        
    }

    public static function getAllCategory() {
        $db_categories = D('Common/Category');
        
        $category_list = $db_categories->getMainCategory();
        foreach ($category_list as &$category) {
            $category['sub'] = $db_categories->getSubCategory($category['c_id']);
        } 
        
        return $category_list;        
    }
    
    public static function getAddress() {
        $db_address = D('Common/Address');
        
        $address = array('province'=>$db_address->getProvinces(), 'city'=>array());
        foreach($address['province'] as &$province) {
            $sub_cities = $db_address->getCities($province['provinceid']);
            $cities = array();
            foreach ($sub_cities as $id=>&$city) {
//                $city['cityid'] = $id + 1;
                $cities[] = $city;
            }
            $address['city'][] = $cities;
        } 
        
        return $address;        
    }
    
    public static function sendWeixinMessage($q_id, $dir, $cat) {
        $db_question = D('Common/Order');
        $db_lawyer = D('Common/Lawyer');
        $db_wxfan = D('Common/WxFan');
        
        $question = $db_question->where(array('q_isdelete'=>0,'q_id'=>$q_id))->find();
        $lawyer = $db_lawyer->where(array('l_isdelete'=>0,'l_id'=>$question['q_lid']))->find();
        $lawyer_wxfan = $db_wxfan->where(array('isdelete'=>0,'w_lawyerid'=>$lawyer['l_id']))->find();
        $wxfan = $db_wxfan->where(array('isdelete'=>0,'w_wxfanid'=>$question['q_wxfanid']))->find();
        
        $theWeixin = TheWeixin::CreateObject();
        $theApp = new TheApp();
        if ($dir) { 
            $message = $theApp->createLawyerMessage($q_id, $cat); 
            $theWeixin->sendMessage($lawyer_wxfan, $message);            
        }
        else {
            $message = $theApp->createWxfanMessage($q_id, $cat); 
            $theWeixin->sendMessage($wxfan, $message);
        }        
    }
    
    public function createLawyerMessage($q_id, $cat) {
        $db_question = D('Common/Order');
        $db_wxfan = D('Common/WxFan');
        
        $question = $db_question->where(array('q_isdelete'=>0,'q_id'=>$q_id))->find();
        $wxfan = $db_wxfan->where(array('isdelete'=>0,'w_wxfanid'=>$question['q_wxfanid']))->find();
        $setting['count_remind_time'] = D('Common/SystemSetting')->GetSettingValue(SystemSettingModel::KEY_FOLLOW_REMIND_TIME);
        
        $title = '';
        switch($cat) {
            case 1:
                $title = '抢单成功，请尽快回复';
                break;
            case 2:
                $title = '用户有新的追问，请尽快回复';
                break;
            case 3:
                $title = '请尽快回复，'.$setting['count_remind_time'].'分钟后咨询将重回抢答区';
                break;
            case 4:
                $title = '超时，咨询已重回抢答区';
                break;
            case 5:
                $title = '用户已评价';
                break;
            case 6:
                $title = '用户已申诉';
                break;
            case 7:
                $title = '您有私问，请尽快回复';
                break;
            case 8:
                $title = '用户已选择您接洽案件';
                break;
            case 9:
                $title = '用户发起“结束咨询”请求，请尽快处理';
                break;
            case 10:
                $title = '问题已关闭';
                break;
            case 11:
                $title = '用户发起“关闭委托”请求，请尽快处理';
                break;
            case 12:
                $title = '委托已关闭';
                break;
            case 13:
                $title = '用户发起“达成委托”请求，请尽快处理';
                break;
            case 14:
                $title = '委托已达成';
                break;
            case 15:
                $title = '申诉期已过，您的咨询费已入账';
                break;
        }        
        $time = date('Y.m.d  H:i:s', time());
        $wxfan_name = '用户名字：'.$wxfan['w_nickname'];
        $question_type = '问题类型：';
        switch($question['q_type']) {
            case OrderModel::QUESTION_TYPE_FREE :
                $question_type .= '免费问';
                break;
            case OrderModel::QUESTION_TYPE_PAYMENT :
                $question_type .= '付费问';
                break;
            case OrderModel::QUESTION_TYPE_PHONE :
                $question_type .= '电话问';
                break;
            case OrderModel::QUESTION_TYPE_CASE :
                $question_type .= '案件委托';
                break;
            case OrderModel::QUESTION_TYPE_DIRECT_CASE :
                $question_type .= '一对一案件';
                break;
            case OrderModel::QUESTION_TYPE_DIRECT_PHONE :
                $question_type .= '一对一电话';
                break;
        }
        $question_content = '问题内容：';
        if (mb_strlen($question['q_content'], 'utf8') > 20) { $question_content .= mb_substr($question['q_content'], 0, 20, 'utf8').'...'; }
        else { $question_content .= $question['q_content']; }
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        
        $message = '\n'.$title.'\n'.$time.'\n\n';
        if ($question['q_status'] > OrderModel::QUESTION_STATUS_REQUEST) { $message .= $wxfan_name.'\n'; }
        $message .= $question_type.'\n'.$question_content.'\n';
        $message .= '-------------------------'.'\n';
        $message .= "<a href='".$rooturl. U('Home/Lawyer/qiangyemian')."?q_id=".$question['q_id']."&lawyer_id=".$question['q_lid']."'>查看详情</a>";
        return $message;        
    }
    
    public function createWxfanMessage($q_id, $cat) {
        $db_question = D('Common/Order');
        $db_lawyer = D('Common/Lawyer');
        $db_wxfan = D('Common/WxFan');
        
        $question = $db_question->where(array('q_isdelete'=>0,'q_id'=>$q_id))->find();
        $lawyer = $db_lawyer->where(array('l_isdelete'=>0,'l_id'=>$question['q_lid']))->find();
        $lawyer_wxfan = $db_wxfan->where(array('isdelete'=>0,'w_lawyerid'=>$question['q_lid']))->find();
        $wxfan = $db_wxfan->where(array('isdelete'=>0,'w_wxfanid'=>$question['q_wxfanid']))->find();
        $setting['before_remind_time'] = D('Common/SystemSetting')->GetSettingValue(SystemSettingModel::KEY_BEFORE_REMIND_TIME);
        
        $title = '';
        switch($cat) {
            case 1:
                $title = '订单已生成，请支付';
                break;
            case 2:
                $title = '咨询发布成功';
                break;
            case 3:
                $title = '律师接单啦';
                break;
            case 4:
                $title = '律师回复了您的咨询';
                break;
            case 5:
                $title = '律师未及时回复，是否咨询其他律师？';
                break;
            case 6:
                if ($question['q_type'] == OrderModel::QUESTION_TYPE_PAYMENT) { $title = '咨询已成功升级为付费问'; }
                else if ($question['q_type'] == OrderModel::QUESTION_TYPE_PHONE) { $title = '咨询已成功升级为电话问'; }
                break;
            case 7:
                $title = ''.$setting['before_remind_time'].'小时后问题将关闭，请及时咨询';
                break;
            case 8:
                $title = '请对律师服务作出评价';
                break;
            case 9:
                $title = '您未发表评价，'.$setting['before_remind_time'].'小时后将默认好评';
                break;
            case 10:
                $title = '律师发起“结束咨询”请求，请尽快处理';
                break;
            case 11:
                $title = '问题已关闭';
                break;
            case 12:
                $title = '已有律师接单，请选择律师';
                break;
            case 13:
                $title = '律师发起“关闭委托”请求，请尽快处理';
                break;
            case 14:
                $title = '委托已关闭';
                break;
            case 15:
                $title = '律师发起“达成委托”请求，请尽快处理';
                break;
            case 16:
                $title = '委托已达成';
                break;
        }
        
        $time = date('Y.m.d  H:i:s', time());
        $lawyer_name = '律师名字：'.$lawyer['l_name'];
        $question_type = '问题类型：';
        switch($question['q_type']) {
            case OrderModel::QUESTION_TYPE_FREE :
                $question_type .= '免费问';
                break;
            case OrderModel::QUESTION_TYPE_PAYMENT :
                $question_type .= '付费问';
                break;
            case OrderModel::QUESTION_TYPE_PHONE :
                $question_type .= '电话问';
                break;
            case OrderModel::QUESTION_TYPE_CASE :
                $question_type .= '案件委托';
                break;
            case OrderModel::QUESTION_TYPE_DIRECT_CASE :
                $question_type .= '一对一案件';
                break;
            case OrderModel::QUESTION_TYPE_DIRECT_PHONE :
                $question_type .= '一对一电话';
                break;
        }
        $question_content = '问题内容：';
        if (mb_strlen($question['q_content'], 'utf8') > 20) { $question_content .= mb_substr($question['q_content'], 0, 20, 'utf8').'...'; }
        else { $question_content .= $question['q_content']; }
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        
        $message = '\n'.$title.'\n'.$time.'\n\n';
        if ($question['q_status'] > OrderModel::QUESTION_STATUS_REQUEST) { $message .= $lawyer_name.'\n'; }
        $message .= $question_type.'\n'.$question_content.'\n';
        $message .= '-------------------------'.'\n';
        $message .= "<a href='".$rooturl. U('Home/User/showConversation')."?q_id=".$question['q_id']."'>查看详情</a>";
        
        return $message;
    }
    
    public static function getRootUrl() {
        return (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
    }    
}
