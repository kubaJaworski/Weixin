<?php
return array(
	//'配置项'=>'配置值'
	//'app_begin'=>array('\\Common\\Behavior\\SettingBehavior'),	//自定义设置
);
?>