<?php
namespace Common\Model;
use Think\Model;

class WxPageModel extends Model{
    protected $tableName = 'wxpage';
    protected $pk        = 'wxpid';
    
    public function GetCount()
    {
        return $this->where(array('isdelete'=>'0'))->count();
    }
    
    public function GetItems($sort, $order, $first, $count)
    {
        $order = $sort . ' ' . $order;
        $limit = $first . ", " . $count;

        $sql = "SELECT w.*  FROM app2_wxpage w WHERE w.isdelete = 0";
        $sql = $sql . " ORDER BY " . $order;
        $sql = $sql . " LIMIT " . $limit;

        $result = $this->query($sql);

        return $result;
    }
    
    public function exist_name($title) {
        $result = $this->where(array('wxp_name'=>$title, 'isdelete'=>0))->select();
        if(!empty($result)) {
            return true;
        } else {
            return false;
        }
    }
        
}