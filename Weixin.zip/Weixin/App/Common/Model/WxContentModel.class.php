<?php
namespace Common\Model;
use Think\Model;

class WxContentModel extends Model{
	protected $tableName = 'wxcontent';
	protected $pk        = 'wxcid';
	public    $error;

        public function GetWeixinResponse($theWeixin, $wxcid, $fromUserName, $toUserName, $eventKey, $event, $msgType, $content)
        {
            $responseString = $theWeixin->weChat->transmitToText('Unimplement Content', $toUserName, $fromUserName );         
            return $responseString;
        }

}