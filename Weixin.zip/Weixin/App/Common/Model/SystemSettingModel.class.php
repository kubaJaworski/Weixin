<?php

namespace Common\Model;
use Think\Model;

class SystemSettingModel extends Model {

    protected $tableName = 'system_setting';
    protected $pk = 'ssid';
    public $error;
    
    const KEY_FREE_CHANCE           = 'mianfeiwen_yonghushu';
    const KEY_PAY_CHANCE            = 'fufeiwen_yonghushu';
    
    const KEY_PAY_PRICE             = 'fufeiwen_feiyong_lushi';
    const KEY_PHONE_PRICE           = 'dianhuawen_feiyong';
    const KEY_CASE_PRICE            = 'anjianweituo_weituofeiyong';
    
    const KEY_FREE_VALID_TIME       = 'mainfeiwen_qiangdahou_youxiaoshijian';
    const KEY_PAYMENT_VALID_TIME    = 'fufeiwen_qiangdahou_youxiaoshijian';
    const KEY_PHONE_VALID_TIME      = 'dianhuawen_qiangdahou_youxiaoshijian';
    
    const KEY_FOLLOW_TIME           = 'qiangdachaoshishijian';
    const KEY_FOLLOW_REMIND_TIME    = 'qiangdatixingshijian';
    const KEY_APPEAL_VALID_TIME     = 'shensuyouxiaoshijian';
    const KEY_PAY_VALID_TIME        = 'fufeiwen_fufeiwenti_youxiaoshijian';
    const KEY_QUESTION_VALID_TIME   = 'wentiyouxiaoshijian';
    const KEY_BEFORE_REMIND_TIME    = 'qiantixingshijian';

    public function getSetting($fileName = 'Setting') {
        $result = array();
        $fields = dict('', $fileName);
        $settingField = array_keys($fields);
        $where = "`ss_key` in('" . implode("','", $settingField) . "')";
        $data = $this->where($where)->getField('ss_key,ss_value', true);

        $result['total'] = count($fields);
        foreach ($fields as $key => &$arr) {
            $arr['value'] = array_key_exists($key, $data) ? $data[$key] : $arr['default'];
            $arr['key'] = $key;
        }
        $result['rows'] = array_values($fields);

        return $result;
    }

    public function dosave($datas = array(), $fileName = 'Setting') {
        $fields = dict('', $fileName);
        $settingField = array_keys($fields);

        $where = "`ss_key` in('" . implode("','", $settingField) . "')";
        $list = $this->where($where)->getField('ss_key', true);
        if (!is_array($list))
            $list = array();
        $result = false;
        foreach ($datas as $data) {
            if (in_array($data['ss_key'], $list)) {
                $state = $this->where(array('ss_key' => $data['ss_key']))->save($data);
            } else {
                $state = $this->add($data);
            }
            if ($state)
                $result = true;
        }
        return $result;
    }

    public function GetSettingValue($key, $defaultValue = 0) {
        $result = $this->where(array('ss_key' => $key))->find();
        if (empty($result))
            return $defaultValue;

        return $result['ss_value'];
    }

    public function SetSettingValue($key, $value) {
        $result = $this->where(array('ss_key' => $key))->find();

        $state = 0;

        if (empty($result)) {
            $state = $this->add(array('ss_key' => $key, 'ss_value' => $value));
        } else {
            if ($value == $result['ss_value']) {
                $state = 1;
            } else {
                $state = $this->where(array('ss_key' => $key))->save(array('ss_value' => $value));
            }
        }
        if ($state) {
            return true;
        }
        return false;
    }
    
    public function getPriceByQuestionType($type) {
        return $this->where(array('ss_key'=>$this->getFieldNameByType($type)))->getField('ss_value');
    }

    public function getFieldNameByType($index) {
        $title = array("fufeiwen_feiyong",'dianhuawen_feiyong','anjianweituo_weituofeiyong');
        return $title[$index - 2];
    }

}
