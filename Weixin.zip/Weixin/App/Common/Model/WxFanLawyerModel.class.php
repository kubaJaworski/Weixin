<?php
namespace Common\Model;
use Think\Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of WxFanLawyerModel
 *
 * @author Administrator
 */
class WxFanLawyerModel extends Model{
    protected $tableName = 'wxfan_lawyer';
    protected $pk        = 'fid';
    
    public function getLawyerCountWithWxFan($lawyer_id) {
        return $this->where('lid=' . $lawyer_id . ' AND wxfanid != 0 AND status=1')->count();
    }
    
    public function getFollowStatus($lawyer_id, $user_id) {
        return $this->where('lid=' . $lawyer_id . ' AND wxfanid=' . $user_id . ' AND status=1')->count();
    }
    
    public function updateFollowStatus($follow) {
        $count = $this->where(array('wxfanid'=>$follow['wxfanid'],'lid'=>$follow['lid']))->count();
        
        if ($count == 0) {
            $this->add(array('wxfanid'=>$follow['wxfanid'],'lid'=>$follow['lid'],'status'=>$follow['status'],'create_time'=>strtotime('now')));
        }
        else if($count == 1) {
            $this->where(array('wxfanid'=>$follow['wxfanid'],'lid'=>$follow['lid']))->delete();
        }
    }
    
    public function getFollowedLawyer($wxfanid) {
        return $this->where(array('isdelete'=>0,'wxfanid'=>$wxfanid))->order('create_time desc')->select();
    }
}
