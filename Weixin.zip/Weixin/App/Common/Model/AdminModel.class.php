<?php
namespace Common\Model;
use Think\Model;

class AdminModel extends Model{
	protected $tableName = 'admin';
	protected $pk        = 'userid';
	public      $error;
	
	/**
	 * 登录验证
	 */
	public function login($username, $password){
		//$times_db = M('times');

		//查询帐号
		$r = $this->where(array('username'=>$username, 'isdelete'=>0))->find();
		if(!$r){
			$this->error = '管理员不存在';
			return false;
		}
		
		
		$password = md5(md5($password).$r['encrypt']);
		$ip             = get_client_ip(0, true);

		if($r['password'] != $password) {
		
			$this->error = "密码错误，再试一试！";
			return false;
		}
		
		$this->where(array('userid'=>$r['userid']))->save(array('lastloginip'=>$ip,'lastlogintime'=>time()));
		
		//登录日志
		$admin_log_db = M('admin_log');
		$admin_log_db->add(array(
			'userid'             => $r['userid'],
			'username'       => $username,
			'httpuseragent' => $_SERVER['HTTP_USER_AGENT'],
			'ip'                   => $ip,
			'time'               => date('Y-m-d H:i:s'),
			'type'               => 'login',
			'sessionid'        => session_id(),
		));
		
		session('userid', $r['userid']);
		session('roleid', $r['roleid']);
		session('stoid',$r['stoid']);
		cookie('username', $username);
		cookie('userid', $r['userid']);
		S('SESSION_ID_' . $r['userid'] , session_id());  //单点登录用
		return true;
	}
	
	/**
	 * 获取用户信息
	 */
	public function getUserInfo($userid){
		$admin_role_db = D('Common/AdminRole');
		$info = $this->field('password, encrypt', true)->where(array('userid'=>$userid))->find();
		if($info) $info['rolename'] = $admin_role_db->getRoleName($info['roleid']);    //获取角色名称
		return $info;
	}
	
	/**
	 * 修改密码
	 */
	public function editPassword($userid, $password){
		$userid = intval($userid);
		if($userid < 1) return false;
		$passwordinfo = password($password);
		return $this->where(array('userid'=>$userid))->save($passwordinfo);
	}

    public function GetItems($sort, $order, $first, $count)
    {
        $order = $sort . ' ' . $order;
        $limit = $first . ", " . $count;

        $sql = "SELECT * FROM app2_admin a
                LEFT JOIN app2_admin_role s
                ON a.roleid = s.roleid and s.disabled = 0
                WHERE a.isdelete = 0";

        $sql = $sql . " ORDER BY " . $order;
        $sql = $sql . " LIMIT " . $limit;

        $result = $this->query($sql);

        return $result;
    }
}