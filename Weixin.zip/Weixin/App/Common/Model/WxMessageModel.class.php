<?php
namespace Common\Model;
use Think\Model;

class WxMessageModel extends Model{
    protected $tableName = 'wxmessage';
    protected $pk        = 'wxmsgid';
    public    $error;

    public function GetItems($sort, $order, $first, $count)
    {
        $order = $sort . ' ' . $order;
        $limit = $first . ", " . $count;

        $sql = "SELECT w.*, wcd.title as wxcdtitle
                FROM app2_wxmessage w
                LEFT JOIN app2_wxcontent_detail wcd
                ON w.wxcdid = wcd.wxcdid
                WHERE w.isdelete = 0";

        $sql = $sql . " ORDER BY " . $order;
        $sql = $sql . " LIMIT " . $limit;

        $result = $this->query($sql);

        return $result;
    }
}