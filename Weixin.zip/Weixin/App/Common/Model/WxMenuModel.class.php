<?php
namespace Common\Model;
use Think\Model;

class WxMenuModel extends Model{
	protected $tableName = 'wxmenu';
	protected $pk        = 'wxmid';
	public    $error;


}