<?php
namespace Common\Model;
use Think\Model;

class WxFanModel extends Model{
    protected $tableName = 'wxfan';
    protected $pk        = 'w_wxfanid';
    public    $error;

    public function getUserByOpenId($openid) {
        return $this->where(array('isdelete'=>0,'w_openid'=>$openid))->find();
    }
    
    public function getUserByLawyerId($lawyer_id) {
        return $this->where(array('isdelete'=>0,'w_lawyerid'=>$lawyer_id))->find();
    }

    public function getLawyer($lawyer_id) {
        return $this->where(array('isdelete'=>0,'w_lawyerid'=>$lawyer_id))->find();
    }

    public function getUserId($openid)
    {
        $fan = $this->where( array('w_openid'=>$openid, 'isdelete'=>0) )->find();

        if( empty($fan)) {
            return 0;
        }
        return $fan['w_wxfanid'];
    }

    public function SetUserId($openid, $uid)
    {
        $fan = $this->where( array( 'openid'=>$openid, 'isdelete'=>0 ) )->find();
        if( empty($fan) )
        {
            return false;
        }
        $result = $this->where( array( 'wxfanid'=>$fan['wxfanid'] ) )->save( array( 'uid'=>$uid ));
        $fan1 = $this->where( array( 'wxfanid'=>$fan['wxfanid'] ) )->find();

        if( !empty($uid) && !empty($fan['nickname']) )
        {
            $db_user = D('Common/User');
            $db_user->where(array('uid'=>$uid))->save(array('u_name'=> $fan['nickname'], 'u_avatar'=>$fan['headimageurl'] ));
        }
        if( $fan1['uid'] == $uid )
            return true;

        return false;
    }
        
    public function GetItems($sort, $order, $first, $count) {
        $order = $sort . ' ' . $order;
        $limit = $first . ", " . $count;

        $sql = "SELECT * FROM app2_wxfan wx
                LEFT JOIN app2_question q
                ON wx.w_wxfanid = q.q_wxfanid and q.q_isdelete = 0
                LEFT JOIN app2_lawyer lw
                ON wx.w_lawyerid = lw.l_id and lw.l_isdelete = 0
                WHERE wx.isdelete = 0 AND wx.w_lawyerid = 0 GROUP BY wx.w_wxfanid";

        $sql = $sql . " ORDER BY wx." . $order;
        $sql = $sql . " LIMIT " . $limit;
        return $this->query($sql);
    }

    public function getUserFromPhone($phonenum) {
        return $this->where( array('w_phone'=>$phonenum, 'isdelete'=>0) )->find();
    }
    
    public function getUserNameFromId($id) {
        $result = $this->where(array('isdelete'=>0,'w_wxfanid'=>$id))->getField('w_nickname');
        return $result;
    }
    
    public function getUserById($id) {
        return $this->where(array('isdelete'=>0,'w_wxfanid'=>$id))->find();
    }
    
    public function updateNickName($id, $nickname) {
        $index = $this->where(array('w_wxfanid'=>$id,'isdelete'=>0))->setField(array('w_nickname'=>$nickname));
        return $index;
    }
    
    public function updatePhoneNumber($id, $phone_number) {
        $index = $this->where(array('w_wxfanid'=>$id,'isdelete'=>0))->setField(array('w_phone'=>$phone_number));
        return $index;
    }
    
    public function savePortraitUrl($id, $url) {
        $index = $this->where(array('isdelete'=>0,'w_wxfanid'=>$id))->setField('w_headimageurl',$url);
        return $index;
    }
    
    public function bindLawyer($openid, $lawyer_id) {
        $this->where(array('isdelete'=>0, 'w_openid'=>$openid))->setField(array('w_lawyerid'=>$lawyer_id));
    }
    
}