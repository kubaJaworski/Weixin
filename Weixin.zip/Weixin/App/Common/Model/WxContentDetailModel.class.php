<?php
namespace Common\Model;
use Think\Model;
use Think\Log;

class WxContentDetailModel extends Model{
	protected $tableName = 'wxcontent_detail';
	protected $pk        = 'wxcdid';
	public    $error;
        
        public function GetCount(  )
        {
            $sql = "SELECT COUNT(*) AS tp_count from app2_wxcontent_detail a ";
            $sql = $sql . " LIMIT 1 ";
            
            $result = $this->query($sql);
            
            if(empty($result)) {
               return 0; 
            }
            
            return intval($result[0]['tp_count']);
        }
        
        public function GetItems(  $sort, $order, $first, $count )
        {
            $order = $sort . ' ' . $order;
            $limit = $first . ", " . $count;
            
            $sql = "SELECT * from app2_wxcontent_detail a "
                    . " WHERE a.isdelete = 0 ";
           
            $sql = $sql . " ORDER BY " . $order;
            $sql = $sql . " LIMIT " . $limit;
           
            $result = $this->query($sql);
            
            return $result;
        }

    public function DeleteContent($wxcdid)
    {
        $result = $this->where(array('wxcdid'=>$wxcdid))->save(array('isdelete'=>1));

        return $result;
    }

    public function exist_name($title) {
        $result = $this->where(array('title'=>$title, 'isdelete'=>0))->select();
        if(!empty($result)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function GetWeixinResponse($theWeixin, $wxcdid, $fromUserName, $toUserName, $eventKey, $event, $msgType, $content)
    {
        $responseString = $theWeixin->weChat->transmitToText('Unimplement ContentDetailModel', $toUserName, $fromUserName );  
        
        $item = $this->where(array('wxcdid'=>$wxcdid))->find();
        
        if( empty($item) == false )
        {
            $text = $item['title'];
            if( empty($item['text']) == false )
            {
                $text = $item['text'];
            }
            
            $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
            
            $url = $rooturl . $item['contenturl'];
            if( empty($item['url']) == false )
            {
                $url = $item['url'];
                if( substr( $url, 0, 7 ) === "http://" )
                {
                    //$url = $url;
                }
                else
                {
                    $url = $rooturl . $url;
                }
            }
            
            $picurl = $rooturl . '/Public/static/img/default_banner.png';
            if( empty($item['picurl']) == false)
            {
                $picurl = $rooturl . $item['picurl'];
            }
            
            $responseString = $theWeixin->weChat->transmitToNews($text, $item['title'], $item['description'], $picurl,  $url, $toUserName, $fromUserName);
        }
        
        Log::record( '[ Weixin ] WxContentDetailModel::GetWeixinResponse ' . $responseString );  
        return $responseString;
    }
}