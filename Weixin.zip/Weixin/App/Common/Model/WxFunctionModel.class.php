<?php
namespace Common\Model;
use Think\Model;
use Common\Common\TheApp;

class WxFunctionModel extends Model{
	protected $tableName = 'wxfunction';
	protected $pk        = 'wxfuncid';
	public    $error;
        
        const TYPE_APPFUNC          = 0;
        const TYPE_MESSAGE          = 1;
        const TYPE_SUBSCRIBE        = 2;    
        const TYPE_LUCKYWHEEL       = 3;
        const TYPE_COUPON           = 4;
        const TYPE_WEIZHULI         = 5;
    
        public function GetTypeString($type)
        {
            $result = '-';
            switch ($type)
            {
                case self::TYPE_APPFUNC:
                    $result = '基本功能';
                    break;
                case self::TYPE_MESSAGE:
                    $result = '自动回复';
                    break;
                case self::TYPE_SUBSCRIBE:
                    $result = '关注回复';
                    break;
                case self::TYPE_LUCKYWHEEL:
                    $result = '大转盘';
                    break;
                case self::TYPE_COUPON:
                    $result = '优惠券';
                    break;
                case self::TYPE_WEIZHULI:
                    $result = '微助力';
                    break;
            }
            return $result;
        }
        
        public function GetFuncName($item)
        {
            $result = '-';
            switch ($item['functype'])
            {
                case self::TYPE_APPFUNC:
                    $result = TheApp::GetAppFuncName($item['appfuncid']);
                    break;
                case self::TYPE_MESSAGE:
                    $result = $item['title'];
                    break;
                case self::TYPE_SUBSCRIBE:
                    $result = $item['title'];
                    break;
                case self::TYPE_LUCKYWHEEL:
                    $result = $item['lwname'];
                    break;
                case self::TYPE_COUPON:
                    $result = $item['cp_title'];
                    break;
                case self::TYPE_WEIZHULI:
                    $result = $item['wz_name'];
                    break;
            }
            return $result;
        }
        
        public function GetWeixinResponseFromObject($theWeixin, $item, $fromUserName, $toUserName, $eventKey, $event, $msgType, $content)
        {
            $result = '';
            switch ($item['functype'])
            {
                case self::TYPE_APPFUNC:
                    $result = TheApp::GetWeixinResponse($theWeixin, $item['appfuncid'], $fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                    break;
                case self::TYPE_MESSAGE:
                case self::TYPE_SUBSCRIBE:
                    if( $item['wxcdid'] != 0 )
                    {
                        $db_wxcontentdetail = D('Common/WxContentDetail');
                        $result = $db_wxcontentdetail->GetWeixinResponse($theWeixin, $item['wxcdid'], $fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                    }
                    else if ( $item['wxcid'] != 0 )
                    {
                        $db_wxcontent = D('Common/WxContentDetail');
                        $result = $db_wxcontent->GetWeixinResponse($theWeixin, $item['wxcid'], $fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                    }                    
                    break;
                case self::TYPE_LUCKYWHEEL:
                    if( $item['lwid'] != 0 )
                    {
                        $db_luckywheel = D('Common/LuckyWheel');
                        $result = $db_luckywheel->GetWeixinResponse($theWeixin, $item['lwid'], $fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                    }
                    break;
                case self::TYPE_COUPON:
                    if( $item['cp_id'] != 0 )
                    {
                        $db_coupon = D('Common/Coupon');
                        $result = $db_coupon->GetWeixinResponse($theWeixin, $item['cp_id'], $fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                    }
                    break;
                case self::TYPE_WEIZHULI:
                    if( $item['wzid'] != 0 )
                    {
                        $db_wxzhuli = D('Common/WxZhuli');
                        $result = $db_wxzhuli->GetWeixinResponse($theWeixin, $item['wzid'], $fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                    }
                    break;               
            }
            
            return $result;
        }
        
        public function GetItems($sort, $order, $first, $count)
	{
		$order = $sort . ' ' . $order;
		$limit = $first . ", " . $count;

		$sql = "SELECT w.*, wc.wcname, wcd.title, lw.lwname, wz.wz_name,cp.cp_title
                        FROM app2_wxfunction w
                        LEFT JOIN app2_wxcontent wc
                        ON w.wxcid = wc.wxcid
                        LEFT JOIN app2_wxcontent_detail wcd
                        ON w.wxcdid = wcd.wxcdid
                        LEFT JOIN app2_luckywheel lw
                        ON w.lwid = lw.lwid
                        LEFT JOIN app2_wxzhuli wz
                        ON w.wzid = wz.wzid
                        LEFT JOIN app2_coupon cp
                        ON w.cp_id = cp.cp_id
                        WHERE w.isdelete = 0";

		$sql = $sql . " ORDER BY " . $order;
		$sql = $sql . " LIMIT " . $limit;

		$result = $this->query($sql);

		return $result;
	}

}