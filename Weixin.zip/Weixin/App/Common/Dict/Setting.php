<?php
return array(
	/* 全站设置  */
	'app_service_phone' => array(
		'name'    => '客服热线',
		'group'   => '基本设置',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => '',
	),
        'service_qq' => array(
		'name'    => 'QQ',
		'group'   => '基本设置',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => '',
	),       
	'app_url_yanjiaodongtai' => array(
		'name'    => '燕郊动态',
		'group'   => '基本设置',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => '',
	),
	'app_android_version' => array(
		'name'    => '安卓版本',
		'group'   => '版本信息',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => '',
	),
	'app_android_apk_url' => array(
		'name'    => '安卓URL',
		'group'   => '版本信息',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => 'http://',
	),
	'app_ios_version' => array(
		'name'    => '苹果版本',
		'group'   => '版本信息',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => ''
	),
    'app_ios_url' => array(
        'name'    => '苹果URL',
        'group'   => '版本信息',
        'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
        'default' => 'http://'
    ),
    'app_server_version' => array(
            'name'    => '后台版本',
            'group'   => '版本信息',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
    
    'default_feyin_host' => array(
            'name'    => '打印服务',
            'group'   => '提醒设置',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
    
    'default_feyin_port' => array(
            'name'    => '服务端口',
            'group'   => '提醒设置',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
    'default_feyin_membercode' => array(
            'name'    => '商户编码 ',
            'group'   => '提醒设置',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
    
     'default_feyin_key' => array(
            'name'    => '商户密码',
            'group'   => '提醒设置',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
    
     'default_feyin_deviceno' => array(
            'name'    => '打印机号码',
            'group'   => '提醒设置',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
   
    /*
    'default_sms_phone' =>array(
            'name'    => '短信电话',
            'group'   => '提醒设置',
            'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
            'default' => '',
    ),
     */
    
    'unit_jifen_value' => array(
        'name'    => '单位积分设置',
        'group'   => '积分设置',
        'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
        'default' => '0.01',
    ),
    
     'tuiguang_jifen_value' => array(
        'name'    => '推广码增加积分',
        'group'   => '积分设置',
        'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
        'default' => '1.0',
    ),
    
    'rate_jifen_value' => array(
        'name'    => '积分换钱比率',
        'group'   => '积分设置',
        'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
        'default' => '1.0',
    ),
    
    'order_min_price' => array(
		'name'    => '限购金额',
		'group'   => '购买设置',
		'editor'  => array('type'=>'validatebox','options'=>array('tipPosition'=>'left', 'validType'=>array('nothtml','length[0,255]'))),
		'default' => '',
	),
);