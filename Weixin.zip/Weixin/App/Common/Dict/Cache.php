<?php
return array(
	//Model名 => func名
//	'Setting'  => 'clearCatche',	//自定义设置
	'Category' => 'clearCatche',	//内容栏目
	'Menu'     => 'clearCatche',	//后台菜单
);