<?php
/**
 * 扫描目录所有文件，并生成treegrid数据
 * @param string $path     目录
 * @param string $filter   过滤文件名
 * @return array
 */
function scan_dir($path, $filter = SITE_DIR) {
	$result = array();
	$path = realpath($path);

	$path = str_replace(array('/', '\\'), DS, $path);
	$filter = str_replace(array('/', '\\'), DS, $filter);

	$list = glob($path . DS . '*');

	foreach ($list as $key => $filename) {
		$result[$key]['path'] = str_replace($filter, '', $filename);
		$result[$key]['name'] = basename($filename);
		$result[$key]['mtime'] = date('Y-m-d H:i:s', filemtime($filename));

		if (is_dir($filename)) {
			$result[$key]['type'] = 'dir';
			$result[$key]['size'] = '-';
		} else {
			$result[$key]['type'] = 'file';
			$result[$key]['size'] = format_bytes(filesize($filename), ' ');
		}
	}
	return $result;
}

/**
 * 上传目录列表
 * @param string $path 目录名
 * @return array
 */
function file_list_upload($path){
	$config  = C('TMPL_PARSE_STRING');
	switch (strtoupper(C('FILE_UPLOAD_TYPE'))){
		case 'SAE':
			$path     = str_replace(DS, '/', rtrim($path, DS));
			$arr      = explode('/', ltrim($path, './'));
			$domain   = array_shift($arr);
			$filePath = implode('/', $arr);
			$s        = new SaeStorage();
			$list     = $s->getListByPath($domain, $filePath);
			$res  = array();
			while(isset($list['dirNum']) && $list['dirNum']){
				$list['dirNum']--;
				array_push($res, array(
					'type'  => 'dir',
					'name'  => $list['dirs'][$list['dirNum']]['name'],
					'path'  => ltrim($list['dirs'][$list['dirNum']]['fullName'], 'upload/'),
					'size'  => '-',
					'mtime' => '-',
					'url'   => '#',
				));
			}
			while(isset($list['fileNum']) && $list['fileNum']){
				$list['fileNum']--;
				array_push($res, array(
					'type'  => 'file',
					'name'  => $list['files'][$list['fileNum']]['Name'],
					'path'  => ltrim($list['files'][$list['fileNum']]['fullName'], 'upload/'),
					'size'  => format_bytes($list['files'][$list['fileNum']]['length'], ' '),
					'mtime' => date('Y-m-d H:i:s', $list['files'][$list['fileNum']]['uploadTime']),
					'url'   => ltrim($list['files'][$list['fileNum']]['fullName'], 'upload/'),
				));
			}
			return $res;
			break;

		case 'FTP':
			$storage = new \Common\Plugin\Ftp();
			$list    =  $storage->ls($path);
			foreach($list as &$item){
				$item['path'] = ltrim($item['path'], UPLOAD_PATH);
				$item['url']  = str_replace('\\', '/', $item['path']);
			}
			return $list;
			break;

		default:
			$path = realpath($path);
			$path = str_replace(array('/', '\\'), DS, $path);
			$list = glob($path . DS . '*');
			$res  = array();
			foreach ($list as $key => $filename) {
				array_push($res, array(
					'type'  => (is_dir($filename) ? 'dir' : 'file'),
					'name'  => basename($filename),
					'path'  => ltrim(str_replace(realpath(UPLOAD_PATH), '', $filename), DS),
					'size'  => format_bytes(filesize($filename), ' '),
					'mtime' => date('Y-m-d H:i:s', filemtime($filename)),
					'url'   => ltrim(str_replace(array(realpath(UPLOAD_PATH), '\\'), array('', '/'), $filename), '/'),
				));
			}
			return $res;
	}
}

/**
 * 生成UUID
 * @return string 返回UUID字符串
 */
function uuid() {
	$uuid = M()->query('SELECT UUID() AS uuid;');
	return $uuid[0]['uuid'];
}

/**
 * 生成弹出层上传链接
 * @param $callback
 * @param string $ext
 * @return string
 */
function url_upload($callback, $ext = 'jpg|jpeg|png|gif|bmp'){
	$query = array('callback'=>$callback, 'ext'=>$ext);
	$query['sign'] = sign($query);
	return U('Storage/public_dialog', $query);
}

function exportexcel($data=array(), $filters = array(), $title=array(), $filename='report'){
	header("Content-type:application/octet-stream");
	header("Accept-Ranges:bytes");
	header("Content-type:application/vnd.ms-excel");
	header("Content-Disposition:attachment;filename=".$filename.".xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	//导出xls 开始
	if (!empty($title)){
		foreach ($title as $k => $v) {
			$title[$k]=iconv("UTF-8", "GB2312",$v);
		}
		$title= implode("\t", $title);
		echo "$title\n";
	}
	if (!empty($data)){
		foreach($data as $key=>$val){

			$line = array();
			foreach($filters as $filter) {
				if(isset($val[$filter])) {
					$line[$filter] = iconv("UTF-8", "GB2312",$val[$filter]);
				}
				else {
					$line[$filter] = '-';
				}
			}
			$data[$key]=implode("\t", $line);
		}
		echo implode("\n",$data);
	}
}


function _upload($files, $config = array(), $field = 'upload'){
    //上传配置
    if(!isset($config['own']) || !$config['own']){
        $config = array_merge(C('FILE_UPLOAD_CONFIG'), $config);
    }

    $upload = new Upload($config);
    $res = $upload->upload($files);
    if($res){
        $filename = $res[$field]['savepath'] . $res[$field]['savename'];

        //图片加水印
//        if(strpos($res[$field]['type'], 'image') !== false ) $this->water($filename);

        return array('status'=>1, 'info'=>$filename, 'result'=>$res[$field]);
    }else{
        return array('status'=>0, 'info'=>$upload->getError(), 'result'=>null);
    }
}

function image_upload($savepath, $filename_prefix) {
    $filename = date('Ymd_HiS');
    $config = array(
        'exts'       => array('jpg', 'gif', 'png', 'jpeg'),
        'autoSub'    => false,       //自动子目录保存文件
        'rootPath'   => UPLOAD_PATH,  //保存根路径
        'savePath'   => $savepath.'/',    //保存路径
        'saveName'   => $filename_prefix.$filename,      //上传文件命名规则，[0]-函数名，[1]-参数，多个参数使用数组
        'replace'    => true,        //存在同名是否覆盖
    );
    $res = _upload($_FILES, $config);

    if($res['status']){
        $data = array('status'=>1, 'info'=>'上传成功', 'filename'=>$filename);
    }else{
        $data = array('status'=>0, 'info'=>$res['info']);
    }
    $this->ajaxReturn(json_encode($data), 'eval');
}

function date_difference($date_1, $date_2, $differenceFormat='%a') {

    $datetime1 = date_create($date_1);
    $datetime2 = date_create($date_2);

    $interval = date_diff($datetime1, $datetime2);
    return $interval->format($differenceFormat);
}

function getCategoryString($cidPostStr)
{
	// get cid
	$iFirst = strrpos( $cidPostStr, '(' );
	$iSecond = strrpos($cidPostStr, ')' );
	$cidStr = substr( $cidPostStr, ($iFirst +1), ($iSecond - $iFirst - 1) );

	if( empty($cidStr) )
	{
		return 0;
	}

	$db_category = D('Common/Category');
	$category = $db_category->where(array('cid'=>$cidStr, 'isdelete'=>0))->find();
	if( $category == null || empty($category ) )
	{
		return 0;
	}

	$name = $category['c_name'] . "(" . $category['cid'] . ')';
	$name1 = '　' . $category['c_name'] . "(" . $category['cid'] . ')';
	if($cidPostStr != $name && $cidPostStr != $name1 )
	{
		return 0;
	}

	$cidVal =  0;
	try
	{
		$cidVal = intval($cidStr);
	}
	catch(Exception $ex)
	{
		return 0;
	}

	return $cidVal;
}

function getDateStringBeforeMonth($cnt_month) {
    $year = date('Y');
    $month = date('m');
    $day = date('d');
    $month = $month - $cnt_month;
    if($month <= 0) {
        $year --;
        $month += 12;
    }
    return $year.'-'.$month.'-'.$day;
}

