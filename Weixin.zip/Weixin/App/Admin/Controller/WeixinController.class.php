<?php
namespace Admin\Controller;
use Common\Common\TheApp;
use Common\Common\TheWeixin;
use Admin\Controller\CommonController;
use Common\Model\CategoryModel;
use Common\Model\WxFunctionModel;
use Common\Model\WxMenuModel;
use Common\Model\CouponModel;
use Common\Model\WxFanReportModel;
use Think\Log;

class WeixinController extends CommonController {

    private $weChat;
    private $wx_app_id;
    private $wx_app_secret;
    private $wx_app_token;
    private $wx_app_encoding_key;

    public function __construct(){
        parent::__construct();
    }
    
    protected function InitWeixin()
    {
        if( $this->weChat == null )
        {
            $setting_db = D('Common/SystemSetting');
            $this->wx_app_id = $setting_db->GetSettingValue('wx_app_id', '');
            $this->wx_app_secret = $setting_db->GetSettingValue('wx_app_secret', '');
            $this->wx_app_token = $setting_db->GetSettingValue('wx_app_token', '');
            $this->wx_app_encoding_key = $setting_db->GetSettingValue('wx_app_encoding_key', '');             
            $this->weChat = new \Org\Util\WeChat($this->wx_app_id, $this->wx_app_secret, $this->wx_app_encoding_key);
        }
    }
    
    public function WxConnect()
    {
        $setting_db = D('Common/SystemSetting');

        $wx_app_id      = $setting_db->GetSettingValue('wx_app_id', '');
        $wx_app_secret  = $setting_db->GetSettingValue('wx_app_secret', '');
        $wx_app_token   = $setting_db->GetSettingValue('wx_app_token', '');
        $wx_app_encoding_key = $setting_db->GetSettingValue('wx_app_encoding_key', '');
        
        $wx_app_mchid   = $setting_db->GetSettingValue('wx_app_mchid', '');
        $wx_app_paysignkey = $setting_db->GetSettingValue('wx_app_paysignkey', '');
            

        if(IS_POST){
            $data = array();
            $data['wx_app_id']              =  $wx_app_id;
            $data['wx_app_secret']          =  $wx_app_secret;
            $data['wx_app_token']           =  $wx_app_token;
            $data['wx_app_encoding_key']    =  $wx_app_encoding_key;
            $data['wx_app_mchid']           =  $wx_app_mchid;
            $data['wx_app_paysignkey']      =  $wx_app_paysignkey;
            
            $this->ajaxReturn($data);
        }
        else {
            $this->assign('wx_app_id',       $wx_app_id );
            $this->assign('wx_app_secret',   $wx_app_secret );
            $this->assign('wx_app_token',    $wx_app_token );
            $this->assign('wx_app_encoding_key', $wx_app_encoding_key );
            $this->assign('wx_app_mchid',       $wx_app_mchid );
            $this->assign('wx_app_paysignkey',  $wx_app_paysignkey );
           
            $url = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . U('/Home/Wechat');
            $this->assign('wx_app_url', $url );
            $this->display('wxconnect');
        }
    }
    
    public function wxConnectSet()
    {
        if(IS_POST){
            $setting_db = D('Common/SystemSetting');
            $data = I('data');
           
            $wx_app_id = $data['wx_app_id'];
            $wx_app_secret = $data['wx_app_secret'];
            $wx_app_token = $data['wx_app_token'];
            $wx_app_encoding_key = $data['wx_app_encoding_key'];
            
            $wx_app_mchid = $data['wx_app_mchid'];
            $wx_app_paysignkey = $data['wx_app_paysignkey'];
            
            try
            {
                $setting_db->startTrans();
                
                $result3 = $setting_db->SetSettingValue('wx_app_id', $wx_app_id);
                $result4 = $setting_db->SetSettingValue('wx_app_secret', $wx_app_secret);
                $result5 = $setting_db->SetSettingValue('wx_app_token', $wx_app_token);
                $result6 = $setting_db->SetSettingValue('wx_app_encoding_key', $wx_app_encoding_key);
                
                $result7 = $setting_db->SetSettingValue('wx_app_mchid', $wx_app_mchid);
                $result8 = $setting_db->SetSettingValue('wx_app_paysignkey', $wx_app_paysignkey);
                
                if( $result3 && $result4 && $result5  && $result6 && $result7 && $result8 )
                {
                    $setting_db->commit();
                    $this->success('设定成功');
                    $this->weChat = null;
                    return;
                }
                else 
                {
                    $setting_db->rollback();
                }
            }
            catch(Exception $ex)
            {
                $setting_db->rollback();
            }
            
            $this->error('设定失败');
            return;
        }
    }
    
    public function WxMenu()
    {       
        $wxmenu_db = D('Common/WxMenu');
        
        if( IS_POST )
        {
            $types = I('types');
            $names = I('names');
            $urls = I('urls');
            $keywords = I('keywords');
            $apps = I('apps');
            
            for( $i = 0; $i <count($types); $i++)
            {
                $data = array('type'=>$types[$i]
                        , 'name'=>$names[$i]
                        , 'url'=>$urls[$i]
                        , 'keyword'=>$keywords[$i]
                        , 'app'=>$apps[$i]);
                $id = $i + 1;
                $wxmenu_db->where(array('wxmid'=>$id))->save($data);
            }
            
            $resultCode = $this->wxCreateMenu();
            if( $resultCode == 0 )
            {
                $this->success('设定成功');
            }
            else
            {
                $resultString = TheWeixin::GetResponseString($resultCode);
                if( empty($resultString) == true)
                {
                    $resultString = '修改失败';
                }
                $this->error( $resultString );
            }
        }
        else 
        {
            $wxmenu1 = $wxmenu_db->where(array('mainindex'=>0))->order('wxmid','asc')->select();
            $wxmenu2 = $wxmenu_db->where(array('mainindex'=>1))->order('wxmid','asc')->select();
            $wxmenu3 = $wxmenu_db->where(array('mainindex'=>2))->order('wxmid','asc')->select();
            
            $applist = TheApp::GetAppFuncList();
            $this->assign( 'applist', $applist );
            $this->assign( 'wxmenu1', $wxmenu1 );
            $this->assign( 'wxmenu2', $wxmenu2 );
            $this->assign( 'wxmenu3', $wxmenu3 );
            $this->display( 'wxmenu' );
        }
    }
    
    protected function wxCreateMenu()
    {
        try
        {
            $this->InitWeixin();
            
            $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
            
            $wxmenu_db = D('Common/WxMenu');
            $wxmenu1 = $wxmenu_db->where(array('mainindex'=>0))->order('wxmid','asc')->select();
            $wxmenu2 = $wxmenu_db->where(array('mainindex'=>1))->order('wxmid','asc')->select();
            $wxmenu3 = $wxmenu_db->where(array('mainindex'=>2))->order('wxmid','asc')->select();

            $premainmenu1 = array();
            $submenu1 = array();
            foreach( $wxmenu1 as $item )
            {
                if( $item['type'] == 'NONE' || empty($item['name']) == true ){
                    continue;
                }

                $addmenu = &$submenu1;
                if( $item['displayorder'] == 0 ){
                    $addmenu = &$premainmenu1;
                }

                if( $item['type'] == 'CLICK' )
                {
                    $addmenu[] = array('type'=>'click', 'name'=>urlencode($item['name']), 'key'=>urlencode($item['keyword']));
                }
                else if( $item['type'] == 'VIEW')
                {
                    $menuurl = html_entity_decode($item['url']);
                    $addmenu[] = array('type'=>'view', 'name'=>urlencode($item['name']), 'url'=>$menuurl );
                }
                else if( $item['type'] == 'APP')
                {
                    $appUrl = $rooturl . U( 'Home/wechat/appBind' ) . '?funcid='. $item['app'];
                    $wxAppUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" 
                            . $this->wx_app_id 
                            . "&redirect_uri=" 
                            . $appUrl
                            . "&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
                    $addmenu[] = array('type'=>'view', 'name'=>urlencode($item['name']), 'url'=>($wxAppUrl ) );
                }
            }

            $premainmenu2 = array();
            $submenu2 = array();
            foreach( $wxmenu2 as $item )
            {
                if( $item['type'] == 'NONE' || empty($item['name']) == true ){
                    continue;
                }

                $addmenu = &$submenu2;
                if( $item['displayorder'] == 0 ){
                    $addmenu = &$premainmenu2;
                }

                if( $item['type'] == 'CLICK' )
                {                    
                    $addmenu[] = array('type'=>'click', 'name'=>urlencode($item['name']), 'key'=>urlencode($item['keyword']) );
                }
                else if( $item['type'] == 'VIEW')
                {
                    $menuurl = html_entity_decode($item['url']);
                    $addmenu[] = array('type'=>'view', 'name'=>urlencode($item['name']), 'url'=>$menuurl );
                }
                else if( $item['type'] == 'APP')
                {
                    $appUrl = $rooturl . U( 'Home/wechat/appBind' ) . '?funcid='. $item['app'];
                    $wxAppUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" 
                            . $this->wx_app_id 
                            . "&redirect_uri=" 
                            . $appUrl
                            . "&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
                    $addmenu[] = array('type'=>'view', 'name'=>urlencode($item['name']), 'url'=>($wxAppUrl ) );
                }
            }

            $premainmenu3 = array();
            $submenu3 =  array();
            foreach( $wxmenu3 as $item )
            {
                if( $item['type'] == 'NONE' || empty($item['name']) == true ){
                    continue;
                }

                $addmenu = &$submenu3;
                if( $item['displayorder'] == 0 ){
                    $addmenu = &$premainmenu3;
                }

                if( $item['type'] == 'CLICK' )
                {
                    $addmenu[] = array('type'=>'click', 'name'=>urlencode($item['name']), 'key'=>urlencode($item['keyword']) );
                }
                else if( $item['type'] == 'VIEW')
                {
                    $menuurl = html_entity_decode($item['url']);
                    $addmenu[] = array('type'=>'view', 'name'=>urlencode($item['name']), 'url'=>$menuurl);
                }
                else if( $item['type'] == 'APP')
                {
                    $appUrl = $rooturl . U( 'Home/wechat/appBind' ) . '?funcid='. $item['app'];
                    $wxAppUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" 
                            . $this->wx_app_id 
                            . "&redirect_uri=" 
                            . $appUrl
                            . "&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect";
                    $addmenu[] = array('type'=>'view', 'name'=>urlencode($item['name']), 'url'=>($wxAppUrl ) );
                }
            }

            $mainmenu1 = array();
            if( empty($premainmenu1) == false )
            {
                $mainmenu1['name'] = $premainmenu1[0]['name'];
                
                if( !empty($premainmenu1[0]['url']) )
                {
                    $mainmenu1['type'] = $premainmenu1[0]['type'];
                    $mainmenu1['url'] = $premainmenu1[0]['url'];
                }
                else if( !empty($premainmenu1[0]['key']) )
                {
                    $mainmenu1['type'] = $premainmenu1[0]['type'];
                    $mainmenu1['key'] = $premainmenu1[0]['key'];
                }
                
                $mainmenu1['sub_button'] = $submenu1 ;
            }

            $mainmenu2 = array();
            if( empty($premainmenu2) == false )
            {
                 $mainmenu2['name'] = $premainmenu2[0]['name'];
                
                if( !empty($premainmenu2[0]['url']) )
                {
                    $mainmenu2['type'] = $premainmenu2[0]['type'];
                    $mainmenu2['url'] = $premainmenu2[0]['url'];
                }
                else if( !empty($premainmenu2[0]['key']) )
                {
                    $mainmenu2['type'] = $premainmenu2[0]['type'];
                    $mainmenu2['key'] = $premainmenu2[0]['key'];
                }
                
                $mainmenu2['sub_button'] = $submenu2 ;
            }

            $mainmenu3 = array();
            if( empty($premainmenu3) == false )
            {
                $mainmenu3['name'] = $premainmenu3[0]['name'];
                
                if( !empty($premainmenu3[0]['url']) )
                {
                    $mainmenu3['type'] = $premainmenu3[0]['type'];
                    $mainmenu3['url'] = $premainmenu3[0]['url'];
                }
                else if( !empty($premainmenu3[0]['key']) )
                {
                    $mainmenu3['type'] = $premainmenu3[0]['type'];
                    $mainmenu3['key'] = $premainmenu3[0]['key'];
                }
                
                $mainmenu3['sub_button'] = $submenu3 ;
            }

            $menu = array();
            if(empty($mainmenu1) == false)
            {
                $menu[] = $mainmenu1;
            }

            if(empty($mainmenu2) == false)
            {
                $menu[] = $mainmenu2;
            }

            if(empty($mainmenu3) == false)
            {
                $menu[] = $mainmenu3;
            }

            $button = array('button' =>$menu );
            
            // 创建菜单
            $accessToken = $this->weChat->getAccessToken();          
            $result = $this->weChat->createMenu($button, $accessToken);
           
            if( $result == 0)
                return $result;
            
            return $result;
        }
        catch(Exception $e)
        {
            Log::record( '[ Weixin ] create menu exception ' . var_dump($e) );  
        }
        
        return -100;
    }
    
    public function wxContentIndex() {
        $menu_db = D('Common/Menu');
        $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
        $this->assign(currentpos, $currentpos);
        $this->display('wxcontent_index');
    }

    public function wxContentList($page = 1, $rows = 10, $sort = 'wxcdid', $order = 'desc'){
       
        if(IS_POST){
            $wxcontent_detail_db = D('Common/WxContentDetail');
            $total = $wxcontent_detail_db->GetCount();

            $first = ($page - 1) * $rows;
            $list = $total ? $wxcontent_detail_db->GetItems( $sort, $order, $first, $rows) : array();
            
            foreach($list as &$item)
            {
                $item['createtime'] = date('Y-m-d H:i', $item['createtime']);
            }
            
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }else{
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                    'url'     => U('Weixin/wxContentList', array('grid'=>'datagrid')),
                    'toolbar' => 'wxContentModule.toolbar',
                ),
                'fields' => array(
                    '生成日期'      => array('field'=>'createtime','width'=>10,'sortable'=>true),
                    '图文名称'      => array('field'=>'title','width'=>10,'sortable'=>true),
                    '浏览数'      => array('field'=>'readcount','width'=>15,'sortable'=>true),
                    '管理操作'    => array('field'=>'wxcdid','width'=>15,'formatter'=>'wxContentModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxcontent_list');
        }
    }

    public function wxContentAdd(){
       
        if(IS_POST){
            if(I('get.dosubmit')){
                $wxcontent_detail_db = D('Common/WxContentDetail');
                $data = I('post.info', array(), 'trim');
                if(!$data['title'] || !$data['content']) $this->error('请填写必填字段');

                if($wxcontent_detail_db->exist_name($data['title'])) {
                    $this->error('添加失败。在那个分类，名称已存在。');
                }

                $html_filename = "/upload/weixin/html/wxcontent_".date('Ymd-His').'.html';
                $db_html_filename = "/upload/weixin/html/getcontent.php?content=wxcontent_".date('Ymd-His').'.html';
                file_put_contents('Public'.$html_filename, $data['content'], LOCK_EX);

                $new_data = array();
                $new_data['title'] = $data['title'];
                $new_data['description'] = $data['description'];
                $new_data['picurl'] = $data['picurl'];
                $new_data['url'] = $data['url'];
                $new_data['contenturl'] = '/Public'.$db_html_filename;
                $new_data['readcount'] = 0;
                $new_data['isdelete'] = 0;
                $cur_time = time();
                $new_data['createtime'] = $cur_time;
                
                $bid = $wxcontent_detail_db->add($new_data);

                if($bid){
                    $this->success('添加成功');
                }else {
                    $this->error('添加失败');
                }
            } else {
                
                $data = array();
                $data[] = array('group'=>'基本设置', 'name'=>'* 名称', 
                        'key'=>'title',
                        "value"=>"",
                        "editor"=>"text",
                        'required'=> true );             

                $data[] = array('group'=>'基本设置'
                    , 'name'=>'图片'
                    , 'key' => 'picurl'
                    , "value"=>""
                    , "editor"=>array('type'=>'image', 'options'=>array( 'handler'=>'wxContentModule.uploadImage', 'width'=>240, 'height'=>180, 'subfix'=>'_1x1')) );

                $data[] = array('group'=>'基本设置'
                    , 'name'=>'URL'
                    , 'key' => 'url'
                    , "value"=>""
                    , "editor"=>"text" );

                $data[] = array('group'=>'基本设置'
                    ,  'name'=>'简介'
                    ,  'key' => 'description'
                    ,  "value"=>""
                    , 'editor' => array('type'=>'textarea','options'=>array('tipPosition'=>'left', 'validType'=>array('length'=>array(5,255)) ))
                    );
                $this->ajaxReturn($data);
            }
        }else{
            $this->display('wxcontent_add');
        }
    }

    public function wxContentDelete() {
        $wxcontent_detail_db = D('Common/WxContentDetail');
        $wxcdid = I('post.wxcdid');
        $result = $wxcontent_detail_db->DeleteContent($wxcdid);

        if ($result){
            $this->success('删除成功');
        }else {
            $this->error('删除失败');
        }
    }

    public function wxContentEdit($wxcdid) {
        $wxcontent_detail_db = D('Common/WxContentDetail');
        if(IS_POST) {
            if(I('get.dosubmit')){
                $data = I('post.info', array(), 'trim');
                if(!$data['title'] || !$data['content']) $this->error('请填写必填字段');

                $html_filename = "/upload/weixin/html/wxcontent_" . $wxcdid . '.html';
                $db_html_filename = "/upload/weixin/html/getcontent.php?content=wxcontent_" . $wxcdid . '.html';
                file_put_contents('Public'.$html_filename, $data['content'], LOCK_EX);

                $new_data = array();
                $cur_time = time();
                
                $new_data['title'] = $data['title'];                
                $new_data['url'] = $data['url'];
                $new_data['picurl'] = $data['picurl'];
                $new_data['contenturl'] = '/Public'.$db_html_filename;
                $new_data['description'] = $data['description'];
                
                $result = $wxcontent_detail_db->where(array('wxcdid'=>$wxcdid))->save($new_data);
                $this->success('修改成功');
            } else {
                $wxcontent    = $wxcontent_detail_db->where(array('wxcdid'=>$wxcdid))->find();
                
                $data = array();
                $data[] = array('group'=>'基本设置', 'name'=>'* 名称', 
                        'key'=>'title',
                        "value"=>$wxcontent['title'],
                        "editor"=>"text",
                        'required'=> true );             

                $data[] = array('group'=>'基本设置'
                    ,  'name'=>'图片'
                    , 'key' => 'picurl'
                    , "value"=>$wxcontent['picurl']
                    , "editor"=>array('type'=>'image', 'options'=>array( 'handler'=>'wxContentModule.uploadImage', 'width'=>240, 'height'=>180, 'subfix'=>'_1x1')) );

                $data[] = array('group'=>'基本设置'
                    , 'name'=>'URL'
                    , 'key' => 'url'
                    , "value"=>$wxcontent['url']
                    , "editor"=>"text"  );

                $data[] = array('group'=>'基本设置'
                    ,  'name'=>'简介'
                    ,  'key' => 'description'
                    ,  "value"=>$wxcontent['description']
                    , 'editor' => array('type'=>'textarea','options'=>array('tipPosition'=>'left', 'validType'=>array('length'=>array(5,255)) ))
                    );
                
                $this->ajaxReturn($data);
            }
        }
        else {
            $info = $wxcontent_detail_db->where(array('wxcdid'=>$wxcdid))->find();
            $detailurl = substr($info['contenturl'], 1);
            $detailurl = str_replace('getcontent.php?content=', '', $detailurl);
            $contents = file_get_contents($detailurl);
            $info['content'] = htmlspecialchars_decode($contents);
            $this->assign('info', $info);
            $this->display('wxcontent_edit');
        }
    }

    public function editor_iframe($callback = ''){

        if($callback) $callback = 'window.parent.'. $callback .'();';

        $this->assign('callback', $callback);
        $this->display('editor');
    }
    
    
    /**
     * 用户管理
     */
    public function wxFunctionList($page = 1, $rows = 10, $sort = 'wxfuncid', $order = 'desc')
    {
        if(IS_POST){
            $wxfunction_db = D('Common/wxFunction');
            $total = $wxfunction_db->where(array('isdelete' => 0))->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxfunction_db->GetItems($sort, $order, $first, $rows) : array();
            foreach( $list as &$item )
            {
                $functypestr = $wxfunction_db->GetTypeString($item['functype']);
                $funcname = $wxfunction_db->GetFuncName($item);
                
                $item['funcname'] =  $funcname;
                $item['functype'] = $functypestr;                
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {

            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/wxFunctionList', array('grid'=>'datagrid')),
                        'toolbar' => 'wxFunctionModule.toolbar',
                ),
                'fields' => array(
                        '关键字'      => array('field'=>'keyword','width'=>50,'sortable'=>true),
                        '功能类型'      => array('field'=>'functype','width'=>50,'sortable'=>true),
                        '功能'      => array('field'=>'funcname','width'=>25,'sortable'=>true),
                        '管理操作'    => array('field'=>'wxfuncid','width'=>25,'formatter'=>'wxFunctionModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxfunction_list');
        }
    }
	
    /**
     * 添加用户
     */
    public function wxFunctionAdd(){
        if(IS_POST){
                $wxfunction_db = D('Common/wxFunction');
                $data = I('post.info');

                if($wxfunction_db->where(array('keyword'=>$data['keyword'], 'isdelete'=>0))->field('keyword')->find()){
                    $this->error('该关键字已存在');
                    return;
                }
                
                if( $data['functype'] == WxFunctionModel::TYPE_SUBSCRIBE )
                {
                    $total = $wxfunction_db->where(array('functype'=>WxFunctionModel::TYPE_SUBSCRIBE, 'isdelete'=>0))->count();
                    
                    if( $total > 0 )
                    {
                        $this->error('该关注回复功能已连接了');
                        return;
                    }
                }
                
                $adddata['keyword'] = $data['keyword'];
                $adddata['functype'] = $data['functype'];
                $adddata['appfuncid'] = 0;
                $adddata['wxcid'] = 0;
                $adddata['wxcdid'] = 0;
                $adddata['lwid'] = 0;
                $adddata['cp_id'] = 0;
                $adddata['wzid'] = 0;
                $adddata['createtime'] = time();
                $adddata['isdelete'] = 0;
                
                switch($data['functype'])
                {
                    case WxFunctionModel::TYPE_APPFUNC:
                        $adddata['appfuncid'] = $data['funcid'];
                        break;
                    case WxFunctionModel::TYPE_MESSAGE:
                        $adddata['wxcdid'] = $data['funcid'];
                        break;
                    case WxFunctionModel::TYPE_SUBSCRIBE:
                        $adddata['wxcdid'] = $data['funcid'];
                        break;
                    case WxFunctionModel::TYPE_LUCKYWHEEL:
                        $adddata['lwid'] = $data['funcid'];
                        break;
                    case WxFunctionModel::TYPE_COUPON:
                        $adddata['cp_id'] = $data['funcid'];
                        break;
                    case WxFunctionModel::TYPE_WEIZHULI:
                        $adddata['wzid'] = $data['funcid'];
                        break;
                }
                
                $id = $wxfunction_db->add($adddata);
                if($id){      
                    $this->success('添加成功');
                }else {
                    $this->error('添加失败');
                }
        }else{
            $this->display('wxfunction_add');
        }
    }
    /**
     * 编辑会员
     */
    public function wxFunctionEdit($id){
        $wxfunction_db = D('Common/wxFunction');
        if(IS_POST){
            $wxfunction_db = D('Common/wxFunction');
            $data = I('post.info');

            $function = $wxfunction_db->where(array('wxfuncid'=>$id))->find();
            
            if($wxfunction_db->where(array('keyword'=>$data['keyword']
                    , 'isdelete'=>0
                    , 'wxfuncid'=>array('neq', $id)))->find())
            {
                $this->error('该关键字已存在');
                return;
            }

            if( $data['functype'] == WxFunctionModel::TYPE_SUBSCRIBE )
            {
                $total = $wxfunction_db->where(array('functype'=>WxFunctionModel::TYPE_SUBSCRIBE
                        , 'isdelete'=>0
                        , 'wxfuncid'=>array('neq', $id)))->count();

                if( $total > 0 )
                {
                    $this->error('该关注回复功能已连接了');
                    return;
                }
            }

            $adddata['keyword'] = $data['keyword'];
            $adddata['functype'] = $data['functype'];
            $adddata['appfuncid'] = 0;
            $adddata['wxcid'] = 0;
            $adddata['wxcdid'] = 0;
            $adddata['lwid'] = 0;
            $adddata['cp_id'] = 0;
            $adddata['wzid'] = 0;
            $adddata['createtime'] = time();
            $adddata['isdelete'] = 0;

            switch($data['functype'])
            {
                case WxFunctionModel::TYPE_APPFUNC:
                    $adddata['appfuncid'] = $data['funcid'];
                    break;
                case WxFunctionModel::TYPE_MESSAGE:
                    $adddata['wxcdid'] = $data['funcid'];
                    break;
                case WxFunctionModel::TYPE_SUBSCRIBE:
                    $adddata['wxcdid'] = $data['funcid'];
                    break;
                case WxFunctionModel::TYPE_LUCKYWHEEL:
                    $adddata['lwid'] = $data['funcid'];
                    break;
                case WxFunctionModel::TYPE_COUPON:
                    $adddata['cp_id'] = $data['funcid'];
                    break;
                case WxFunctionModel::TYPE_WEIZHULI:
                    $adddata['wzid'] = $data['funcid'];
                    break;
            }

            $id = $wxfunction_db->where(array('wxfuncid'=>$id))->save($adddata);
            if($id){      
                $this->success('修改成功');
            }else {
                $this->error('修改失败');
            }
        }
        else
        {
            $info = $wxfunction_db->where(array('wxfuncid'=>$id))->find();
            $this->assign('info', $info);
            $this->assign('functype', $info['functype']);
            $curIndex = 0;
            switch($info['functype'])
            {
                case WxFunctionModel::TYPE_APPFUNC:
                    $curIndex = $info['appfuncid'];
                    break;
                case WxFunctionModel::TYPE_MESSAGE:
                case WxFunctionModel::TYPE_SUBSCRIBE:
                    $curIndex = $info['wxcdid'];
                    break;
                case WxFunctionModel::TYPE_LUCKYWHEEL:
                    $curIndex = $info['lwid'];
                    break;
                case WxFunctionModel::TYPE_COUPON:
                    $curIndex = $info['cp_id'];
                    break;
                case WxFunctionModel::TYPE_WEIZHULI:
                    $curIndex = $info['wzid'];
                    break;
            }
            $this->assign( 'curIndex', $curIndex );            
            $this->display('wxfunction_edit');
        }
    }

    public function wxFunctionGetDetail( $functype, $oldfunctype=-1, $curIndex = -1 )
    {   
        $data=array();   
        switch($functype)
        {
            case WxFunctionModel::TYPE_APPFUNC:
                $list = TheApp::GetAppFuncList();
                foreach( $list as $func )
                {
                    $info['id'] = $func['id'];
                    if( $info['id'] ==  $curIndex && $functype == $oldfunctype )
                    {
                        Log::record("wxFunctionGetDetail selected " . $info['id'] );
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this,". $info['id'] . "  );' checked /> " . $func['funcname'] . "</span>";
                    }
                    else
                    {
                        Log::record("wxFunctionGetDetail unselected " . $info['id'] );
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this,". $info['id'] . "  );' /> " . $func['funcname'] . "</span>";
                    }
                    array_push($data, $info);
                }
                break;
            case WxFunctionModel::TYPE_MESSAGE:
                $db_contentdetail = D('Common/WxContentDetail');
                $list = $db_contentdetail->where(array('isdelete'=>0))->select();
                foreach( $list as $func )
                {
                    $info['id'] = $func['wxcdid'];
                    if( $info['id'] ==  $curIndex && $functype == $oldfunctype  )
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' checked /> " . $func['title'] . "</span>";
                    }
                    else
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' /> " . $func['title'] . "</span>";
                    }
                    array_push($data, $info);
                }
                break;
            case WxFunctionModel::TYPE_SUBSCRIBE:
                $db_contentdetail = D('Common/WxContentDetail');
                $list = $db_contentdetail->where(array('isdelete'=>0))->select();
                foreach( $list as $func )
                {
                    $info['id'] = $func['wxcdid'];
                    if( $info['id'] ==  $curIndex && $functype == $oldfunctype  )
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' checked /> " . $func['title'] . "</span>";
                    }
                    else
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' /> " . $func['title'] . "</span>";
                    }
                    array_push($data, $info);
                }
                break;
            case WxFunctionModel::TYPE_LUCKYWHEEL:
                $db_luckywheel = D('Common/LuckyWheel');
                $list = $db_luckywheel->where(array('isdelete'=>0))->select();
                foreach( $list as $func )
                {
                    $info['id'] = $func['lwid'];
                    if( $info['id'] ==  $curIndex && $functype == $oldfunctype  )
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' checked /> " . $func['lwname'] . "</span>";
                    }
                    else
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' /> " . $func['lwname'] . "</span>";
                    }
                    array_push($data, $info);
                }
                break;
            case WxFunctionModel::TYPE_COUPON:
                $db_coupon = D('Common/Coupon');
                $list = $db_coupon->where(array('isdelete'=>0))->select();
                foreach( $list as $func )
                {
                    $info['id'] = $func['cp_id'];
                    if( $info['id'] ==  $curIndex && $functype == $oldfunctype  )
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' checked /> " . $func['cp_title'] . "</span>";
                    }
                    else
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' /> " . $func['cp_title'] . "</span>";
                    }
                    array_push($data, $info);
                }
                break;
            case WxFunctionModel::TYPE_WEIZHULI:
                $db_wxzhuli = D('Common/WxZhuli');
                $list = $db_wxzhuli->where(array('isdelete'=>0))->select();
                foreach( $list as $func )
                {
                    $info['id'] = $func['wzid'];
                    if( $info['id'] ==  $curIndex && $functype == $oldfunctype  )
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' checked /> " . $func['wz_name'] . "</span>";
                    }
                    else
                    {
                        $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' /> " . $func['wz_name'] . "</span>";
                    }
                    array_push($data, $info);
                }
                break;
        }
        $this->ajaxReturn($data,'JSON');
        
    }
    
    /**
     * 删除会员
     */
    public function wxFunctionDelete($id){
        $wxfunction_db = D('Common/wxFunction');
        $result = $wxfunction_db->where(array('wxfuncid'=>$id))->save(array('isdelete'=>1));

        if ($result){                    
            $this->success('删除成功');
        }else {
            $this->error('删除失败');
        }
    }

    public function WxMessage($page = 1, $rows = 10, $sort = 'wxmsgid', $order = 'desc')
    {
        if(IS_POST){
            $wxmessage_db = D('Common/wxMessage');
            $total = $wxmessage_db->where(array('isdelete' => 0))->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxmessage_db->GetItems($sort, $order, $first, $rows) : array();
            foreach($list as &$info){
                $info['createtime']    = $info['createtime'] ? date('Y-m-d H:i:s', $info['createtime']) : '-';
             }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {

            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/wxMessage', array('grid'=>'datagrid')),
                        'toolbar' => 'wxMessageModule.toolbar',
                ),
                'fields' => array(
                        '发提时间'      => array('field'=>'createtime','width'=>25,'sortable'=>true),
                        '消息名称'      => array('field'=>'msgname','width'=>50,'sortable'=>true),
                        '图文名称'      => array('field'=>'wxcdtitle','width'=>50,'sortable'=>true),                        
                        '管理操作'    => array('field'=>'wxmsgid','width'=>25,'formatter'=>'wxMessageModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxmessagelist');
        }
    }
    
   
    /**
     * 发送消息
     */
    public function  wxMessageSend(){
        if(IS_POST){
                $data = I('post.info');
                
                $wxcdid = $data['wxcdid'];
                
                $content_db = D('Common/WxContentDetail');
                $content = $content_db->where(array('wxcdid'=>$wxcdid))->find();
                
                
                $title = $data['msgname'];
                $picurl = $content['picurl'];
                // get contents
                $descriptionurl = substr($content['contenturl'], 1);
                $descriptionurl = str_replace('getcontent.php?content=', '', $descriptionurl);
                $contents = file_get_contents($descriptionurl);
                // content source url                
                $contenturl = $content['url'];
                
                $mediafile = getcwd() . $picurl;
                $mediafile = str_replace("\\", "/", $mediafile );
                $this->InitWeixin();
                $accessToken = $this->weChat->getAccessToken();          
                
                // step 1: upload media & get media id
                $result = $this->weChat->uploadMedia($accessToken, "image", $mediafile);
                if( !empty($result["errcode"]) )
                {
                    $this->error(TheWeixin::GetResponseString($result["errcode"]));
                    return;
                }                
                $mediaid = $result["media_id"];
                
                // step 2: upload news
                $result = $this->weChat->uploadOneNews($accessToken, $mediaid, "110法律微信在线", $title, $contents, $contenturl );
                if( !empty($result["errcode"]) )
                {
                    $this->error(TheWeixin::GetResponseString($result["errcode"]));
                    return;
                }
                $news_mediaid = $result["media_id"];
                
                // step 3: send to fan
                $result = $this->weChat->sendNews($accessToken, "0", $news_mediaid );
                if( !empty($result["errcode"]) )
                {
                    $this->error(TheWeixin::GetResponseString($result["errcode"]));
                    return;
                }
                
                $adddata['wxcdid'] = $data['wxcdid'];
                $adddata['msgname'] = $data['msgname'];
                $adddata['createtime'] = time();
                $adddata['isdelete'] = 0;
                
                $wxmessage_db = D('Common/wxMessage');
                $id = $wxmessage_db->add($adddata);
                $this->success('发消息成功');
        }else{
            $this->display('wxmessage_add');
        }
    }
    
    /**
     * 发送消息
     */
    public function  wxMessageResend(){
           $this->success('重发成功');
    }
     /**
     * 删除
     */
    public function wxMessageDelete($id){
        $wxmessage_db = D('Common/wxMessage');
        $result = $wxmessage_db->where(array('wxmsgid'=>$id))->save(array('isdelete'=>1));

        if ($result){                    
            $this->success('删除成功');
        }else {
            $this->error('删除失败');
        }
    }
    
    /**
     * 添加用户
     */
    public function wxFanAdd(){
        $result = false;
        try
        {
            $this->InitWeixin();
            $accessToken = $this->weChat->getAccessToken();  

            $db_wxfan = D("Common/WxFan");
            $db_wxfan->where(array("isdelete"=>0))->save(array("isdelete"=>1));
            
            $nextopenid = "";
            $fanlist = $this->weChat->getFanList( $accessToken, $nextopenid );

            $count = intval($fanlist["count"]);
            while( $count > 0 )
            {
                $openids = $fanlist["data"]["openid"];
                
                foreach( $openids as $openid )
                {
                    
                    // get fan info
                    $fanInfo = $this->weChat->getFanInfo( $accessToken, $openid );
                    
                    // write fan info
                    $data = array(  "openid"    => $fanInfo['openid'],
                                "headimageurl"    => $fanInfo['headimgurl'],
                                "nickname"  => $fanInfo['nickname'],
                                "sex"       => $fanInfo['sex'],
                                "city"      => $fanInfo['city'],
                                "province"  => $fanInfo['province'],
                                "subscribe_time" => $fanInfo['subscribe_time'],
                                "groupid"   => $fanInfo['groupid'],
                                "isdelete"  => 0
                        );

                    $fanObj = $db_wxfan->where( array('openid'=>$fanInfo['openid']) )->find();

                    if( empty($fanObj) == true )
                    {
                        $db_wxfan->add($data);
                    }
                    else
                    {
                        $db_wxfan->where(array('openid'=>$fanInfo['openid']))->save($data);
                    }                    
                    
                    $nextopenid = $openid;
                }
                $fanlist = $this->weChat->getFanList($accessToken, $nextopenid);
                $count = intval($fanlist["count"]);
            }
            
            $result = true;

        } catch (Exception $ex) {

        }

        if ($result){                    
            $this->success('获取粉丝信息成功');
        }else {
            $this->error('获取粉丝信息失败');
        }     
        
    }
    
    public function wxFanDelete($id){
        $wxfan_db = D('Common/WxFan');
        $result = $wxfan_db->where(array('wxfanid'=>$id))->save(array('isdelete'=>1));

        if ($result){                    
            $this->success('删除成功');
        }else {
            $this->error('删除失败');
        }
    }
    
    public function WxFanList($page = 1, $rows = 10, $sort = 'w_wxfanid', $order = 'asc')
    {
        if(IS_POST){
            $wxfan_db = D('Common/WxFan');
            $total = $wxfan_db->where(array('isdelete'=>0,'w_lawyerid'=>0))->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxfan_db->GetItems($sort, $order, $first, $rows) : array();
            foreach( $list as &$item) {  
                $item['address'] = getAddress($item['w_province'], $item['w_city'], " ");
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/wxFanList', array('grid'=>'datagrid')),
                        'toolbar' => 'wxFanModule.toolbar',
                ),
                'fields' => array(
                        'OPEN ID'     => array('field'=>'w_openid','width'=>50,'sortable'=>true),
                        '昵称'         => array('field'=>'w_nickname','width'=>50,'sortable'=>true),
                        '地址'         => array('field'=>'address','width'=>50,'sortable'=>true),
//                        '绑定的律师 ID' => array('field'=>'lawyername','width'=>50,'sortable'=>true),
                        '手机号'       => array('field'=>'w_phone','width'=>50,'sortable'=>true),
                        '操作'         => array('field'=>'w_wxfanid','width'=>25,'formatter'=>'wxFanModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxfanlist');
        }
    }
    
    public function WxGroupList($page = 1, $rows = 20, $sort = 'id', $order = 'asc')
    {
        if(IS_POST){
            $wxgroup_db = D('Common/wxGroup');
            $total = $wxgroup_db->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxgroup_db->GetItems($sort, $order, $first, $rows) : array();
            foreach( $list as &$item )
            {
                if( empty($item['wgcount']) )
                {
                    $item['wgcount'] = '0';
                }
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {

            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/wxGroupList', array('grid'=>'datagrid')),
                        'toolbar' => 'wxGroupModule.toolbar',
                ),
                'fields' => array(
                        '分组ID'  => array('field'=>'id','width'=>50,'sortable'=>true),
                        '分组名称'    => array('field'=>'groupname','width'=>25,'sortable'=>true),
                        '粉丝数' => array('field'=>'wgcount','width'=>50,'sortable'=>true),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxgrouplist');
        }
    }
    
    public function WxFanReport($page = 1, $rows = 20, $sort = 'wl_date', $order = 'desc')
    {
        if(IS_POST){
            $wxfanreport_db = D('Common/wxFanReport');
            $total = $wxfanreport_db->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxfanreport_db->GetItems($sort, $order, $first, $rows) : array();
            
            foreach( $list as &$item )
            {
                $item['wl_date'] = date('Y.m.d', $item['wl_date'] );
            }
            $sumReport = $wxfanreport_db->GetSumReport( );
            $sumReport[0]['subscribe_count'] = '关注（'. $sumReport[0]['subscribe_count'] . ')';
            $sumReport[0]['unsubscribe_count'] = '取消关注（'. $sumReport[0]['unsubscribe_count'] . ')';
            $sumReport[0]['click_count'] = '自定义菜单（'. $sumReport[0]['click_count'] . ')';
            $sumReport[0]['scan_count'] = '扫描（'. $sumReport[0]['scan_count'] . ')';
            $sumReport[0]['keyword_count'] = '关键字（'. $sumReport[0]['keyword_count'] . ')';
            $sumReport[0]['message_count'] = '消息（'. $sumReport[0]['message_count'] . ')';
            $sumReport[0]['nickname'] = '合计';
            $sumReport[0]['openid'] = '';
            $sumReport[0]['wl_date'] = '';
            
            //$data = array('total'=>$total, 'rows'=>$list);
            $data = array('total'=>$total, 'rows'=>$list, 'footer'=>  $sumReport );
            $this->ajaxReturn($data);
        }
        else
        {

            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/wxFanReport', array('grid'=>'datagrid')),
                        'toolbar' => 'wxFanReportModule.toolbar',
                        'showFooter'=> true
                ),
                'fields' => array(
                        '日期'       => array('field'=>'wl_date','width'=>50,'sortable'=>true),     
                        '昵称'      => array('field'=>'nickname','width'=>50,'sortable'=>true),
                        'OPENID'    => array('field'=>'openid','width'=>50,'sortable'=>true),                        
                        '关注'      => array('field'=>'subscribe_count','width'=>50,'sortable'=>true),
                        '取消关注'  => array('field'=>'unsubscribe_count','width'=>50,'sortable'=>true),
                        '自定义菜单' => array('field'=>'click_count','width'=>50,'sortable'=>true),
                        '扫描'       => array('field'=>'scan_count','width'=>50,'sortable'=>true),
                        '关键字'     => array('field'=>'keyword_count','width'=>50,'sortable'=>true),
                        '消息'       => array('field'=>'message_count','width'=>50,'sortable'=>true),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxfanreport');
        }
    }
    
    public function QrcodeView($id){
        $wxqrcode_db = D('Common/wxQrcode');
        $info = $wxqrcode_db->where(array('scene_id'=>$id))->find();
        
        // first set default url
        $imageurl = 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQEI8ToAAAAAAAAAASxodHRwOi8vd2VpeGluLnFxLmNvbS9xL2hEaVF5N2JrSEFWbE5OajhCeFF0AAIEGYmiVgMEAAAAAA==';
        if( !empty($info))
        {
            $imageurl = 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=' . $info['ret_ticket'];
        }
        
        $this->assign('qrimageurl', $imageurl );
        $this->display('qrcode_view');
    }
    
    public function KeywordLists()
    {
        $db_wxfunction = D('Common/WxFunction');
        $list = $db_wxfunction->where(array('isdelete'=>0))->select();
        $data = array();
        foreach( $list as $func )
        {
            $info['id'] = $func['wxfuncid'];
            $info['text'] = "<input type='radio' class='funcid' onclick='selectWxFunction( this," . $info['id'] . ")' /> " . $func['keyword'] . "</span>";
            
            array_push($data, $info);
        }
        
        $this->ajaxReturn($data,'JSON');
    }
    
    public function QrcodeAdd(){
        if(IS_POST){
            $data = I('post.info');
            $wxqrcode_name = $data['wxqrcode_name'];
            $wxfuncid = $data['wxfuncid'];
            
            $wxqrcode_db = D('Common/wxQrcode');
            $sceneid = $wxqrcode_db->GetSceneId();
            
            if( $sceneid <= 0 )
            {
                 $this->error('超过二维码数量');
                 return;
            }
            
            $this->InitWeixin();
            $accessToken = $this->weChat->getAccessToken();          
            $result = $this->weChat->createQrcode($sceneid, $accessToken);
            
            if( !empty($result['errcode']) )
            {
                $this->error('生成二维码失败');
                return;
            }
            
            $ret_ticket = $result['ticket'];
            
            $ret_expire_second = -1;
            if( !empty($result['expire_seconds']) )
            {
                $ret_expire_second = $result['expire_seconds'];
            }
            
            $ret_url = $result['url'];
            
            $addresult = $wxqrcode_db->add(array( 'scene_id'=>$sceneid
                    , 'wxqrcode_name'=>$wxqrcode_name
                    , 'func_type'=>0
                    , 'wxfuncid'=>$wxfuncid
                    , 'func_url'=>''
                    , 'ret_ticket'=>$ret_ticket
                    , 'ret_expire_second'=>$ret_expire_second
                    , 'ret_url'=>$ret_url
                    , 'createtime'=>time()
                    , 'isdelete'=>0 ));
            if( !empty($addresult) )
            {
                $this->success('生成二维码成功');
            }
            else
            {
                $this->error('生成二维码失败');
            }
        }
        else
        {
            $this->display('qrcode_add');
        }
    }
    
    public function QrcodeDelete($id){
        $wxqrcode_db = D('Common/wxQrcode');
        $result = $wxqrcode_db->where(array('scene_id'=>$id))->save(array('isdelete'=>1));

        if ($result){                    
            $this->success('删除成功');
        }else {
            $this->error('删除失败');
        }
    }
    
    public function QrcodeList($page = 1, $rows = 20, $sort = 'scene_id', $order = 'desc')
    {
        if(IS_POST){
            $wxqrcode_db = D('Common/wxQrcode');
            $total = $wxqrcode_db->where(array('isdelete' => 0))->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxqrcode_db->GetItems($sort, $order, $first, $rows) : array();            
            foreach($list as &$info){
                $info['createtime']   = $info['createtime'] ? date('Y-m-d H:i:s', $info['createtime']) : '-';
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/QrcodeList', array('grid'=>'datagrid')),
                        'toolbar' => 'wxQrcodeModule.toolbar',
                ),
                'fields' => array(
                        '生成时间'  => array('field'=>'createtime','width'=>50,'sortable'=>true),
                        '名称'  => array('field'=>'wxqrcode_name','width'=>50,'sortable'=>true),
                        '关键字'    => array('field'=>'keyword','width'=>25,'sortable'=>true),
                        '操作'    => array('field'=>'scene_id','width'=>25,'formatter'=>'wxQrcodeModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('qrcodelist');
        }
    }
    
    public function luckywheelsetting($page = 1, $rows = 10, $sort = 'lwid', $order = 'desc')
    {
        if(IS_POST){
            $luckywheel_db = D('Common/LuckyWheel');
            $total = $luckywheel_db->where(array('isdelete' => 0))->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $luckywheel_db->GetItems($sort, $order, $first, $rows) : array();
            foreach($list as &$info){
                $info['createtime']   = $info['createtime'] ? date('Y-m-d H:i:s', $info['createtime']) : '-';
                $info['starttime']    = $info['starttime'] ? date('Y-m-d H:i:s', $info['starttime']) : '-';
                $info['endtime']      = $info['endtime'] ? date('Y-m-d H:i:s', $info['endtime']) : '-';
             }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                    'title'   => $currentpos,
                    'url'     => U('Weixin/luckywheelsetting', array('grid'=>'datagrid')),
                    'toolbar' => 'luckywheelModule.toolbar',
                ),
                'fields' => array(
                    '生成时间' => array('field'=>'createtime','width'=>50,'sortable'=>true),                   
                    '名称'     => array('field'=>'lwname','width'=>50,'sortable'=>true),
                    '奖品等级' => array('field'=>'rankcount','width'=>50,'sortable'=>true),
                    '开始时间' => array('field'=>'starttime','width'=>50,'sortable'=>true),                        
                    '结束时间' => array('field'=>'endtime','width'=>50,'sortable'=>true),
                    '管理操作' => array('field'=>'lwid','width'=>25,'formatter'=>'luckywheelModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('luckywheelsetting');
        }
    }
    
    public function luckywheelAdd()
    {
        if(IS_POST){
            $luckywheel_db = D('Common/LuckyWheel');
            $coupon_db  = D('Common/Coupon');
            
            $data = I('post.info');
            
            $lwname         = $data['lwname'];
            $lwdescription  = $data['lwdescription'];
            $rankcount      = $data['rankcount'];
            $rank_cpid1     = $data['rank_cpid1'];
            $rank_cpid2     = $data['rank_cpid2'];
            $rank_cpid3     = $data['rank_cpid3'];
            $rank_cpid4     = $data['rank_cpid4'];
            $rank_cpid5     = $data['rank_cpid5'];
            $rank_cpid6     = $data['rank_cpid6'];
            $rank_descr1    = $data['rank_descr1'];
            $rank_descr2    = $data['rank_descr2'];
            $rank_descr3    = $data['rank_descr3'];
            $rank_descr4    = $data['rank_descr4'];
            $rank_descr5    = $data['rank_descr5'];
            $rank_descr6    = $data['rank_descr6'];
            $isalluse      = $data['is_alluse'];
            $starttime      = $data['starttime'];
            $endtime        = $data['endtime'];
            $userwheelcount = $data['userwheelcount'];
            $now = time();
            
            // old luckywheel
            $oldluckywheel = $luckywheel_db->where(array('lwname'=>$data['lwname'], 'isdelete'=>0 ))->find();
            
            if( !empty($oldluckywheel) )
            {
                $this->error('大转盘名已存在');
                return;
            }
            
            // time check
            if( $isalluse == 'true' || $isalluse=='1' || $isalluse == true || $isalluse == 1 || $isalluse == 'on')
            {
                $starttime = 0;
                $endtime = 0;
            }
            else
            {
                $starttime = strtotime( $starttime . ' 00:00:00' );
                $endtime = strtotime( $endtime . ' 23:59:59' );
                
                if( $starttime > $endtime )
                {
                    $this->error('开始时间不可能超过结束时间');
                    return;
                }
                
                if( $endtime < $now )
                {
                    $this->error('结束时间已经过了');
                    return;
                }
            }
            
            if( $rankcount < 6 )
                $rank_cpid6 = 0;
            
            if( $rankcount < 5 )
                $rank_cpid5 = 0;
            
            if( $rankcount < 4 )
                $rank_cpid4 = 0;
            
            if( $rankcount < 3 )
                $rank_cpid3 = 0;
            
            if( $rankcount < 2 )
                $rank_cpid2 = 0;
            
            try
            {
                $luckywheel_db->startTrans();
                
                $result = $luckywheel_db->add(array( 'lwname'  => $lwname
                    , 'lwdescription'    =>  $lwdescription
                    , 'rankcount' =>  $rankcount
                    , 'rank_cpid1' => $rank_cpid1
                    , 'rank_cpid2' => $rank_cpid2
                    , 'rank_cpid3' => $rank_cpid3
                    , 'rank_cpid4' => $rank_cpid4
                    , 'rank_cpid5' => $rank_cpid5
                    , 'rank_cpid6' => $rank_cpid6
                    , 'rank_descr1' => $rank_descr1
                    , 'rank_descr2' => $rank_descr2
                    , 'rank_descr3' => $rank_descr3
                    , 'rank_descr4' => $rank_descr4
                    , 'rank_descr5' => $rank_descr5
                    , 'rank_descr6' => $rank_descr6
                    , 'starttime'   => $starttime
                    , 'endtime'     => $endtime
                    , 'userwheelcount' => $userwheelcount
                    , 'createtime'  =>  $now ));
                
                if( $result )
                {
                    $luckywheel = $luckywheel_db->where(array('lwname'=>$lwname, 'isdelete'=>0))->find();
                    
                    $result1 = 0;
                    $result2 = 0;
                    $result3 = 0;
                    $result4 = 0;
                    $result5 = 0;
                    $result6 = 0;
                    
                    if( !empty($rank_cpid1) )
                        $result1 = $coupon_db->SetLuckyWheelGetType($rank_cpid1, $luckywheel['lwid'], 1 );                        
                    
                    if( !empty($rank_cpid2) )
                        $result2 = $coupon_db->SetLuckyWheelGetType($rank_cpid2, $luckywheel['lwid'], 2 );
                    else
                        $result2 = 1;

                    if( !empty($rank_cpid3) )
                        $result3 = $coupon_db->SetLuckyWheelGetType($rank_cpid3, $luckywheel['lwid'], 3 );
                    else
                        $result3 = 1;

                    if( !empty($rank_cpid4) )
                        $result4 = $coupon_db->SetLuckyWheelGetType($rank_cpid4, $luckywheel['lwid'], 4 );
                    else
                        $result4 = 1;

                    if( !empty($rank_cpid5) )
                        $result5 = $coupon_db->SetLuckyWheelGetType($rank_cpid5, $luckywheel['lwid'], 5 );
                    else 
                        $result5 = 1;

                    if( !empty($rank_cpid6) )
                        $result6 = $coupon_db->SetLuckyWheelGetType($rank_cpid6, $luckywheel['lwid'], 6 );
                    else
                        $result6 = 1;

                    if( $result1 && $result2 && $result3 && $result4 && $result5 && $result6 )
                    {
                        $luckywheel_db->commit();
                        $this->success('发布成功');
                    }
                    else {
                        $luckywheel_db->rollback();
                        $this->error('发布失败：优惠券冲突');
                    }
                    return;
                }
                else
                {
                    $luckywheel_db->rollback();
                }
            }
            catch(Exception $ex)
            {
                $luckywheel_db->rollback();
            }
            
            $this->error('发布失败');
        }
        else
        {
            $coupon_db = D('Common/Coupon');
            
            $coupons = $coupon_db->where(array( 'isdeleted'=>0
                            , 'cp_luckywheelid'=>0
                            , 'cp_wzid'=>0
                            , 'cp_qsid'=>0 
                        ))->order('cp_id desc')->limit(20)->select();
            
            $this->assign('coupons', $coupons);            
            $this->display('luckywheel_add');
        }
    }
    
    public function luckywheelEdit($id)
    {        
        if( IS_POST )
        {
            $luckywheel_db = D('Common/LuckyWheel');
            $coupon_db  = D('Common/Coupon');
            
            $data = I('post.info');            
           
            $lwdescription  = $data['lwdescription'];
            $rankcount      = $data['rankcount'];
            $rank_cpid1     = $data['rank_cpid1'];
            $rank_cpid2     = $data['rank_cpid2'];
            $rank_cpid3     = $data['rank_cpid3'];
            $rank_cpid4     = $data['rank_cpid4'];
            $rank_cpid5     = $data['rank_cpid5'];
            $rank_cpid6     = $data['rank_cpid6'];
            $rank_descr1    = $data['rank_descr1'];
            $rank_descr2    = $data['rank_descr2'];
            $rank_descr3    = $data['rank_descr3'];
            $rank_descr4    = $data['rank_descr4'];
            $rank_descr5    = $data['rank_descr5'];
            $rank_descr6    = $data['rank_descr6'];
            $isalluse       = $data['is_alluse'];
            $starttime      = $data['starttime'];
            $endtime        = $data['endtime'];
            $userwheelcount = $data['userwheelcount'];
            $now = time();
            
            // time check
            if( $isalluse == 'true' || $isalluse=='1' || $isalluse == true || $isalluse == 1 || $isalluse == 'on')
            {
                $starttime = 0;
                $endtime = 0;
            }
            else
            {
                $starttime = strtotime( $starttime . ' 00:00:00' );
                $endtime = strtotime( $endtime . ' 23:59:59' );
                
                if( $starttime > $endtime )
                {
                    $this->error('开始时间不可能超过结束时间');
                    return;
                }
                
                if( $endtime < $now )
                {
                    $this->error('结束时间已经过了');
                    return;
                }
            }
            
            if( $rankcount < 6 )
                $rank_cpid6 = 0;
            
            if( $rankcount < 5 )
                $rank_cpid5 = 0;
            
            if( $rankcount < 4 )
                $rank_cpid4 = 0;
            
            if( $rankcount < 3 )
                $rank_cpid3 = 0;
            
            if( $rankcount < 2 )
                $rank_cpid2 = 0;
            
            try
            {
                $luckywheel_db->startTrans();
                
                $old = $luckywheel_db->where(array('lwid'=>$id))->find();                
                if( !empty($old['rank_cpid1']) )
                    $coupon_db->SetDefaultGetType( $old['rank_cpid1'] );

                if( !empty($old['rank_cpid2']) )
                    $coupon_db->SetDefaultGetType( $old['rank_cpid2'] );
                
                if( !empty($old['rank_cpid3']) )
                    $coupon_db->SetDefaultGetType( $old['rank_cpid3'] );
                
                if( !empty($old['rank_cpid4']) )
                    $coupon_db->SetDefaultGetType( $old['rank_cpid4'] );
                
                if( !empty($old['rank_cpid5']) )
                    $coupon_db->SetDefaultGetType( $old['rank_cpid5'] );
                
                if( !empty($old['rank_cpid6']) )
                    $coupon_db->SetDefaultGetType( $old['rank_cpid6'] );
                
                $result = $luckywheel_db->where(array('lwid'=>$id))->save(array( 
                     'lwdescription'    =>  $lwdescription
                    , 'rankcount' =>  $rankcount
                    , 'rank_cpid1' => $rank_cpid1
                    , 'rank_cpid2' => $rank_cpid2
                    , 'rank_cpid3' => $rank_cpid3
                    , 'rank_cpid4' => $rank_cpid4
                    , 'rank_cpid5' => $rank_cpid5
                    , 'rank_cpid6' => $rank_cpid6
                    , 'rank_descr1' => $rank_descr1
                    , 'rank_descr2' => $rank_descr2
                    , 'rank_descr3' => $rank_descr3
                    , 'rank_descr4' => $rank_descr4
                    , 'rank_descr5' => $rank_descr5
                    , 'rank_descr6' => $rank_descr6                   
                    , 'starttime'   => $starttime
                    , 'endtime'     => $endtime
                    , 'userwheelcount' => $userwheelcount ));
                
                if( $result )
                {
                    $result1 = 0;
                    $result2 = 0;
                    $result3 = 0;
                    $result4 = 0;
                    $result5 = 0;
                    $result6 = 0;
                    
                    if( !empty($rank_cpid1) )
                        $result1 = $coupon_db->SetLuckyWheelGetType($rank_cpid1, $id, 1 );                        
                    
                    if( !empty($rank_cpid2) )
                        $result2 = $coupon_db->SetLuckyWheelGetType($rank_cpid2, $id, 2 );
                    else
                        $result2 = 1;

                    if( !empty($rank_cpid3) )
                        $result3 = $coupon_db->SetLuckyWheelGetType($rank_cpid3, $id, 3 );
                    else
                        $result3 = 1;

                    if( !empty($rank_cpid4) )
                        $result4 = $coupon_db->SetLuckyWheelGetType($rank_cpid4, $id, 4 );
                    else
                        $result4 = 1;

                    if( !empty($rank_cpid5) )
                        $result5 = $coupon_db->SetLuckyWheelGetType($rank_cpid5, $id, 5 );
                    else 
                        $result5 = 1;

                    if( !empty($rank_cpid6) )
                        $result6 = $coupon_db->SetLuckyWheelGetType($rank_cpid6, $id, 6 );
                    else
                        $result6 = 1;

                    if( $result1 && $result2 && $result3 && $result4 && $result5 && $result6 )
                    {
                        $luckywheel_db->commit();
                        $this->success('修改成功');
                    }
                    else {
                        $luckywheel_db->rollback();
                        $this->error('修改失败：优惠券冲突');
                    }
                    return;
                }
                else
                {
                    $luckywheel_db->rollback();
                }
            }
            catch(Exception $ex)
            {
                $luckywheel_db->rollback();
            }
            
            $this->error('修改失败');
        }
        else
        {
            $this->InitWeixin();
            
            $coupon_db = D('Common/Coupon');
            $coupons = $coupon_db->where(array( 'isdelete'=>0
                            , 'cp_luckywheelid'=>array('in', array(0, $id))
                            , 'cp_wzid'=>0
                            , 'cp_qsid'=>0 
                        ))->order('cp_id desc')->limit(26)->select();
            
            $luckywheel_db = D('Common/LuckyWheel');
            $luckywheel = $luckywheel_db->where(array('lwid'=>$id))->find();
            
            $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
            $appUrl = $rooturl . U( 'Home/wechat/appBind' ) . '?funcid='. TheApp::FUNCID_LUCKYWHEEL . '&lwid=' .$id ;
            $wxAppUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" 
                           . $this->wx_app_id 
                           . "&redirect_uri=" 
                           . $appUrl
                           . "&response_type=code&scope=snsapi_userinfo&state=". $id . "#wechat_redirect";
            $luckywheel['lwlink'] = $wxAppUrl;
            
            $isalluse = (( $luckywheel['starttime'] == 0 ) &&( $luckywheel['endtime'] == 0 )) ? 'checked' : '';
            $displayTime = (empty($isalluse)) ? "" : "display:none";
            
            $displayRank2 = "display:none";
            $displayRank3 = "display:none";
            $displayRank4 = "display:none";
            $displayRank5 = "display:none";
            $displayRank6 = "display:none";
            
            $rankcount = $luckywheel['rankcount'];
                    
            if( $rankcount > 1 )
                $displayRank2 = "";
            
            if( $rankcount > 2 )
                $displayRank3 = "";
            
            if( $rankcount > 3 )
                $displayRank4 = "";
            
            if( $rankcount > 4 )
                $displayRank5 = "";
            
            if( $rankcount > 5 )
                $displayRank6 = "";
            
            $this->assign('isalluse',   $isalluse);
            $this->assign('displayTime', $displayTime );
            $this->assign('displayRank2', $displayRank2 );
            $this->assign('displayRank3', $displayRank3 );
            $this->assign('displayRank4', $displayRank4 );
            $this->assign('displayRank5', $displayRank5 );
            $this->assign('displayRank6', $displayRank6 );
            $this->assign('info', $luckywheel); 
            $this->assign('coupons', $coupons); 
            $this->display('luckywheel_edit');
        }
    }
    
    public function luckywheelDelete( )
    {
        if( IS_POST )
        {
            $id = I('id');
            
            $luckywheel_db = D('Common/LuckyWheel');
            $coupon_db = D('Common/Coupon');
            
            $luckywheel = $luckywheel_db->where(array('lwid'=>$id))->find();
            
            if( !empty($luckywheel['rank_cpid1']) )
                $coupon_db->SetDefaultGetType($luckywheel['rank_cpid1']);
            
            if( !empty($luckywheel['rank_cpid2']) )
                $coupon_db->SetDefaultGetType($luckywheel['rank_cpid2']);
            
            if( !empty($luckywheel['rank_cpid3']) )
                $coupon_db->SetDefaultGetType($luckywheel['rank_cpid3']);
            
            if( !empty($luckywheel['rank_cpid4']) )
                $coupon_db->SetDefaultGetType($luckywheel['rank_cpid4']);
            
            if( !empty($luckywheel['rank_cpid5']) )
                $coupon_db->SetDefaultGetType($luckywheel['rank_cpid5']);
            
            if( !empty($luckywheel['rank_cpid6']) )
                $coupon_db->SetDefaultGetType($luckywheel['rank_cpid6']);
            
            $result = $luckywheel_db->where(array('lwid'=>$id))->save(array('isdelete'=>1));
            
            if ($result){
                $this->success('删除成功');
            }else {
                $this->error('删除失败');
            }
        }
    }
    
    public function couponlist($page = 1, $rows = 10, $sort = 'cp_id', $order = 'desc')
    {
        if(IS_POST){
            $coupon_db = D('Common/coupon');
            $total = $coupon_db->where(array('isdelete' => 0))->count();
            $first = ($page - 1) * $rows;
            $list = $total ? $coupon_db->GetItems($sort, $order, $first, $rows) : array();
            foreach($list as &$info){
                $info['cp_maxcount']  = $info['cp_maxcount'] ?  $info['cp_maxcount'] : '无限定';
                $info['createtime']   = $info['createtime'] ? date('Y-m-d H:i:s', $info['createtime']) : '-';
                $info['cp_starttime'] = $info['cp_starttime'] ? date('Y-m-d H:i:s', $info['cp_starttime']) : '-';
                $info['cp_endtime']   = $info['cp_endtime'] ? date('Y-m-d H:i:s', $info['cp_endtime']) : '-';
                $info['cp_gettype']   = CouponModel::GetTypeString($info['cp_gettype']);
             }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                    'title'   => $currentpos,
                    'url'     => U('Weixin/couponlist', array('grid'=>'datagrid')),
                    'toolbar' => 'couponModule.toolbar',
                ),
                'fields' => array(
                    '生成时间'     => array('field'=>'createtime','width'=>50,'sortable'=>true),                   
                    '名称'         => array('field'=>'cp_title','width'=>50,'sortable'=>true),
                    '发行数量'     => array('field'=>'cp_maxcount','width'=>50,'sortable'=>true),
                    '说明'         => array('field'=>'cp_description','width'=>50,'sortable'=>true),                        
                    '面额'         => array('field'=>'cp_price','width'=>50,'sortable'=>true),  
                    /* '积分'         => array('field'=>'cp_jifen','width'=>50,'sortable'=>true), */ 
                    '领取类型'   => array('field'=>'cp_gettype','width'=>25,'sortable'=>true),
                    '使用开始时间' => array('field'=>'cp_starttime','width'=>50,'sortable'=>true),                        
                    '使用完了时间' => array('field'=>'cp_endtime','width'=>50,'sortable'=>true),
                    '可取得数量'   => array('field'=>'cp_possiblecount','width'=>50,'sortable'=>true),
                    '管理操作'     => array('field'=>'cp_id','width'=>25,'formatter'=>'couponModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('couponlist');
        }
    }
    
    public function couponAdd()
    {
        if(IS_POST){
            $coupon_db = D('Common/coupon');
            $data = I('post.info');
            
            $title      = $data['cp_title'];
            $price      = $data['cp_price'];
            $maxcount   = $data['cp_maxcount'];
            $nochkprice = $data['cp_nochkorderprice'];
            $matchprice = $data['cp_match_overorderprice'];
            $description = $data['cp_description'];
            $gettype    = $data['cp_gettype'];
            $isalluse   = $data['cp_alluse'];
            $starttime  = $data['cp_starttime'];
            $endtime    = $data['cp_endtime'];
            $possiblecount = $data['cp_possiblecount'];
            $now = time();
            
            // old coupon
            $oldcoupon = $coupon_db->where(array('cp_title'=>$data['cp_title'], 'isdelete'=>0 ))->find();
            
            if( !empty($oldcoupon) )
            {
                $this->error('优惠券名已存在');
                return;
            }
            
            // time check
            if( $isalluse == 'true' || $isalluse=='1' || $isalluse == true || $isalluse == 1 || $isalluse == 'on')
            {
                $starttime = 0;
                $endtime = 0;
            }
            else
            {
                $starttime = strtotime( $starttime . ' 00:00:00' );
                $endtime = strtotime( $endtime . ' 23:59:59' );
                
                if( $starttime > $endtime )
                {
                    $this->error('开始时间不可能超过结束时间');
                    return;
                }
                
                if( $endtime < $now )
                {
                    $this->error('结束时间已经过了');
                    return;
                }
            }            
            
            if( $nochkprice == 'true' || $nochkprice=='1' || $nochkprice == true || $nochkprice == 1 || $nochkprice == 'on')
            {
                $matchprice = 0;
            }
            
            $result = $coupon_db->add(array( 'cp_title'  => $title
                    , 'cp_price'    =>  $price
                    , 'cp_maxcount' =>  $maxcount
                    , 'cp_match_overorderprice' => $matchprice
                    , 'cp_description'  => $description
                    , 'cp_gettype'      => $gettype
                    , 'cp_starttime'    => $starttime
                    , 'cp_endtime'      => $endtime
                    , 'cp_possiblecount' => $possiblecount
                    , 'createtime'  =>  $now ));
            
            if( $result )
            {
                $this->success('发布成功');
            }
            else
            {
                $this->error('发布失败');
            }
        }
        else
        {
            $this->display('coupon_add');
        }
    }
    
    public function couponEdit($id)
    {        
        if( IS_POST )
        {
            $data = I('post.info');
            
            $title          = $data['cp_title'];
            $price          = $data['cp_price'];
            $maxcount       = $data['cp_maxcount'];
            $description    = $data['cp_description'];
            $gettype        = $data['cp_gettype'];
            $isalluse       = $data['cp_alluse'];
            $starttime      = $data['cp_starttime'];
            $endtime        = $data['cp_endtime'];
            $possiblecount  = $data['cp_possiblecount'];
            $nochkprice     = $data['cp_nochkorderprice'];
            $matchprice     = $data['cp_match_overorderprice'];
            
            $jifen          = 0; //$data['cp_jifen'];
            $overprice      = $data['cp_overorderprice'];
            /*
            $luckywheelid   = $data['cp_luckywheelid'];
            $luckywheelrank = $data['cp_luckywheelrank'];
            $wzid           = $data['cp_wzid'];
            $qsid           = $data['cp_qsid'];
            */
            
            // time check
            if( $isalluse == 'true' || $isalluse=='1' || $isalluse == true || $isalluse == 1 || $isalluse == 'on')
            {
                $starttime = 0;
                $endtime = 0;
            }
            else
            {
                $starttime = strtotime( $starttime . ' 00:00:00' );
                $endtime = strtotime( $endtime . ' 23:59:59' );
                
                if( $starttime > $endtime )
                {
                    $this->error('开始时间不可能超过结束时间');
                    return;
                }
                
                if( $endtime < $now )
                {
                    $this->error('结束时间已经过了');
                    return;
                }
            }         
            
            if( $nochkprice == 'true' || $nochkprice=='1' || $nochkprice == true || $nochkprice == 1 || $nochkprice == 'on')
            {
                $matchprice = 0;
            }
            
            $coupon_db = D('Common/Coupon');
            $result = $coupon_db->where(array('cp_id'=>$id))->save(
                        array(
                              'cp_price'=>$price
                            , 'cp_maxcount'=>$maxcount
                            , 'cp_match_overorderprice' => $matchprice
                            , 'cp_description'=>$description
                            , 'cp_gettype'=>$gettype
                            , 'cp_starttime'=>$starttime
                            , 'cp_endtime'=>$endtime
                            , 'cp_possiblecount'=>$possiblecount
                        )
                    );
            
            if( $result )
            {
                $this->success('修改成功');
            }
            else
            {
                $this->success('修改失败');
            }
        }
        else
        {
            $coupon_db = D('Common/Coupon');
            $luckywheel_db = D('Common/LuckyWheel');
            $qiandaosetting_db = D('Common/QiandaoSetting');
            $weizhuli_db = D('Common/WxZhuli');
            $coupon = $coupon_db->where(array('cp_id'=>$id))->find();
            
            $lwObj = $luckywheel_db->where(array(''=>$coupon['cp_luckywheelid']))->find();
            $wzObj = $weizhuli_db->where(array(''=>$coupon['cp_wzid']))->find();
            $qsObj = $qiandaosetting_db->where(array(''=>$coupon['cp_qsid']))->find();
            
            if( !empty($lwObj))
                $coupon['cp_luckywheelid'] = $lwObj['lwname'];
            
            if( !empty($wzObj))
                $coupon['cp_wzid'] = $lwObj['wz_name'];
            
            if( !empty($qsObj))
                $coupon['cp_qsid'] = $qsObj['qs_name'];
            
            $isalluse = (( $coupon['cp_starttime'] == 0 ) &&( $coupon['cp_endtime'] == 0 )) ? 'checked' : '';           
            $isnochkorderprice = ( $coupon['cp_match_overorderprice'] == 0 ) ? 'checked' : '';
            $gettypename = CouponModel::GetTypeString($coupon['cp_gettype']);
            
            $displayOrder       = "display:none";
            $displayLuckyWheel  = "display:none";
            $displayWeizhuli    = "display:none";
            $displayQiandao     = "display:none";
            $displayMatchOverOrder = "display:none";
            $displayUsetime     = "display:none";
            $displayGetCount    = "";
            
            if( empty($isalluse) )
            {
                $displayUsetime = "";
            }
            
            if( empty($isnochkorderprice) ) 
            {
                $displayMatchOverOrder = "";
            }
            
            $gettype = intval($coupon['cp_gettype']);
            switch( $gettype )
            {
                case CouponModel::GETTYPE_OVERORDER:
                    $displayOrder = "";
                    break;
                case CouponModel::GETTYPE_LUCKYWHEEL:
                    $displayLuckyWheel = "";
                    $displayGetCount    = "display:none";
                    break;
                case CouponModel::GETTYPE_WEIZHULI:
                    $displayWeizhuli = "";
                    $displayGetCount    = "display:none";
                    break;
                case CouponModel::GETTYPE_QIANDAO:
                    $displayQiandao = "";
                    $displayGetCount    = "display:none";
                    break;
            }
            
            $this->assign( 'isalluse',          $isalluse );
            $this->assign( 'isnochkorderprice', $isnochkorderprice );
            $this->assign( 'gettypename',       $gettypename );
            $this->assign( 'displayUsetime',    $displayUsetime );
            $this->assign( 'displayOrder',      $displayOrder );
            $this->assign( 'displayLuckyWheel', $displayLuckyWheel );
            $this->assign( 'displayWeizhuli',   $displayWeizhuli );
            $this->assign( 'displayQiandao',    $displayQiandao );  
            $this->assign( 'displayMatchOverOrder', $displayMatchOverOrder );  
            
            $this->assign( 'info',              $coupon );
            
            $this->display('coupon_edit');
        }
    }
    
    public function couponDelete( )
    {
        if( IS_POST )
        {
            $id = I('id');
            
            $coupon_db = D('Common/Coupon');
            $result = $coupon_db->where(array('cp_id'=>$id))->save(array('isdelete'=>1));
            
            if ($result){
                $this->success('删除成功');
            }else {
                $this->error('删除失败');
            }
        }
    }
    
    public function QiandaoSetting(){
        if(IS_POST){
            $data = I('post.info');
            $wxqiandao_db = D('Common/QiandaoSetting');
            $coupon_db = D('Common/Coupon');
            
            $old = $wxqiandao_db->where(array('qsid'=>1))->find();
            $coupon_db->SetDefaultGetType( $old['cp_id'] );
            $coupon_db->SetQiandaoGetType( $data['cp_id'], 1 );
            
            $wxqiandao_db->where(array('qsid'=>1))->save($data);
            $this->success('设定签到功能成功');
        }
        else
        {
            $wxqiandao_db = D('Common/QiandaoSetting'); 
            $coupon_db = D('Common/Coupon');
            $info = $wxqiandao_db->where(array('qsid'=>1))->find();
            
            $coupons = $coupon_db->where(array( 'isdelete'=>0
                            , 'cp_luckywheelid'=>0
                            , 'cp_wzid'=>0
                            , 'cp_qsid'=>array('in', array(0, 1)) 
                        ))->order('cp_id desc')->limit(26)->select();
            
            $this->assign('sel_cp_id', $info['cp_id']);
            $this->assign('info', $info);
            $this->assign('coupons', $coupons);
            $this->display('qiandao_setting');
        }
    }
    
    public function QiandaoList($page = 1, $rows = 20, $sort = 'check_time', $order = 'desc')
    {
        if(IS_POST){
            $qiandao_db = D('Common/Qiandao');
            
            $total = $qiandao_db->GetCount();
            $first = ($page - 1) * $rows;
            $list = $total ? $qiandao_db->GetItems($sort, $order, $first, $rows) : array();            
            
            foreach($list as &$info){
                if($info['seasonend'] == 1)
                {
                    $info['qs_name'] = $info['qs_name'] . "(已结束)";
                }
                
                $info['check_time']   = $info['check_time'] ? date('Y-m-d', $info['check_time']) : '-';
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/QiandaoList', array('grid'=>'datagrid')),
                        'toolbar' => 'wxQiandaoModule.toolbar',
                ),
                'fields' => array(
                        '会员名称'    => array('field'=>'u_name','width'=>50,'sortable'=>true),
                        '签到名称'    => array('field'=>'qs_name','width'=>50,'sortable'=>true),
                        '签到天'  => array('field'=>'check_time','width'=>50,'sortable'=>true),
                        '签到数'  => array('field'=>'check_count','width'=>50,'sortable'=>true),
                        '优惠券'  => array('field'=>'cp_title','width'=>25,'sortable'=>true),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('qiandaolist');
        }
    }
    
    public function SurveyDelete()
    {
        if( IS_POST )
        {
            $id = I('id');
            
            $survey_db = D('Common/Survey');
            $result = $survey_db->where(array('sv_id'=>$id))->save(array('isdelete'=>1));
            
            if ($result){
                $this->success('删除成功');
            }else {
                $this->error('删除失败');
            }
        }
    }
    
    public function SurveyAdd()
    {
        if(IS_POST){
            $paramSurvey = I('post.info');
            $paramQuestions = I('post.question');
            $paramQuestionItemsList = I('post.questionitem');
            
            // check survey item
            $sv_name        = $paramSurvey['sv_name'];
            $sv_description = $paramSurvey['sv_description'];
            $sv_starttime   = $paramSurvey['sv_starttime'];
            $sv_endtime     = $paramSurvey['sv_endtime'];
            
            
            $sv_question  = array();
            
            foreach( $paramQuestions as $i=>$paramQuestion )
            {
                $sv_questionItems = array();

                if( empty($paramQuestion['type']))
                    $paramQuestion['type'] = "0";

                $paramQuestionItems = $paramQuestionItemsList[$i];
                foreach( $paramQuestionItems as $paramQuestionItem )
                {   
                    $sv_questionItems[] = $paramQuestionItem;
                }
                $sv_question[$i] = array( 'question'=>$paramQuestion, 'questionItem'=>$sv_questionItems ) ;                
            }
            
            $result = false;
            
            $db_survey = D('Common/Survey');
            $db_question = D('Common/SvQuestion');
            $db_questionitem = D('Common/SvQuestionItem');
            
            try
            {
                $db_survey->startTrans();
                
                $surveyId = $db_survey->add(array( 'sv_name'=>$sv_name
                        , 'sv_description'=>$sv_description
                        , 'sv_starttime'=>strtotime($sv_starttime . ' 00:00:00')
                        , 'sv_endtime'=>strtotime($sv_endtime . ' 23:59:59')
                    ));
                
                if( $surveyId <= 0)
                {
                    $db_survey->rollback();
                    $this->error('发布失败');
                    return;
                }
                
                foreach( $sv_question as $question )
                {
                    $sq_name = $question['question']['name'];
                    $sq_type = $question['question']['type'];
                    
                    $sq_id = $db_question->add( array(
                                'sv_id' =>$surveyId
                              , 'sq_name'=>$sq_name
                              , 'sq_type'=>$sq_type      
                            ));
                    
                    if( $sq_id <= 0)
                    {
                        $db_survey->rollback();
                        $this->error('发布失败');
                        return;
                    }
                    
                    $sq_items = $question['questionItem'];
                    foreach( $sq_items as $sq_item )
                    {
                        $si_id = $db_questionitem->add(array('sq_id'=>$sq_id, 'si_item'=>$sq_item));
                        
                        if( $si_id <= 0)
                        {
                            $db_survey->rollback();
                            $this->error('发布失败');
                            return;
                        }
                    }
                }
                
                $db_survey->commit();
                $result = true;
            }
            catch(Exception $ex)
            {
                $db_survey->rollback();
            }
            
            if( $result )
            {
                $this->success('发布成功');
            }
            else
            {
                $this->error('发布失败');
            }
        }
        else
        {
            $this->display('survey_add');
        }
    }
    
    public function SurveyEdit($id)
    {
        $db_survey = D('Common/Survey');
        $db_question = D('Common/SvQuestion');
        $db_questionitem = D('Common/SvQuestionItem');
            
        if(IS_POST){            
            $paramSurvey = I('post.info');
            $paramQuestions = I('post.question');
            $paramQuestionItemsList = I('post.questionitem');            
            $result = false;            
            try
            {
                $db_survey->startTrans();
                
                $db_survey->where(array('sv_id'=>$id))->save(
                            array( 'sv_name'=>$paramSurvey['sv_name']
                                , 'sv_description'=>$paramSurvey['sv_description']
                                , 'sv_starttime'=>strtotime($paramSurvey['sv_starttime'] . ' 00:00:00')
                                , 'sv_endtime'=>strtotime($paramSurvey['sv_endtime'] . ' 23:59:59')
                            ));
                
                foreach($paramQuestions as $question )
                {
                    $sq_name = $question['name'];
                    $sq_type = 0;
                    if( !empty($question['type']))
                        $sq_type = $question['type'];
                    
                    $db_question->where( array('sq_id'=>$question['id']))->save(array('sq_name'=>$sq_name, 'sq_type'=>$sq_type));
                }
                
                foreach($paramQuestionItemsList as $questionItems )
                {
                    foreach( $questionItems as $item)
                    {
                        $si_id = $item['id'];
                        $si_item = $item['text'];                        
                        $db_questionitem->where( array('si_id'=>$item['id']))->save(array('si_item'=>$si_item));
                    }
                }
                
                $db_survey->commit();
                $result = true;
            }
            catch(Exception $ex)
            {
                $db_survey->rollback();
            }
            
            if( $result )
            {
                $this->success('修改成功');
            }
            else
            {
                $this->error('修改失败');
            }            
        }
        else
        {
            $survey = $db_survey->where(array('sv_id'=>$id, 'isdelete'=>0))->find();
            $svquestions = $db_question->where( array('sv_id'=>$id, 'isdelete'=>0))->select();
            
            $question = array();
            $questionitems = array();            
            for( $i = 0 ; $i < 5; $i++ )
            {
                $sq_id = 0;
                $sq_name = '';
                $sq_display = 'display:none';
                $sq_type = '';
                
                // Get Question info -- begin --
                if( count($svquestions) > $i )
                {
                    $sq_id = $svquestions[$i]['sq_id'];
                    $sq_name = $svquestions[$i]['sq_name'];
                    $sq_type = $svquestions[$i]['sq_type'];                    
                }
                
                if( !empty($sq_type) )
                {
                    $sq_type = "checked";
                }
                
                if( !empty($sq_name) )
                {
                    $sq_display = '';
                }
                
                $question[$i] = array('id'=>$sq_id, 'name'=>$sq_name, 'type'=>$sq_type, 'display'=>$sq_display ); 
                // Get Question info -- end --
                
                // Get Question Items -- begin --
                $tempQuestionItems = array();
                $sq_items = array();
                if( !empty($sq_id) )
                {
                    $sq_items = $db_questionitem->where(array('sq_id'=>$sq_id))->select();
                }               
                
                for( $j=0; $j < 10; $j++ )
                {
                    $sqitem_id = 0;
                    $sqitem_text = '';
                    $sqitem_display = 'display:none';
                    
                    if( count($sq_items) > $j )
                    {
                        $sqitem_id = $sq_items[$j]['si_id'];
                        $sqitem_text = $sq_items[$j]['si_item'];
                        
                        if( !empty($sqitem_text) )
                        {
                            $sqitem_display = '';
                        }
                    }
                    
                    $tempQuestionItems[$j] = array('id'=>$sqitem_id, 'text'=>$sqitem_text, 'display'=>$sqitem_display );
                }                
                $questionitems[$i] = $tempQuestionItems;                
            }
            
            $survey['sv_starttime'] = date('Y-m-d', intval($survey['sv_starttime']) );
            $survey['sv_endtime'] = date('Y-m-d', intval($survey['sv_endtime']) );
            
            $this->assign( 'info',          $survey );            
            $this->assign( 'question',      $question );
            $this->assign( 'questionitem',  $questionitems );            
            $this->display('survey_edit');
        }
    }
    
    public function SurveyList($page = 1, $rows = 20, $sort = 'createtime', $order = 'desc')
    {
        if(IS_POST){
            $survey_db = D('Common/Survey');
            
            $total = $survey_db->GetCount();
            $first = ($page - 1) * $rows;
            $list = $total ? $survey_db->GetItems($sort, $order, $first, $rows) : array();            
            
            foreach($list as &$info){
                $info['sv_starttime'] = $info['sv_starttime'] ? date('Y-m-d', $info['sv_starttime']) : '-';
                $info['sv_endtime']   = $info['sv_endtime'] ? date('Y-m-d', $info['sv_endtime']) : '-';
                $info['sv_usercount'] = $info['sv_usercount']? $info['sv_usercount'] : 0;
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/SurveyList', array('grid'=>'datagrid')),
                        'toolbar' => 'surveyModule.toolbar',
                ),
                'fields' => array(
                        '调研标题'  => array('field'=>'sv_name','width'=>50,'sortable'=>true),
                        '介绍'      => array('field'=>'sv_description','width'=>50,'sortable'=>true),
                        '开始时间'  => array('field'=>'sv_starttime','width'=>50,'sortable'=>true),
                        '过期时间'  => array('field'=>'sv_endtime','width'=>50,'sortable'=>true),
                        '参与人数'  => array('field'=>'sv_usercount','width'=>25,'sortable'=>true),
                        '管理操作'     => array('field'=>'sv_id','width'=>25,'formatter'=>'surveyModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('survey_list');
        }
    }
    
    public function wxzhuliDelete()
    {
        if( IS_POST )
        {
            $id = I('id');
            
            $wxzhuli_db = D('Common/WxZhuli');
            $result = $wxzhuli_db->where(array('wzid'=>$id))->save(array('isdelete'=>1));
            
            if ($result){
                $this->success('删除成功');
            }else {
                $this->error('删除失败');
            }
        }
    }
    
    public function wxzhuliAdd()
    {
        if(IS_POST){
            
            $info = I('post.info');
            
            $db_wxzhuli = D('Common/WxZhuli');
                
            $result = $db_wxzhuli->add(array( 'wz_name'=>$info['wz_name']
                        , 'wz_description'=>$info['wz_description']
                        , 'wxcdid'=>$info['wxcdid']
                        , 'wz_rank'=>$info['wz_rank']
                        , 'wz_sharetitle'=>$info['wz_sharetitle']
                        , 'wz_sharedescription'=>$info['wz_sharedescription']
                        , 'wz_starttime'=>strtotime($info['wz_starttime'] . ' 00:00:00')
                        , 'wz_endtime'=>strtotime($info['wz_endtime'] . ' 23:59:59')
                    ));
            
            if( $result )
            {
                $this->success('添加成功');
            }
            else
            {
                $this->error('添加失败');
            }
        }
        else
        {
            $db_contentdetail = D('Common/WxContentDetail');
            $list = $db_contentdetail->where(array('isdelete'=>0))->select();
            
            $this->assign('contents', $list);
            $this->display('wxzhuli_add');
        }
    }
    
    public function wxzhuliEdit($id)
    {            
        if(IS_POST){
            $info = I('post.info');
            $db_wxzhuli = D('Common/WxZhuli');
                
            $result = $db_wxzhuli->where(array('wzid'=>$id))->save(array( 'wz_name'=>$info['wz_name']
                        , 'wz_description'=>$info['wz_description']
                        , 'wxcdid'=>$info['wxcdid']
                        , 'wz_rank'=>$info['wz_rank']
                        , 'wz_sharetitle'=>$info['wz_sharetitle']
                        , 'wz_sharedescription'=>$info['wz_sharedescription']
                        , 'wz_starttime'=>strtotime($info['wz_starttime'] . ' 00:00:00')
                        , 'wz_endtime'=>strtotime($info['wz_endtime'] . ' 23:59:59')
                    ));
            
            if( $result )
            {
                $this->success('修改成功');
            }
            else
            {
                $this->error('修改失败');
            }
        }
        else
        {   
            $db_wxzhuli = D('Common/WxZhuli');
            $db_contentdetail = D('Common/WxContentDetail');
            
            $list = $db_contentdetail->where(array('isdelete'=>0))->select();
            $info = $db_wxzhuli->where(array('wzid'=>$id))->find();
            
            $info['wz_starttime'] = $info['wz_starttime'] ? date('Y-m-d', $info['wz_starttime']) : '-';
            $info['wz_endtime']   = $info['wz_endtime'] ? date('Y-m-d', $info['wz_endtime']) : '-';
            
            $wxcdid = $info['wxcdid'];
            
            $this->assign( 'contents', $list );
            $this->assign( 'info',    $info );
            $this->assign( 'wxcdid',  $wxcdid );
            $this->display('wxzhuli_edit');
        }
    }
    
    public function wxzhuli($page = 1, $rows = 20, $sort = 'createtime', $order = 'desc')
    {
        if(IS_POST){
            $wxzhuli_db = D('Common/WxZhuli');
            
            $total = $wxzhuli_db->GetCount();
            $first = ($page - 1) * $rows;
            $list = $total ? $wxzhuli_db->GetItems($sort, $order, $first, $rows) : array();            
            
            foreach($list as &$info){
                $info['wz_starttime'] = $info['wz_starttime'] ? date('Y-m-d', $info['wz_starttime']) : '-';
                $info['wz_endtime']   = $info['wz_endtime'] ? date('Y-m-d', $info['wz_endtime']) : '-';
                
            }
            $data = array('total'=>$total, 'rows'=>$list);
            $this->ajaxReturn($data);
        }
        else
        {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'title'   => $currentpos,
                        'url'     => U('Weixin/wxzhuli', array('grid'=>'datagrid')),
                        'toolbar' => 'wxzhuliModule.toolbar',
                ),
                'fields' => array(
                        '名称'  => array('field'=>'wz_name','width'=>50,'sortable'=>true),
                        '说明'      => array('field'=>'wz_description','width'=>50,'sortable'=>true),
                        '开始时间'  => array('field'=>'wz_starttime','width'=>50,'sortable'=>true),
                        '结束时间'  => array('field'=>'wz_endtime','width'=>50,'sortable'=>true),
                        '管理操作'     => array('field'=>'wzid','width'=>25,'formatter'=>'wxzhuliModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxzhuli');
        }
    }
    
    public function wxpageIndex() {
        $menu_db = D('Common/Menu');
        $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
        $this->assign(currentpos, $currentpos);
        $this->display('wxpage_index');
    }
    
    public function wxpageDelete()
    {
        if( IS_POST )
        {
            $id = I('id');
            
            $wxpage_db = D('Common/WxPage');
            $result = $wxpage_db->where(array('wxpid'=>$id))->save(array('isdelete'=>1));
            
            if ($result){
                $this->success('删除成功');
            }else {
                $this->error('删除失败');
            }
        }
    }
    
    public function wxpageAdd() {
        
        if(IS_POST){
            if(I('get.dosubmit')){
                $wxpage_db = D('Common/WxPage');
                $data = I('post.info', array(), 'trim');
                if(!$data['wxp_name'] || !$data['content']) $this->error('请填写必填字段');

                if($wxpage_db->exist_name($data['wxp_name'])) {
                    $this->error('添加失败。名称已存在。');
                }

                $html_filename = "/upload/weixin/site/wxpage_".date('Ymd-His').'.html';
                $db_html_filename = "/upload/weixin/site/getcontent.php?content=wxpage_".date('Ymd-His').'.html';
                file_put_contents('Public'.$html_filename, $data['content'], LOCK_EX);

                $new_data = array();
                $new_data['wxp_name'] = $data['wxp_name'];
                $new_data['wxp_html'] = '/Public'.$db_html_filename;
                $bid = $wxpage_db->add($new_data);

                if($bid){
                    $this->success('添加成功');
                }else {
                    $this->error('添加失败');
                }
            } else {
              
            }
        }else{
            $this->display('wxpage_add');
        }
        
    }
    
    public function wxpageEdit( $wxpid ) {
        
        if (IS_POST) {
            
            $wxpage_db = D('Common/WxPage');
            $data = I('post.info', array(), 'trim');
            if(!$data['wxp_name'] || !$data['content']) $this->error('请填写必填字段');

            $html_filename = "/upload/weixin/site/wxpage_".date('Ymd-His').'.html';
            $db_html_filename = "/upload/weixin/site/getcontent.php?content=wxpage_".date('Ymd-His').'.html';
            file_put_contents('Public'.$html_filename, $data['content'], LOCK_EX);

            $new_data = array();
            $new_data['wxp_name'] = $data['wxp_name'];
            $new_data['wxp_html'] = '/Public'.$db_html_filename;
            $bid = $wxpage_db->where(array('wxpid'=>$wxpid))->save($new_data);

            if($bid){
                $this->success('编辑成功');
            }else {
                $this->error('编辑失败');
            }
        } else {
            
            $wxpage_db = D("Common/WxPage");

            $info = $wxpage_db->where(array('wxpid'=>$wxpid))->find();
            $detailurl = substr($info['wxp_html'], 1);
            $detailurl = str_replace('getcontent.php?content=', '', $detailurl);
            $contents = file_get_contents($detailurl);
            $info['wxp_html'] = htmlspecialchars_decode($contents);
            
            $this->assign( 'info',    $info );
            $this->display('wxpage_edit');
        }
    }
    
    public function wxpageList($page = 1, $rows = 10, $search = array(), $sort = 'wxpid', $order = 'desc') {
        
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        
        if (IS_POST) {
            $db_wxpage = D('Common/WxPage');
            $total = $db_wxpage->GetCount();

            $first = ($page - 1) * $rows;
            $list = $total ? $db_wxpage->GetItems( $sort, $order, $first, $rows ) : array();
            
            foreach( $list as &$item )
            {
                $pos = strpos( $item['wxp_html'] ,  "http://");                
                if( $pos === false )
                {
                    $item['wxp_html']  = $rooturl . $item['wxp_html'];
                }
            }

            $data = array('total' => $total, 'rows' => $list);
            $this->ajaxReturn($data);
        } else {
            $menu_db = D('Common/Menu');
            $currentpos = $menu_db->currentPos(I('get.menuid'));  //栏目位置
            $datagrid = array(
                'options'     => array(
                        'url'     => U('Weixin/wxpageList', array('grid'=>'datagrid')),
                        'toolbar' => 'wxpageModule.toolbar',
                ),
                'fields' => array(
                        '名称'  => array('field'=>'wxp_name','width'=>10,'sortable'=>true),
                        'URL'   => array('field'=>'wxp_html','width'=>50,'sortable'=>true),                      
                        '管理操作'     => array('field'=>'wxpid','width'=>25,'formatter'=>'wxpageModule.operate'),
                )
            );
            $this->assign('datagrid', $datagrid);
            $this->display('wxpage_list');
        }
    }
    
    public function wxPageCopyUrl($id)
    {
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $db_wxpage = D('Common/WxPage');
        $info = $db_wxpage->where(array('wxpid'=>$id))->find();
        
        // first set default url
        $pageurl = '';
        if( !empty($info))
        {
            $pos = strpos( $info['wxp_html'] ,  "http://");                
            if( $pos === false )
            {
                $info['wxp_html']  = $rooturl . $info['wxp_html'];
            }
            $pageurl = $info['wxp_html'];
        }
        
        $this->assign('wxpageurl', $pageurl );
        $this->display('wxpage_urlview');
    }
}