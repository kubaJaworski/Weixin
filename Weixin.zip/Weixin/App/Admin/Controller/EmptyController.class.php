<?php
namespace Admin\Controller;
use Admin\Controller\CommonController;

/**
 * 空模块，主要用于显示404页面，请不要删除
 * @author wangdong
 */
class EmptyController extends CommonController{}
