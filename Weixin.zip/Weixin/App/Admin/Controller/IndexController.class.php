<?php
namespace Admin\Controller;
use Admin\Controller\CommonController;
use Common\Model\OrderModel;

/**
 * 后台管理通用模块
 * @author wangdong
 */
class IndexController extends CommonController {
	/**
	 * 后台首页
	 */
	public function index(){
		$admin_db = D('Common/Admin');
		$menu_db  = D('Common/Menu');
		
		$userid     = session('userid');
		$userInfo  = $admin_db->getUserInfo($userid);    //获取用户基本信息
		$menuList = $menu_db->getMenu();                //头部菜单列表
		
                $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
		$this->assign('userInfo', $userInfo);
		$this->assign('menuList', $menuList);
                $this->assign('rooturl',  $rooturl);
		$this->display('index');
	}
	
	/**
	 * 用户登录
	 */
	public function login(){
		if (I('get.dosubmit')){
			$admin_db = D('Common/Admin');
			
			$username = I('post.username', '', 'trim') ? I('post.username', '', 'trim') : $this->error('用户名不能为空', HTTP_REFERER);
			$password = I('post.password', '', 'trim') ? I('post.password', '', 'trim') : $this->error('密码不能为空', HTTP_REFERER);
			//验证码判断
			$code = I('post.code', '', 'trim') ? I('post.code', '', 'trim') : $this->error('请输入验证码', HTTP_REFERER);
			if(!check_verify($code, 'admin')) $this->error('验证码错误！', HTTP_REFERER);
			
			if($admin_db->login($username, $password)){
				$this->success('登录成功', U('Index/index'));
			}else{
				$this->error($admin_db->error, HTTP_REFERER);
			}
		}else {
			$this->display();
		}
	}
	
	/**
	 * 退出登录
	 */
	public function logout() {
		session('userid', null);
		session('roleid', null);
		cookie('username', null);
		cookie('userid', null);
		
		$this->success('安全退出！', U('Index/login'));
	}
	
	/**
	 * 验证码
	 */
	public function code(){
		$verify = new \Think\Verify();
		$verify->useCurve = true;
		$verify->useNoise = false;
		$verify->bg = array(255, 255, 255);
		
		if (I('get.code_len')) $verify->length = intval(I('get.code_len'));
		if ($verify->length > 8 || $verify->length < 2) $verify->length = 4;
		
		if (I('get.font_size')) $verify->fontSize = intval(I('get.font_size'));
		
		if (I('get.width')) $verify->imageW = intval(I('get.width'));
		if ($verify->imageW <= 0) $verify->imageW = 130;
		
		if (I('get.height')) $verify->imageH = intval(I('get.height'));
		if ($verify->imageH <= 0) $verify->imageH = 50;

		$verify->entry('admin');
	}
	
	/**
	 * 左侧菜单
	 */
	public function public_menuLeft($menuid = 0) {
		$menu_db = D('Common/Menu');
		$datas = array();
		$list = $menu_db->getMenu($menuid);
		foreach ($list as $k=>$v){
			$datas[$k]['name'] = $v['name'];
			$son_datas = $menu_db->getMenu($v['id']);
			foreach ($son_datas as $k2=>$v2){
				$datas[$k]['son'][$k2]['text'] = $v2['name'];
				$datas[$k]['son'][$k2]['id']   = $v2['id'];
                                $url = U( $v2['c'].'/'.$v2['a'], array('menuid'=>$v2['id'], 'data'=>$v2['data']) );
				$datas[$k]['son'][$k2]['url'] = $url;
				$datas[$k]['son'][$k2]['iconCls'] = 'icons-application-application_go';
                                
                                $dataVal = $datas[$k]['son'][$k2];
                                $dataVal = null;
			}
		}
		$this->ajaxReturn($datas);
	}
	
	/**
	 * 后台欢迎页
	 */
	public function public_main(){
		$admin_db = D('Common/Admin');
		$userid   = session('userid');
		$userInfo = $admin_db->getUserInfo($userid);    //获取用户基本信息

		$admin_log = M('admin_log');
		$loginList = $admin_log->where(array('userid'=>$userid))->order("time desc")->limit(5)->select();

		$changFile  = SITE_DIR . DS . 'change.log';
		$changeList = array();
		if(file_exists($changFile)){
			$changeList = file($changFile);
		}
		
		$this->assign('changeList', $changeList);
		$this->assign('userInfo', $userInfo);
		$this->assign('loginList', $loginList);
		$this->display('main');
	}

	/**
	 * 服务器信息
	 */
	public function systemInfo(){
		$sysinfo = \Admin\Plugin\SysinfoPlugin::getinfo();
		$os = explode(' ', php_uname());
		//网络使用状况
		$net_state = null;
		if ($sysinfo['sysReShow'] == 'show' && false !== ($strs = @file("/proc/net/dev"))) {
			for ($i = 2; $i < count($strs); $i++) {
				preg_match_all("/([^\s]+):[\s]{0,}(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/", $strs[$i], $info);
				$net_state.="{$info[1][0]} : 已接收 : <font color=\"#CC0000\"><span id=\"NetInput{$i}\">" . $sysinfo['NetInput' . $i] . "</span></font> GB &nbsp;&nbsp;&nbsp;&nbsp;已发送 : <font color=\"#CC0000\"><span id=\"NetOut{$i}\">" . $sysinfo['NetOut' . $i] . "</span></font> GB <br />";
			}
		}

		$this->assign('sysinfo', $sysinfo);
		$this->assign('os', $os);
		$this->assign('net_state', $net_state);
		$this->display("systeminfo");
	}
	
	/**
	 * 更新后台缓存
	 */
	public function public_clearCatche(){
		$list = dict('', 'Cache');
		if(is_array($list) && !empty($list)){
			foreach ($list as $modelName=>$funcName){
				D($modelName)->$funcName();
			}
		}
		$this->success('缓存更新成功');
	}
	
	/**
	 * 防止登录超时
	 */
	public function public_sessionLife(){
		$userid = session('userid');
		//单点登录判断
		if(C('LOGIN_ONLY_ONE')){
			if(session_id() != S('SESSION_ID_' . $userid)){
				$this->error('帐号已在其他地方登录，您已被迫下线！', U('Index/logout'));
			}
		}
		$this->success('正常登录');
	}

	public function checkorder(){
		$uid = I('post.uid');
		$roleid = I('post.roleid');		
		$order_db = M('Order');		
		$time = time() - 7200;
                
                $status_pay         = OrderModel::STATUS_PAYED;
                $status_later       = OrderModel::STATUS_PAY_LATER;
                $status_processing  = OrderModel::STATUS_PROCESSING;
                $status_shipping    = OrderModel::STATUS_SHIPPING;
                $status_req         = OrderModel::STATUS_RETURN_REQ;
		
                $sql1 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                        . $status_pay . ", " . $status_later . " ) " 
                        . " and reservetime <= " . $time;
                $sql2 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                        . $status_processing . ", "  . $status_shipping . " ) " 
                        . " and reservetime <= " . $time;
                $sql3 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                        . $status_req . " ) " 
                        . " and reservetime <= " . $time;
		
		$result1 = $order_db->query($sql1);
		$result2 = $order_db->query($sql2);
		$result3 = $order_db->query($sql3);
		$mes = array('order' => $result1[0]['num'], 'processing' =>$result2[0]['num'],'returnreq'=>$result3[0]['num']);
		echo json_encode($mes);
	}
        
	public function checkneworder(){
		$uid = I('post.uid');
		$roleid = I('post.roleid');		
		$order_db = M('Order');		
		$time = time() - 300;
                
                $status_pay = OrderModel::STATUS_PAYED;
                $status_later = OrderModel::STATUS_PAY_LATER;
                $status_processing  = OrderModel::STATUS_PROCESSING;
                $status_shipping    = OrderModel::STATUS_SHIPPING;
                $status_ready = OrderModel::STATUS_READY;
                
                $setting_db = D('Common/SystemSetting');
                $old_max_oid = $setting_db->GetSettingValue('max_order_id');
                $new_max_oid = 0;
                if ($order_db->count() > 0) {
                    $new_max_oid = $order_db->max('oid');
                }
                
                if ($new_max_oid != $old_max_oid) {
                    $setting_db->SetSettingValue('max_order_id', $new_max_oid);
                    
                    $sql1 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                            . $status_pay . " ) " 
                            . " and oid > " . $old_max_oid;
                    $sql2 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                            . $status_later . " ) " 
                            . " and oid > " . $old_max_oid;
                    $sql3 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                            . $status_processing . " ) " 
                            . " and oid > " . $old_max_oid;
                    $sql4 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                            . $status_shipping . " ) " 
                            . " and oid > " . $old_max_oid;
                    $sql5 = "SELECT COUNT(*) as num FROM app2_order WHERE isdelete = 0 AND orderstatus in (" 
                            . $status_ready . " ) " 
                            . " and oid > " . $old_max_oid;
                    $result1 = $order_db->query($sql1);
                    $result2 = $order_db->query($sql2);
                    $result3 = $order_db->query($sql3);
                    $result4 = $order_db->query($sql4);
                    $result5 = $order_db->query($sql5);
                    $total = $result1[0]['num'] + $result2[0]['num'] + $result3[0]['num'] + $result4[0]['num'] + $result5[0]['num'];
                    
                    $mes = array('order' => $total,'payed' => $result1[0]['num'],'pay_later' =>$result2[0]['num'],'processing'=>$result3[0]['num'],'shipping'=>$result4[0]['num'],'ready'=>$result5[0]['num']);
                } else {
                    $mes = array('order' => 0);
                }
		echo json_encode($mes);
	}        
}