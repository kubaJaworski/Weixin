<?php
namespace Home\Controller;
use Home\Controller\CommonController;

/**
 * 空模块，主要用于显示404页面，请不要删除
 */
class EmptyController extends CommonController{}
