<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/11/9
 * Time: 15:05
 */

namespace Home\Controller;
use Think\Controller;
use Think\Log;
use Common\Common\TheApp;
use Common\Common\TheWeixin;



class WechatController extends Controller
{
    private $theWeixin;
    
    public function __construct(){
        parent::__construct();
    }
    
    protected function InitWeixin()
    {
        if( $this->theWeixin == null )
        {
            $this->theWeixin = TheWeixin::CreateObject();
        }
    }

    public function index(){
        $echoStr = $_GET["echostr"];

        $post_data = $GLOBALS['HTTP_RAW_POST_DATA'];
        Log::record( '[ Weixin ] post raw data ' . $post_data );  
	
        $this->InitWeixin();
        
        Log::record( '[ Weixin ] echostr ' . $echoStr );  
        
        if(empty($echoStr))
        {
            $postData = @$GLOBALS['HTTP_RAW_POST_DATA'];
            if(!empty($postData)){
                $postObj = simplexml_load_string($postData, 'SimpleXMLElement', LIBXML_NOCDATA);
                $postArray =  json_decode(json_encode($postObj),1);

                Log::record( '[ Weixin ] xml paramter ' . var_dump_ret($postObj) );  

                $fromUserName = $postArray['FromUserName'];
                $toUserName = $postArray['ToUserName'];
                $eventKey = trim($postArray['EventKey']);
                $event = trim($postArray['Event']);

                $msgType = $postArray['MsgType'];
                $content = $postArray['Content'];

                if( !empty( $event ) )
                {
                    if( $event == "subscribe")
                    {
                        $resultStr = $this->theWeixin->eventSubscribe($fromUserName, $toUserName, $eventKey, $event, $msgType, $content);                        
                        echo $resultStr;
                    }
                    else if( $event == "CLICK")
                    {
                        $resultStr = $this->theWeixin->eventClick($fromUserName, $toUserName, $eventKey, $event, $msgType, $content);                        
                        echo $resultStr;
                    }
                    else if( $event == "unsubscribe")
                    {
                        $resultStr = $this->theWeixin->eventUnsubscribe($fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                        echo $resultStr;
                    }
                    else if ( $event == "SCAN")
                    {
                        $resultStr = $this->theWeixin->eventScan($fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                        echo $resultStr;
                    }
                    else
                    {
                        // echo $this->theWeixin->weChat->transmitToText(' Unknown Event Reply Yanjiao Online ', $toUserName, $fromUserName);
                        echo '';
                    }
                }
                else
                {

                    if( $msgType == "text" )
                    {
                        $resultStr = $this->theWeixin->eventText($fromUserName, $toUserName, $eventKey, $event, $msgType, $content);
                        echo $resultStr;                        
                    }                    
                }		
            }
            else
            {
                echo '';
                exit;                
            }
        }else{
            if(self::checkSignature()){
                echo $echoStr;
                exit;                
            }
        }
        exit;
    }

    private function checkSignature(){       
        if (empty($this->theWeixin->wx_app_token)) {
            throw new Exception('TOKEN is not defined!');
        }
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];
      
        $tmpArr = array($this->theWeixin->wx_app_token, $timestamp, $nonce);
        // use SORT_STRING rule
        sort($tmpArr, SORT_STRING);
        $tmpStr = implode( $tmpArr );
        $tmpStr = sha1( $tmpStr );

        if( $tmpStr == $signature ){
            return true;
        }
        return false;
    }

    public function getComponentAuth()
    {
        $post_data = $GLOBALS['HTTP_RAW_POST_DATA'];
        Log::record( '[ Weixin ] post raw data ' . $post_data );  
        echo $post_data;
        exit(0);
    }
    
    public function appBind(){
        try
        {
            $code = I('get.code');
            $state = I('get.state');
            $funcid = I('get.funcid');
            
            $this->InitWeixin();        
            $wxUserMes = $this->theWeixin->weChat->oAuthValidate($code);
            //Log::record( '[ Weixin ] wxUserMes ' . var_dump_ret($wxUserMes) );  
            $openid = $wxUserMes['openid'];
            session('openid', $openid);
            session('client', 'wx');
            
            $url = TheApp::GetFuncWeixinURL($funcid);
          
            $this->_Redirect( $url, array('openid'=>$openid));
        }
        catch(Exception $e)
        {
             Log::record( '[ Weixin ] appBind exception ' . var_dump_ret($e) );  
        }
    }
    
    public function _Redirect($url, $param)
    {
        $url    =   U($url);

        $paramstr = "?time=" .time();
        foreach ($param as $var => $val){
            if('' !== trim($val)) $paramstr .= '&' . $var . '=' . urlencode($val);
        } 
        $url = $url . $paramstr;

        redirect($url,0,'');
    }
}
