<?php
namespace Home\Controller;
use Home\Controller\CommonController;
use Service\Controller\ApiController;
use Common\Common\TheApp;
use Common\Model\OrderModel;
use Common\Model\TransactionModel;
use Common\Model\LuckyWheelModel;
use Common\Model\CouponModel;
use Think\Controller;
use Think\Log;

class IndexController extends CommonController {

    const DEBUG_TOKEN = '$$$';

    public function index() {
        $this->display('index');
    }

    private function bindBottomMenu() {
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $home_path = $rooturl . '/index.php/home/index/';
        $bottom_main = $rooturl . U('Home/index/main');
        $bottom_guoshi = $rooturl . U('Home/index/guoshui');
        $bottom_discovery = $rooturl . U('Home/index/discovery');
        $bottom_cart = $rooturl . U('Home/index/cart');
        $bottom_mycenter = $rooturl . U('Home/index/mycenter');

        $db_system_setting = D('Common/SystemSetting');
        $bottom_discovery = $db_system_setting->GetSettingValue('discovery_path', '');
       
        /**  inserted by ujh 2016.01.21  -- begin -- **/
        $isWxFan = 0;
        if( $this->IsWeixin() == true )
        {
            $isWxFan = 1;
        }
        
        $db_system_setting = D('Common/SystemSetting');
        $guanzhuurl = "http://mp.weixin.qq.com/s?__biz=MzA3NTgzNTkzMQ==&mid=400382467&idx=1&sn=e1414cd6bc0b2b218824869ebd8c0e6f#rd";
        
        $this->assign("guanzhuurl", $guanzhuurl);
        $this->assign("isWxFan", $isWxFan );
        /**  inserted by ujh 2016.01.21  -- end -- **/
        
        $this->assign('home_path', $home_path);
        $this->assign('bottom_main', $bottom_main);
        $this->assign('bottom_guoshi', $bottom_guoshi);
        $this->assign('bottom_discovery', $bottom_discovery);
        $this->assign('bottom_cart', $bottom_cart);
        $this->assign('bottom_mycenter', $bottom_mycenter);
    }

    /**  inserted by ujh 2016.01.21  -- begin -- **/ 
    
    // checkWeixinBrowser
    private function checkWeixin()
    {
        if(strpos($_SERVER["HTTP_USER_AGENT"],"MicroMessenger")){
            // is weixin     
            return true;
        }
        else
        {
            // no weixin
           // $this->display('warning');
           //  return false;
            return true;
        }
    }
    
    /**  inserted by ujh 2016.01.21  -- end -- **/ 

    public function main() {
        $this->checkWeixin();

        $this->GetLoginInfo();

        $db_banner_list = D('Common/Banner');
        $banners = $db_banner_list->field('sb_imageurl,sb_linktype,sb_funcid,sb_productid,sb_url')->where(array('sb_type'=>0))->order('disporder asc')->select();

        $db_system_setting = D('Common/SystemSetting');
        $yanjiaodongtai = $db_system_setting->GetSettingValue('app_url_yanjiaodongtai', 'http://yajol.com/wap/');
        $servicephone = $db_system_setting->GetSettingValue('app_service_phone', '4006020066');
        $onlinetalk_url = $db_system_setting->GetSettingValue('onlinetalk_url', '');
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $mydingdan = $rooturl . U('Home/index/mydingdan') . '?searchmode=0' ; 
        // news
        $db_news_list = M('news');
        $news = $db_news_list->field('n_type,n_text')->order('nid asc')->select();

        $db_homeblocks = D('Common/HomeBlocks');
        $blocks = $db_homeblocks->GetItems();

        $db_homebuttons = D('Common/HomeButton');
        $buttons = $db_homebuttons->GetItems();

        $buttons1 = array();
        $buttons2 = array();
        if (!empty($buttons)) {
            $cnt = 0;
            foreach ($buttons as $key => $item) {
                if ($cnt < 4) {
                    array_push($buttons1, $item);
                } else {
                    array_push($buttons2, $item);
                }
                $cnt++;
            }
        }

        $readycnt = 0;
        $processcnt = 0;
        $completecnt = 0;
        $cartprice = 0;
        if ($this->IsLogin()) {
            $db_order = D('Common/Order');
            $statuses = array(OrderModel::STATUS_READY);
            $readycnt = $db_order->GetCount($this->theUid, $statuses);
            $statuses = array(OrderModel::STATUS_PAYED, OrderModel::STATUS_PAY_LATER, OrderModel::STATUS_PROCESSING, OrderModel::STATUS_SHIPPING);
            $processcnt = $db_order->GetCount($this->theUid, $statuses);
            $statuses = array(OrderModel::STATUS_COMPLETE);
            $completecnt = $db_order->GetCount($this->theUid, $statuses);

            // get buscket
            $db_busket = D('Common/Basket');
            $cartprice = $db_busket->GetCartPrice($this->theUid);
        }

        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $this->assign('rooturl', $rooturl);
        $this->assign('homeurl', $rooturl . '/index.php/home/index/');
        $this->assign('client', $this->theClient);
        $this->assign('openid', $this->theOpenid);
        $this->assign('uid', $this->theUid);
        $this->assign('servicephone', $servicephone);
        $this->assign('yanjiaodongtai', $yanjiaodongtai);
        $this->assign('readycnt', $readycnt);
        $this->assign('processcnt', $processcnt);
        $this->assign('completecnt', $completecnt);
        $this->assign('cartprice', $cartprice);
        $this->assign('banners', $banners);
        $this->assign('onlinetalk_url', $onlinetalk_url);
        $this->assign('mydingdan', $mydingdan);
        
        $this->assign('blocks', $blocks);
        $this->assign('buttons', $buttons);
        $this->assign('buttons1', $buttons1);
        $this->assign('buttons2', $buttons2);
        $this->assign('news', $news);
        $this->assign('selectIndex', '1');
        
        // modified by ujh 2016.01.21
        $this->bindBottomMenu();
        $this->display('main');
    }

    public function mycenter() {
        $this->GetLoginInfo();
        $uid = $this->theUid;

        $this->InitApiController();
        $data = array('uid' => $uid, 'token' => self::DEBUG_TOKEN);

        $resp = $this->apiController->GetUserInfo($data);
        $resp = json_decode($resp);

        $this->assign('uid', $uid);
        $this->assign('data', $resp);

        $this->assign('selectIndex', '5');
        $this->bindBottomMenu();
        $this->display('mycenter');
    }

    
    

    public function Return_ZhifuBao() {
        //计算得出通知验证结果
        vendor('Alipay.Corefunction');
        vendor('Alipay.Rsafunction');
        vendor('Alipay.Notify');

        $resultValue = 0;
        // $alipayNotify = new AlipayNotify($alipay_config);
        // $verify_result = $alipayNotify->verifyNotify();        
        $verify_result = 1;
        if ($verify_result) {
            //商户订单号
            $out_trade_no = $_GET['out_trade_no'];

            //支付宝交易号
            $trade_no = $_GET['trade_no'];

            //交易状态
            $trade_status = $_GET['trade_status'];

            if ($_GET['trade_status'] == 'TRADE_FINISHED' || $_GET['trade_status'] == 'TRADE_SUCCESS') {
                $resultValue = 1;
            } else {
                //echo "trade_status=".$_GET['trade_status'];
            }
        } else {
            //echo "0";
        }
        $this->assign('resultValue', $resultValue);
        $this->display('return_zhifubao');
    }

    public function Pay_ZhifuBao() {
        $ordertag = I('ordertag');
        $subject = I('subject');
        $description = I('description');
        $price = I('price');

        $setting_db = D('Common/SystemSetting');

        $payment_type = "1";
        $partnerid = $setting_db->GetSettingValue('zhifu_zhifubao_partnerid', '');
        $sellerid = $setting_db->GetSettingValue('zhifu_zhifubao_sellerid', '');
        $is_release = $setting_db->GetSettingValue('is_release', '0');

        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $notify_url = $rooturl . U('service/api/notify_zhifubao');
        $return_url = $rooturl . U('Home/index/Return_ZhifuBao');
        $out_trade_no = $ordertag;
        // $subject = $subject;        
        $floatprice = floatval($price);
        $total_fee = number_format($floatprice, 2, '.', '');
        if ($is_release == 0 || $is_release == '0') {
            $total_fee = '0.01';
        }

        //$show_url       = $rooturl . U('Home/Index/mydingdan');
        $body = $description;
        $it_b_pay = '1';
        $extern_token = 'yjx_' . $ordertag;

        $alipay_config = array();
        $alipay_config['partner'] = $partnerid;
        $alipay_config['seller_id'] = $alipay_config['partner'];
        $alipay_config['private_key_path'] = 'zhifubao/key/rsa_private_key.pem';
        $alipay_config['ali_public_key_path'] = 'zhifubao/key/alipay_public_key.pem';
        $alipay_config['sign_type'] = strtoupper('RSA');
        $alipay_config['input_charset'] = strtolower('utf-8');
        $alipay_config['cacert'] = getcwd() . '\\zhifubao\\cacert.pem';
        $alipay_config['transport'] = 'http';

        Log::record('[ Alipay ] -- start --       ' . date('Y-m-d H:i:s', time()));
        Log::record('[ Alipay ] config data  ' . var_dump_ret($alipay_config));
        Log::record('[ Alipay ] post data ' . var_dump_ret($_POST));

        try {
            //计算得出通知验证结果
            vendor('Alipay.Corefunction');
            vendor('Alipay.Rsafunction');
            vendor('Alipay.Submit');

            $parameter = array(
                "service" => "alipay.wap.create.direct.pay.by.user",
                "partner" => trim($alipay_config['partner']),
                "seller_id" => trim($alipay_config['seller_id']),
                "payment_type" => $payment_type,
                "notify_url" => $notify_url,
                "return_url" => $return_url,
                "out_trade_no" => $out_trade_no,
                "subject" => $subject,
                "total_fee" => $total_fee,
                "show_url" => $show_url,
                "body" => $body,
                "it_b_pay" => $it_b_pay,
                "extern_token" => $extern_token,
                "_input_charset" => trim(strtolower($alipay_config['input_charset']))
            );

            $alipaySubmit = new \AlipaySubmit($alipay_config);
            $html_text = $alipaySubmit->buildRequestForm($parameter, "get", "确认");
            echo $html_text;
        } catch (Exception $ex) {
            Log::record('[ Alipay ] exception ' . var_dump_ret($ex));
        }

        Log::record('[ Alipay ] -- end --    ' . date('Y-m-d H:i:s', time()));
    }

    public function paySuccess() {
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $mainurl = $rooturl . U('Home/index/main') . "?client=" . $this->theClient . "&openid=" . $this->theOpenid;
        $mydingdanurl = $rooturl . U('Home/Index/mydingdan');
        $myteamdingdanurl = $rooturl . U('Home/Index/teamproductorder');
        
        $ordertag = I('ordertag');
        
        $order_db = D('Common/Order');
        $order = $order_db->where(array('ordertag' => $ordertag))->find();
        
        $lbladdress = '地　址：';
        $lblstore = '分售点：';
        $realname = $order['realname'];
        $detailaddress = '燕郊开发区' . $order['district'] . ' ' . $order['address'];
        $receivername = $order['receivername'];
        $sendtype = $order['sendtype'];
        $price = $order['price'];
        $mark_price = $order['mark_price'];
        $coupon_price = $order['coupon_price'];
        
         if (empty($sendtype)) {
                $lbladdress = $lbladdress;
                $realname = $realname;
                $detailaddress = $detailaddress;
            } else {
                $store_db = D('Common/Store');
                $store = $store_db->where(array('stoid' => $order['stoid']))->find();
                $stoname = '';
                if (!empty($store)) {
                    $stoname = $store['stoname'];
                }
                $lbladdress = $lblstore;
                $realname = $receivername;
                $detailaddress = $stoname;
            }
 
         $this->assign('pay_zhifu_url', $pay_zhifu_url);
        $this->assign('ordertag', $ordertag);
        $this->assign('team_ordertag', $order["team_ordertag"]);
        $this->assign('realname', $realname);
        $this->assign('lbladdress', $lbladdress);
        $this->assign('detailaddress', $detailaddress);
        $this->assign('subject', $subject);
        $this->assign('description', $description);
        $this->assign('price', $price);
        $this->assign('mark_price', $mark_price);
        $this->assign('coupon_price', $coupon_price);

        $this->assign('mydingdanurl', $mydingdanurl);
        $this->assign('myteamdingdanurl', $myteamdingdanurl);
        $this->assign('rooturl', $rooturl);
        $this->assign('mainurl', $mainurl);
        $this->display('pay_success');
    }

    public function payFail() {
        $rooturl = (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'];
        $mydingdanurl = $rooturl . U('Home/Index/mydingdan');
        $this->assign('mydingdanurl', $mydingdanurl);
        $this->display('pay_fail');
    }
        
    private function getFloatNumber( $value )
    {
        $olval = $value;
        $flval0 = number_format($olval, 0, '.', '');
        $flval1 = number_format($olval, 1, '.', '');
        $flval2 = number_format($olval, 2, '.', '');
        if( $flval0 == $olval )
        {
            $olval = $flval0;
        }
        else if ( $flval1 == $olval )
        {
            $olval = $flval1;
        }
        else 
        {
            $olval = $flval2;
        }
        return $olval;
    }
}
