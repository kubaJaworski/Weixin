<?php
namespace Home\Controller;
use Think\Controller;

/**
 * 公共控制器
 */
class CommonController extends Controller {

	protected $apiController = null;
        protected $theClient = '';
        protected $theOpenid = '';
        protected $theUid = '';

        protected function InitApiController()
        {
            if( $this->apiController == null )
            {
                $this->apiController = new \Service\Controller\ApiController;
            }
        }

        protected function GetSessionValue($name, $default='')
        {
            $session_val = session($name);
            /*
            $query_session_val = I($name, $default);        

            if( !empty($query_session_val) )
            {
                session($name, $query_session_val);
                $session_val = session($name);
            }
            */

            return $session_val;
        }

        protected function GetLoginInfo()
        {
            $this->theClient = $this->GetSessionValue('client');
            if( $this->theClient == "wx")
            {
                $this->theOpenid = $this->GetSessionValue('openid');

                $db_wxfan = D('Common/WxFan');
                $uid= $db_wxfan->GetUserId($this->theOpenid);
                
                if( empty($uid) )
                {
                    $this->theUid = 0;
                    session('uid', $this->theUid);
                    return;
                }
                
                $db_user = D('Common/User');
                $user = $db_user->where(array('uid'=>$uid, 'isdelete'=>0))->find();
                
                if( !empty($user) )
                {                    
                    $this->theUid = $uid;
                    session('uid', $this->theUid);
                    return;
                }
                else
                {
                    $this->theUid = 0;
                    session('uid', $this->theUid);
                    return;
                }
            }
            else
            {
                $this->theUid =  $this->GetSessionValue('uid');
            }
        }
        
        protected function GetRedirectURLAfterLogin()
        {
            $redircturl = session('YJ_LOGIN_REDIRECT');
            
            if( $redircturl === "0" )
                return "";
            
            return $redircturl;
        }
        
        protected function WriteRedirectURLAfterLogin($url)
        {
            session('YJ_LOGIN_REDIRECT', $url);
        }

        protected function WriteLoginInfo($uid ='', $openid='', $client='' )
        {
            session('uid', $uid);
            session('openid', $openid);
            session('client', $client);

            $db_wxfan = D('Common/WxFan');    
            $fanObj = $db_wxfan->where( array('openid'=>$openid) )->find();
            if( empty( $fanObj ))
            {
                $db_wxfan->add(array("openid"=>$openid));
            }
            $db_wxfan->SetUserId($openid, $uid );
            
            $this->GetLoginInfo();
        }

        protected function IsLogin()
        {
             $this->theUid =  $this->GetSessionValue('uid');
             if( empty($this->theUid) || $this->theUid == 0 )
             {
                 return false;
             }
             return true;
        }

        protected function IsWeixin()
        {
            $this->theClient = $this->GetSessionValue('client');
            $this->theOpenid = $this->GetSessionValue('openid');

            if( $this->theClient == 'wx' && !empty($this->theOpenid) )
            {
                return true;
            }
            return false;
        }
    
        /**
	 * 空操作，用于输出404页面
	 */
	public function _empty(){
		header("HTTP/1.0 404 Not Found");
		$this->show('<b>404 Not Found</b>');
		exit;
	}
	
        public function _Redirect($url, $param)
        {
            $url    =   U($url);
            
            $paramstr = "?time=" .time();
            foreach ($param as $var => $val){
                if('' !== trim($val)) $paramstr .= '&' . $var . '=' . urlencode($val);
            } 
            $url = $url . $paramstr;
            
            redirect($url,0,'');
        }
}
