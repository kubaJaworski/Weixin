<?php
namespace Service\Controller;
use Think\Controller;

/**
 * 空模块，主要用于显示404页面，请不要删除
 */
class EmptyController extends Controller{

	const ERR_NOTFOUNDAPI = '-2';

	public function _empty(){
		$this->ajaxReturn(array(
            'retCode' => self::ERR_NOTFOUNDAPI
        ));
	}
}
