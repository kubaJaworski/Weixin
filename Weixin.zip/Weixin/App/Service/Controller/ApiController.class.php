<?php
namespace Service\Controller;
use Think\Controller;
use Think\Upload;
use Think\Log;
use Common\Common\TheWeixin;
use Common\Common\TheApp;
use Common\Model\OrderModel;
use Common\Model\OrderDetailModel;
use Common\Model\TransactionModel;
use Common\Model\MarkAppealModel;

class ApiController extends BaseApiController{
    /* Debug Code */
    const DEBUG_TOKEN = '$$$';
    const DEBUG_SMSCODE = '$$$';
    
    /* SMS Code Check Type*/
    const SMS_LOGIN         = 0;
    const SMS_REGISTRATION  = 1;
    const SMS_FINDPASSOWRD  = 2;
   
    /* error code */
    const SUCCESS                       = '200';
    const SUCCESS_EMPTYVALUE            = '201';
    const ERR_UNKNOWN                   = '-1';
    const ERR_NOTFOUNDAPI               = '-2';
    const ERR_AUTH                      = '400';
    const ERR_LOGIN                     = '500';
    const ERR_NOFOUND_PHONE             = '501';
    const ERR_CONFLICT_NAME             = '502';
    const ERR_CONFLICT_PHONE            = '503';
    const ERR_MODIFY_PASSWORD           = '504';
    const ERR_ALREADY_RECOMMEND         = '505';
    const ERR_OVERFLOW_SHIPPING_ADDR    = '506';
    const ERR_INSUFFICIENT_PRODUCT      = '507';
    const ERR_INVALID_PRODUCTID         = '508';
    const ERR_INVALID_PRODUCTUNIT       = '509';
    const ERR_FIND_PASSWORD             = '510';    
    const ERR_TIMEOUT_SMSCODE           = '511';
    const ERR_NOMATCH_SMSCODE           = '512';
    const ERR_NOMATCH_PASSWORD          = '513';
    const ERR_INSUFFICIENT_USERPOINT    = '514';
    const ERR_NOTFOUND_USER             = '515';
    const ERR_NOTEXIST_ORDER            = '516';
    const ERR_ORDER_PROGRESSED          = '517';
    const ERR_ORDER_COMPLETE            = '518';
    const ERR_ORDER_RETURN              = '519';
    const ERR_SET_USERNAME              = '520';
    const ERR_NOMATCH_DISTRICTNAME      = '521';
    const ERR_OVERFLOWBUY_PRODUCT       = '522';
    const ERR_INSUFFICIENT_PRICE        = '523';
    const ERR_INVALID_COUPON            = '524';
    
    const VERIFY_FAIL = 'fail';
    
    private static function isAuth($user, $token)
    {
        if( $token == self::DEBUG_TOKEN )
            return true;
        
        if( $user['token'] == $token )
            return true;
        
        return false;
    }
    
    public function Signin($vParam = null)
    {
        try
        {
            // get parameter
            $username = call_I('username', '0', $vParam);
            $password = call_I('password', '0', $vParam);
            $devicecid  = call_I('devicecid', '', $vParam);
            $devicetoken = call_I('devicetoken', '', $vParam);

            $db_lawyer = D('Common/Lawyer');
            
            $result1 =   $db_lawyer->where( array('l_name'=>$username, 'l_isdelete'=>0) )->find();
            $result2 =   $db_lawyer->where( array('l_phone'=>$username, 'l_isdelete'=>0) )->find();
            
            if( empty($result1) && empty($result2) )
            {
                return $this->callAjaxReturn(array( 'retCode' => self::ERR_NOTFOUND_USER ), ($vParam != null));                
            }
            
            $lawyer = $db_lawyer->login($username, $password);
            
            if(!$lawyer)
            {
                return  $this->callAjaxReturn(array( 'retCode' => self::ERR_NOMATCH_PASSWORD ), ($vParam != null));
            }
            
            session_start();
            $uid = $lawyer['l_id'];
            $token = session_id() . "00" . time();
            
            $olddevicecid = $lawyer['devicecid'];
            $olddevicetoken = $lawyer['devicectoken'];
           
            if( empty($devicecid))
                $devicecid = $olddevicecid;
            
            if( empty($devicetoken))
                $devicectoken = $olddevicetoken;
            
            if( empty($devicecid))
                $devicecid ='';
            
            if( empty($devicetoken))
                $devicectoken = '';
            
            $res = $db_lawyer->where( array('l_id'=>$uid ) )->save( array('token'=>$token, 'devicecid'=>$devicecid, 'devicetoken'=>$devicetoken ) );
            
            return $this->callAjaxReturn(array(
                'retCode' => self::SUCCESS,
                'token' => $token,
                'uid' => $uid
            ), ($vParam != null));
            
        }
        catch (Exception $e)
        {            
        }
        
        return $this->callAjaxReturn( array( 'retCode' => self::ERR_UNKNOWN ), ($vParam != null) );
    }
    
    public function Signup($vParam = null)
    {
        try
        {
            // get parameter
            $phonenum   = call_I('phonenum', '0', $vParam);
            $password   = call_I('password', '0', $vParam);
            $checkcode  = call_I('checkcode', '0', $vParam);
            $friendcode = call_I('tuiguangma', '0', $vParam);
            $devicecid  = call_I('devicecid', '', $vParam);
            $devicetoken = call_I('devicetoken', '', $vParam);

            $code = 0;            
            if( !empty($phonenum) )
            {   
                $db_sms = D('Common/SmsTable');
                $code = $db_sms->getCode( $phonenum );
            }
            
            if( ($code == null || $code == 0 ) &&  $checkcode != self::DEBUG_SMSCODE )
            {
                return $this->callAjaxReturn(array( 'retCode' => self::ERR_TIMEOUT_SMSCODE ), ($vParam != null) );
                
            }
            else if (  $code != $checkcode &&  $checkcode != self::DEBUG_SMSCODE )
            {
                return $this->callAjaxReturn( array( 'retCode' => self::ERR_NOMATCH_SMSCODE ), ($vParam != null) ); 
            }
            
            $db_user = D('Common/User');
            
            $user = $db_user->getUserFromPhone($phonenum);
            if( $user )
            {
                return $this->callAjaxReturn( array( 'retCode' => self::ERR_CONFLICT_PHONE ), ($vParam != null) );  
            }
            
            $count = $db_user->count();
            $uname = "普通用户 " . $count;
            $uid = $db_user->registerUser($uname, $phonenum, $password, $friendcode);
            
            if($uid)
            {
                session_start();
                $token = session_id() . "00" . time();

                $olddevicecid = $user['devicecid'];
                $olddevicetoken = $user['devicectoken'];

                if( empty($devicecid))
                    $devicecid = $olddevicecid;

                if( empty($devicetoken))
                    $devicectoken = $olddevicetoken;

                if( empty($devicecid))
                    $devicecid ='';

                if( empty($devicetoken))
                    $devicectoken = '';
                
                $res = $db_user->where( array('uid'=>$uid ) )->save( array('token'=>$token, 'devicecid'=>$devicecid, 'devicetoken'=>$devicetoken ) );

                return $this->callAjaxReturn(array(
                    'retCode' => self::SUCCESS,
                    'token' => $token,
                    'uid' => $uid
                ), ($vParam != null));
                
            }
        }
        catch (Exception $e)
        {            
        }
        
        return $this->callAjaxReturn( array( 'retCode' => self::ERR_UNKNOWN ), ($vParam != null) );
    }
    
    
        
    public  function doSuccessPay($out_trade_tag, $paytype, $payprice, $paytag, $paytime)
    {
        try
        {
//            Log::record( '[ doSuccessPay ] Question  000-01 ' . $out_trade_tag );
            $trade_params= explode("_", $out_trade_tag);
            
            //Log::record( '[ doSuccessPay ] Question  000-02 ' . var_dump_ret($trade_params) );
            
            $tradeType = $trade_params[0];
            $q_code  = $trade_params[1];
            $type = $trade_params[3];            
            
                $db_question->commit();
            }
            catch(Exception $ex)
            {
                $db_question->rollback();
            }               
            
            return true;
        }
        catch (Exception $e)
        {            
            Log::record( '[ doSuccessPay ] exception ' . var_dump_ret($e) );
        }
        return false;
    }
    
    public function Notify_ZhifuBao($vParam = null)
    {
        $alipay_config = array();
        $alipay_config['partner']        = '2088021715507592';
        $alipay_config['private_key_path']    = 'zhifubao/key/rsa_private_key.pem';
        $alipay_config['ali_public_key_path']   = 'zhifubao/key/alipay_public_key.pem';
        $alipay_config['sign_type']             = strtoupper('RSA');
        $alipay_config['input_charset']         = strtolower('utf-8');        
        $alipay_config['cacert']                = getcwd().'\\zhifubao\\cacert.pem';
        $alipay_config['transport']             = 'http';
        
        Log::record( '[ Alipay ] -- start --       ' . date('Y-m-d H:i:s', time()) );
        Log::record( '[ Alipay ] config data  ' . var_dump_ret($alipay_config)  );
        Log::record( '[ Alipay ] post data ' . var_dump_ret($_POST)  );

        try
        {
            //计算得出通知验证结果
            vendor('Alipay.Corefunction');
            vendor('Alipay.Rsafunction');
            vendor('Alipay.Notify');   
            
            // $alipayNotify = new AlipayNotify($alipay_config);
            // $verify_result = $alipayNotify->verifyNotify();
            // Log::record( '[ Alipay ] verify result ' . $verify_result );
            $verify_result = true;

            if($verify_result) 
            {
                $ordertag       = $_POST['out_trade_no'];
                $paytag         = $_POST['trade_no'];
                $trade_status   = $_POST['trade_status'];
                $price          = $_POST['total_fee'];
                $paytime        = strtotime($_POST['gmt_payment']);

                if ($trade_status == 'TRADE_SUCCESS') {
                    $this->doSuccessPay($ordertag, TransactionModel::TYPE_ALI_PAY, $price, $paytag, $paytime);
                    Log::record( '[ Alipay ] Success '  );
                }
            }
            else 
            {
                Log::record( '[ Alipay ] fail '  );
            }            
        }
        catch(Exception $ex)
        {
            Log::record( '[ Alipay ] exception ' . var_dump_ret($ex)  );
        }

        Log::record( '[ Alipay ] -- end --    ' . date('Y-m-d H:i:s', time()) );
    }    
    
    public function Notify_Weixin($vParam = null)
    {
//        Log::record( '[ Weixin ] -- start --       ' . date('Y-m-d H:i:s', time()) );        
        
        $post_data = $GLOBALS['HTTP_RAW_POST_DATA'];       
//        Log::record( '[ Weixin ] post raw data ' . $post_data );
                
        try
        {
            $param = xml2array($post_data); 
//            Log::record( '[ Weixin ] result ' . var_dump_ret($param) ) ;
            if( $param['result_code'] == 'SUCCESS' &&
                $param['return_code'] == 'SUCCESS' )
            {
                $out_trade_tag  = $param['out_trade_no'];
                $paytag         = $param['transaction_id'];               
                $price          = floatval($param['total_fee']) / 100;
                $paytime        = strtotime($param['time_end']);      
                
                //
                $this->doSuccessPay($out_trade_tag, TransactionModel::TYPE_WEIXIN_PAY, $price, $paytag, $paytime);
                
//                Log::record( '[ Weixin ] Success -- end --    ' . date('Y-m-d H:i:s', time()) );
                return;                
            }
        }
        catch(Exception $ex)
        {
            Log::record( '[ Weixin ] exception ' . var_dump_ret($ex)  );
        }
        
        Log::record( '[ Weixin ] -- end --    ' . date('Y-m-d H:i:s', time()) );
    }
}