var g_offset = 0;
var g_limit = 8;
var g_isGettingMore = false;
var g_disporder = 0;
var g_cid = 0;

$(document).ready(function() {
    bind_cat_event();
    $('.yj-smcat-btn').eq(0).click();

    refresh_cart_price();

});

function bind_cat_event() {
    $('.yj-smcat-btn').unbind('click');
    $('#leftPane').unbind('scroll');

    $('.yj-smcat-btn').click(function () {
        $('.yj-smcat-btn-active').addClass('yj-smcat-btn');
        $('.yj-smcat-btn-active').removeClass('yj-smcat-btn-active');
        $(this).removeClass('yj-smcat-btn');
        $(this).addClass('yj-smcat-btn-active');

        var cid = $(this).attr('cid');
        if(cid != g_cid) {
            g_cid = cid;
            refresh_page(0);
        }

        bind_cat_event();
    });

    $('#leftPane').scroll(function() {
        if (!g_isGettingMore && isScrolledIntoView($('#div_viewmore'))) {
            //console.log('ok');
            g_isGettingMore = true;
            getMore();
        }
    });

}

function refresh_mode_buttons(elem) {
    $('.searchmode').removeClass('yj-active');
    $(elem).addClass('yj-active');
    $('.searchmode').children('i').remove();
    var mode = $(elem).attr('searchmode');
    if(mode == 1 || mode == 3) {
        $(elem).append('<i class="fa fa-arrow-down"></i>');
    }
    else if(mode == 2 || mode == 4) {
        $(elem).append('<i class="fa fa-arrow-up"></i>');
    }
}

function refresh_page(searchmode) {
    $('#product_list').empty();
    g_offset = 0;
    g_isGettingMore = false;
    g_disporder = searchmode;
    getMore();
}

function getMore() {

    //waitingDialog.show('Please wait');
    //console.log('API begin : GetProductList');
    $.post('/index.php/home/service/GetBranchList',
        {'offset': g_offset, 'limit': g_limit, 'cid': g_cid, 'ctype': '3'})
        .done(function (resp) {
            //console.log('API end : GetProductList');
            console.log(resp);

            //waitingDialog.hide();
            if (resp.size > 0) {
                $('#product_list').append(resp.html);
                g_offset += resp.size;
                if (resp.size < g_limit) {
                    $('#div_viewmore').hide();
                }
            }
            g_isGettingMore = false;
        });
}

function refresh_cart_price()
{
    $.post('/index.php/home/service/GetCartPrice',  {}, function (resp) {
        // Success
        console.log(resp);
        if(resp.retCode == 200) {
            if( resp.price > 0 )
            {
                $('#carNum').text('￥' + resp.price);
            }
            else
            {
                $('#carNum').text('');
            }
        }
    });
}