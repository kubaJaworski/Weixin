/******************************************
 *
 * validation.js
 *
 * Yanjiao online (Shuiguo)
 *
 ******************************************/

// require jquery-1.11.3.min.js
// require bootstrap.min.js
// require jssor.slider.mini.js
// require bootstrap-notify.js

var theValidation = {
   
    /*
     * isNumberKey
     */ 
    isNumberKey: function(evt)
    {  
        var charCode = (evt.which) ? evt.which : evt.keyCode
        if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    },
           
    /*
     * isAlphaKey
     */
    isAlphaKey: function (evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
            return false;

        return true;
    },

    /*
     * Invalid input special key
     */
    bindInputSpecial: function ( vInput )
    {
        $( vInput ).keypress(
            function (e) {
                var keyCode = (e.which) ? e.which : e.keyCode;

                if ( keyCode == 33     || keyCode == 36    
                    || keyCode == 37 || keyCode == 38 || keyCode == 39    
                    || keyCode == 40 || keyCode == 41 || keyCode == 42    
                    || keyCode == 43 || keyCode == 92 || keyCode == 94    
                    || keyCode == 124 ) {
                     e.preventDefault();
                }
                
                if ( keyCode == 59       /* ;  */
                    || keyCode == 61     /* =  */
                    || keyCode == 91 || keyCode == 123 || keyCode == 219    /* [ , {  */
                    || keyCode == 92 || keyCode == 124 || keyCode == 220    /* \  */
                    || keyCode == 93 || keyCode == 125 || keyCode == 221    /* ]  */
                    || keyCode == 34 || keyCode == 39  || keyCode == 222    /* ' "  */
                    || keyCode == 62 || keyCode == 63  || keyCode == 47    /*  > ? /  */
                    || keyCode == 44 || keyCode == 60 || keyCode == 188 ) { /* ,  < */
                     e.preventDefault();
                }

                if( isNumberKey(e) == true || isAlphaKey(e) == true )
                {
                    return;
                }

                

                if ( keyCode == 8    /* backspace */
                    || keyCode == 13   /* enter */
                    || keyCode == 173   /* - */
                    || keyCode == 50    /* @  */
                    || keyCode == 190 ) { /* .  */
                    return;
                }

                return;
            });

    },
}
