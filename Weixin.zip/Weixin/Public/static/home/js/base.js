// 核心
var KC = {
    // 遮罩
    Mask: {
        cfg: {
            id: ".mask"												// box
        },
        // show
        show: function (n) {
            var oMask = $(this.cfg.id);						// 遮罩层

            if (!oMask.length) {
                var bTran = n == 0 ? "mask tran" : "mask";
                oMask = $('<div class="' + bTran + '" />').appendTo($("body"));
                oMask
					.fadeIn("fast")
					.bind("touchstart", function () {
					    KC.Mask.hide();

					    $(".filterSel").hide();
					});

                $(this.cfg.id)
					.bind("touchmove", function (e) {
					    e.stopPropagation();
					    e.preventDefault();
					});
            }
        },
        // hide
        hide: function () {
            $(this.cfg.id).hide().remove();

            if ($(".sType")) $(".sType").hide();
            if ($(".dlg")) $(".dlg").hide();
        }
    },
    // 泡泡
    Bubble: {
        cfg: {
            id: ".bubble",										// box
            speed: 2000
        },
        show: function (str, o) {
            var oBubble = $(this.cfg.id);
            var sTitle = str;
            if (!oBubble.length) {

                oBubble = $('<div class="bubble" />').appendTo($("body"));

                if (o) {
                    oBubble
						.html(sTitle)
						.css({
						    "position": "absolute",
						    "top": $(o).offset().top
						})
						.fadeIn();
                } else {
                    oBubble
					.html(sTitle)
					.fadeIn();
                }

            }

            KC.Mask.show(0);
            setTimeout("KC.Bubble.hide()", KC.Bubble.cfg.speed);
        },
        hide: function () {
            $(this.cfg.id).fadeOut("slow", function () {
                $(this).remove();
                if ($(KC.Dlg.cfg.id).length > 0) {
                    $(KC.Mask.cfg.id).removeClass("tran");
                } else {
                    KC.Mask.hide();
                }
            });
        }
    },
    // 对话框
    Dlg: {
        cfg: {
            id: ".dlg",											// box
            box: ".dlgC",
            hasTitle: true,
            title: "提示",
            btn: ["确定"]
        },
        // show
        show: function (n) {
            var oDlg = $(this.cfg.id);
            var sTitle = this.cfg.title;

            if (!oDlg.length) {
                oDlg = $('<div class="dlg" />').appendTo($("body"));
                if (this.cfg.hasTitle) {
                    oTitle = $('<div class="title" />').appendTo(oDlg);
                    oTitle.html(sTitle + "<a href='javascript:KC.Dlg.hide();'></a>");
                }
                $('<div class="dlgC" />').appendTo(oDlg);
                $('<div class="dlgBtn" />').appendTo(oDlg);
            }
            this.addBtn();
            oDlg.show();
            KC.Mask.show(n);
        },
        // add btn
        addBtn: function () {
            var oBtn = $(".dlgBtn");
            oBtn.empty();

            // 逆序排序
            $.each(this.cfg.btn, function (i, n) {
                $('<a href="javascript:void(0)">' + n + '</a>').appendTo(oBtn);
            });

            if (this.cfg.btn.length > 1) $(".dlgBtn>a").width("50%");

            oBtn.focus();

        },
        // hide
        hide: function (bHide) {
            $(this.cfg.id).remove();
            if (bHide == undefined) KC.Mask.hide();
        }
    },
    // 加载...
    Loading: {
        cfg: {
            id: ".loading"
        },
        // show
        show: function (msg) {
            var oLoading = $(this.cfg.id);
            var sMsg = msg == undefined ? "请等待..." : msg;

            if (!oLoading.length) {
                oLoading = $('<div class="loading" />').appendTo($("body"));
                oLoading
					.html("<i></i>" +
								"<p>" + sMsg + "</p>");
            } else {
                oLoading.children("p").html(sMsg);
            }
            //	KC.Mask.show(0);
        },
        // hide
        hide: function () {
            $(this.cfg.id).fadeOut(200, function () { $(this).remove(); });
            //	KC.Mask.hide();
        }
    },
    // Radio
    rad: function (el) {
        if ($(".radio input").length) {
            $(".radio").removeClass("radio_checked");
            $(".radio input:checked").parent("label").addClass("radio_checked");
        }
        if (el) {
            var sName = $(el).children("input").attr("name");
            $(".radio input[name=" + sName + "]").attr("checked", false);
            $(el).children("input").attr("checked", true);
            $(".radio input[name=" + sName + "]").parent().removeClass("radio_checked");
            $(el).addClass("radio_checked");
        }
    },
    // 模拟 Checkbox
    chk: function (el) {
        var o = $(el).children("input");
        o.attr("checked", o.attr("checked") ? false : true);
        if ($(".checkbox input").length) {
            $(".checkbox").removeClass("checkbox_checked");
            $(".checkbox input:checked").parent("label").addClass("checkbox_checked");
        }
    },
    // 模拟 switch
    swi: function () {
        // switch
        $(".switchOff, .switchOn")
			.click(function () {
			    var el = $(this);
			    // default
			    el.attr("class",
					el.attr("class") == "switchOff"
					? "switchOn"
					: "switchOff"
				);
			});
    },
    // 是否有底部
    hasFooter: function () {
        var o = $(".content");
        var oFooter = $("footer.my li");
        if ($("footer").size() > 0) o.addClass("hasFooter");
    },
    // 会员
    Member: {
        logged: function () {

            var bLogged = Math.floor(Math.random() * 2);  // handler 处理是否登录
            var nType = Math.floor(Math.random() * 2);		// 0普通、1律师

            if (!bLogged) {
                KC.Dlg.cfg.hasTitle = false;
                KC.Dlg.cfg.btn = ["取消", "现在去登录"];
                KC.Dlg.show();
                var oBtn = $(".dlgBtn>a");
                $(KC.Dlg.cfg.box)
						.html(
							'<dl class="confirm fail">' +
							'	<dt>您的输入失败！</dt>' +
							'	<dd>您需登录后才可' + (nType ? "解答问题" : "向律师咨询") + '~</dd>' +
							'</dl>'
						);
                oBtn.eq(0).click(function () {
                    KC.Dlg.hide();
                });
                oBtn.eq(1).click(function () {
                    window.location.href = "sign-in.shtml";
                });
            }
        },

        eixt: function () {
            // handler 清理用户数据
            window.location.href = "index.shtml";
        }
    },

    // 加载...
    Loading: {
        cfg: {
            id: ".loading"
        },
        // show
        show: function (msg) {
            var oLoading = $(this.cfg.id);
            var sMsg = msg == undefined ? "请等待..." : msg;

            if (!oLoading.length) {
                oLoading = $('<div class="loading" />').appendTo($("body"));
                oLoading
					.html("<i></i>" +
								"<p>" + sMsg + "</p>");
            } else {
                oLoading.children("p").html(sMsg);
            }
            //	KC.Mask.show(0);
        },
        // hide
        hide: function () {
            $(this.cfg.id).fadeOut(200, function () { $(this).remove(); });
            //	KC.Mask.hide();
        }
    },

    Fix: {
        // 
        browser: function () {
            var _versions = null;
            var u = navigator.userAgent;
            /*    var app = navigator.appVersion;*/
            _versions = {         //移动终端浏览器版本信息
                trident: u.indexOf('Trident') > -1, //IE内核
                presto: u.indexOf('Presto') > -1, //opera内核
                webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
                ucBrowser: u.indexOf('UCBrowser') > -1,	// uc浏览器				
                //		360Browser : u.indexOf('360 Aphone') > -1,	// 360浏览器				
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
                iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
                iPad: u.indexOf('iPad') > -1, //是否iPad
                webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
                winPhone: u.indexOf("Windows Phone") > -1
            };

            return _versions;
        },

        // 有segment
        hasSegment: function () {
            if ($(".segment").length > 0) {
                $("body").addClass("hasSegment");
            }
        }
    },
    // 初始化
    init: function () {

        // Checkbox
        $(".checkbox:not('.disabled')").live("click", function () { KC.chk(this); });
        // Radio
        $(".radio").live("click", function () { KC.rad(this); });

        // search
        $("input[type='search']")
			.live("keyup", function (e) {
			    var o = $(this);
			    var sVal = $.trim(o.val()).replace(/\s/g, '');
			    var nLen = sVal.length;
			    if (nLen > 0) {
			        $("header").css("z-index", 105);
			        $(".sType").show();
			        if ($(this).attr("data-target") == undefined) { KC.Mask.show(); }

			        if ($(this).attr("data-type") != "0") {
			            $(".content").show();
			            $(".searchHistory").hide();
			        }

			        $(".btnText").show();
			    } else {
			        $("header").css("z-index", 5);
			        $(".sType").hide();
			        KC.Mask.hide();
			        if ($(this).attr("data-target") == undefined) { $(".btnText").hide(); }
			    }
			});

        this.chk();									// chckbox
        this.rad();									// radio
        this.swi();									// Switch
        this.hasFooter();						// Has footer
        this.Fix.hasSegment();

        //		this.Loading.show();


        if (this.Fix.browser().ucBrowser) {
            $("body").addClass("static");
        }
    }
};

$(document)
 .ready(function () { KC.init(); });
$(function () {

    // 解答咨询
    $(".kAnswer")
		.live("click", function () {
		    if (checkLMUM('checkLM') == "1") {
		        var uqid = $(this).attr("uqid");
		        var userid = $(this).attr("userid");
		        var uqtype = $(this).attr("uqtype");
		        var ispay = $(this).attr("ispay");
		        var str;
		        $.ajax({
		            async: false,
		            url: 'ashx/comm.ashx?bigtype=dblock&uqid=' + uqid + '&userid=' + userid + '&uqtype=' + uqtype + '&ispay=' + ispay + '&dbtype=1&num=' + GetRandomNum(0, 10000),
		            success: function (data) {
		                str = data;
		            }
		        })
		        if (str == "0") {
		            location.href = "chatum.aspx?uid=" + uqid + "&lid=" + userid + "&uqtype=" + uqtype + "&num=" + GetRandomNum(0, 10000);
		        }
		        else if (str == "5") {
		            KC.Bubble.show("用户正在修改问题，请稍等，谢谢！");
		        }
		        else if (str == "7") {
		            KC.Bubble.show("您已经暂时不能回答收费问题了，请先回答两个免费问题，谢谢！");
		        }
		        else if (str == "8") {
		            KC.Bubble.show("凌晨1点到6点为律师充电时间，请您休息，谢谢！");
		        }
		        else if (str == "2") {
		            KC.Bubble.show("该问题已被解答，谢谢，请选择其他问题！");
		        }
		        else if (str == "3") {
		            KC.Bubble.show("您已在解答一个问题，请完成后再解答新的问题！");
		        }
		        else {
		            KC.Bubble.show("其他律师正在解答，请选择其他问题！");
		        }
		    }
		    else if (checkLMUM('checkLM') == "3")
		        alert("您的律师资料正在审核中，请稍后进行操作！");
		    else if (checkLMUM('checkLM') == "2" || checkLMUM('checkLM') == "4") {
		        if (confirm("您的律师身份尚未验证，提交相关资料！")) {
		            if (checkLMUM('checkLM') == "2")
		                location.href = "profileLE1.aspx";
		            else
		                location.href = "profileLM1.aspx";
		        }
		    }
		    else
		        cooperationLogin('phone');
		});

});


 $.sess = function (dat) {
     if (dat.indexOf('DOCTYPE') > -1) {
         location.href = "login.aspx"
     }
 }

$.getimg = function () {
    return "<div  style='text-align:center; margin-top:150px' id='besu'><img src='/img/loading.gif' /></div>";
}

function getajax2(ajaxurl) {
    var str;
    $.ajax({
        async: false,
        beforeSend: function () {
            KC.Loading.show("爱我，别走，再给我一点温柔！");
        },
        url: ajaxurl + '&num=' + GetRandomNum(0, 10000),
        success: function (data) {
            $.sess(data);
            KC.Loading.hide();
            str = data;
        }
    })
    return str;
}

function getajax(ajaxurl) {
    var str;
    $.ajax({
        async: false,      
        url: ajaxurl + '&num=' + GetRandomNum(0, 10000),
        success: function (data) {
            $.sess(data);
            str = data;
        }
    })
    return str;
}




function getajax1(ajaxurl,spar) {
    var str;
    $.ajax({
        async: false,
        type: "POST",
        url: ajaxurl,
        data: spar + '&num=' + GetRandomNum(0, 10000),
        success: function (data) {
            $.sess(data);
            str = data;
        }
    })
    return str;
}

function getjson(ajaxurl) {
    var str;
    $.ajax({
        async: false,
        type: 'GET',
        url: ajaxurl + '&num=' + GetRandomNum(0, 10000),
        dataType: 'json',
        success: function (data) {
            $.sess(data);
            str = data;
        }
    })
    return str;
}

function getJsonObjLength(jsonObj) {
    var Length = 0;
    for (var item in jsonObj) {
        Length++;
    }
    return Length;
}



//取一个随机数
function GetRandomNum(minNum, maxNum) {
    return minNum + Math.round((Math.random() * (maxNum - minNum)));
}

// 合作登录
function cooperationLogin(obj) {
    var target = "";
    switch (obj) {
        case "sina-weibo":
            location.href = "/exit.aspx?id=sina-weibo";
            break;
        case "qq":
            location.href = "/exit.aspx?id=qq";
            break;
        case "weixin":
            location.href = "/exit.aspx?id=weixin";
            break;
        case "tencent-weibo":
            location.href = "/exit.aspx?id=tencent-weibo";
            break;
    }

}

function checkLength(which, maxChars) {

    if (which.value.length > maxChars) {

        alert("您出入的字数超多限制!");

        // 超过限制的字数了就将 文本框中的内容按规定的字数 截取

        which.value = which.value.substring(0, maxChars);

        return false;

    }

    else {

        var curr = maxChars - which.value.length; //250 减去 当前输入的

        document.getElementById("lbcount").innerHTML = curr.toString();

        return true;

    }
}


function checkLMUM(str) {
    var str;
    $.ajax({
        async: false,
        url: 'ashx/comm.ashx?bigtype=' + str + '&num=' + GetRandomNum(0, 10000),
        success: function (data) {
            str = data;
        }
    })
    return str;
}
//检测是否整数
function CheckInt(str) {
    var matchstr = /^(-?(\d+))$/;
    return matchstr.test(str)
}

function is_weixn() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
    } else {
        return false;
    }
}

function jsonDateFormat(jsonDate) {//json日期格式转换为正常格式
    try {
        var date = new Date(parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10));
        var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
        var day = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();
        var milliseconds = date.getMilliseconds();
        return date.getFullYear() + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds ;//+ "." + milliseconds
    } catch (ex) {
        return "";
    }
}

//百度统计js
var _hmt = _hmt || [];
(function () {
    var hm = document.createElement("script");
    hm.src = "//hm.baidu.com/hm.js?6f39c07ed785e60843b22a1f9580c6a8";
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);


    $.get('ashx/HandlerWeb.ashx?bigtype=dourl');
})();
