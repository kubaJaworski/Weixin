var g_offset = 0;
var g_limit = 30;
var g_isGettingMore = false;
var g_searchmode = 0;

$(document).ready(function() {

    $(window).scroll(function() {
        if (!g_isGettingMore && isScrolledIntoView($('#div_viewmore'))) {
            //console.log('ok');
            g_isGettingMore = true;
            getMore();
        }
    });

    $('.searchmode').click(function() {
        var mode = $(this).attr('searchmode');

        refresh_mode_buttons(this);
        refresh_page(mode);
    });

    $('.searchmode').eq(0).click();

});

function refresh_mode_buttons(elem) {
    $('.searchmode').removeClass('yj-active');
    $(elem).addClass('yj-active');
}

function refresh_page(searchmode) {
    g_searchmode = searchmode;

    $('#history_list').empty();
    g_offset = 0;
    g_isGettingMore = false;
    getMore();
}

function getMore() {

    //waitingDialog.show('Please wait');
    //console.log('API begin : GetProductList');
    $.post('/index.php/home/service/GetTuihuanList',
        {'offset': g_offset, 'limit': g_limit, 'searchmode': g_searchmode})
        .done(function (resp) {
            //console.log('API end : GetProductList');
            //console.log(resp);

            //waitingDialog.hide();
            if (resp.size > 0) {
                $('#history_list').append(resp.html);
                g_offset += resp.size;
                if (resp.size < g_limit) {
                    $('#div_viewmore').hide();
                }
            }
            g_isGettingMore = false;
        });
}
