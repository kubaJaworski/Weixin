/******************************************
 *
 * date.js
 *
 * Yanjiao online (Shuiguo)
 *
 ******************************************/

// require jquery-1.11.3.min.js
// require bootstrap.min.js
// require jssor.slider.mini.js
// require bootstrap-notify.js

var theDate = {

   /*
    * Get Days of the Month
    */
    getDayNum:function (dateObject) {
        switch (dateObject.getMonth()) {
            case 1: // Check for leap year
                if ((dateObject.getFullYear() % 4 == 0
                        && dateObject.getFullYear() % 100 != 0)
                        || dateObject.getFullYear() % 400 == 0)
                    return 29;
                else
                    return 28;
            case 3:
                return 30;
            case 5:
                return 30;
            case 8:
                return 30;
            case 10:
                return 30
            default:
                return 31;
        }
    },

   /*
    * Get weeks of the Month
    */
    getWeekNum: function(y, m) {
        var first_day = new Date(y, m - 1, 1);
        var total_days = getDayNum(first_day);
        var last_day = new Date(y, m - 1, total_days);
        var wday1 = first_day.getDay();
        var wday2 = last_day.getDay();

        var wnum = parseInt((total_days + wday1 - 1) / 7);

        if (wday1 < 4)
            wnum++;

        if (wday2 < 3)
            wnum--;

        return wnum;
    },

    /*
    * Get weeks period of the Month
    */
    getWeekPeriod: function(y, m, w) {
        // first week first day of year, month
        var first_day = new Date(y, m - 1, 1);
        var last_day = new Date();
        var wday = first_day.getDay();

        first_day.setTime(first_day.getTime() - wday * 24 * 60 * 60 * 1000);

        if (wday > 3)
            first_day.setTime(first_day.getTime() + 7 * 24 * 60 * 60 * 1000);

        // first day of week
        first_day.setTime(first_day.getTime() + (w - 1) * 7 * 24 * 60 * 60 * 1000);

        // last day of week
        last_day.setTime(first_day.getTime() + 6 * 24 * 60 * 60 * 1000);

        var first_month = ((first_day.getMonth() + 1) < 10) ? "0" + (first_day.getMonth() + 1) : first_day.getMonth() + 1;
        var first_date = (first_day.getDate() < 10) ? "0" + first_day.getDate() : first_day.getDate();
        var last_month = ((last_day.getMonth() + 1) < 10) ? "0" + (last_day.getMonth() + 1) : last_day.getMonth() + 1;
        var last_date = (last_day.getDate() < 10) ? "0" + last_day.getDate() : last_day.getDate();

        return {
            start: first_day.getFullYear() + "-" + first_month + "-" + first_date,
            end: last_day.getFullYear() + "-" + last_month + "-" + last_date
        }
    },

   /*
    * Get year, month, week from Date
    */
    getYMW: function(dt) {
        var y = dt.getFullYear();
        var m = dt.getMonth() + 1;
        var w = 0;

        var first_day = new Date(y, m - 1, 1);
        var wday = first_day.getDay();

        var wnum = getWeekNum(y, m);

        w = parseInt((dt.getDate() + wday - 1) / 7);

        if (wday < 4)
            w++;

        if (w == 0) { // the case contain previous month
            if (m == 1) {
                y--;
                m = 12;
            } else {
                m--;
            }

            w = getWeekNum(y, m);
        } else if (w > wnum) { // the case contain next month
            if (m == 12) {
                y++;
                m = 1;
            } else {
                m++;
            }

            w = 1;
        }

        return {year: y, month: m, week: w};
    },

    /*
     * Get Season from date
     */ 
    getSeasonPeriod: function(now) {
        var y = now.getFullYear();
        var m = now.getMonth();
        var season = m;
        if (m == 0 || m == 1 || m == 2) {
            season = 1;
        } else if (m == 3 || m == 4 || m == 5) {
            season = 2;
        } else if (m == 6 || m == 7 || m == 8) {
            season = 3;
        } else if (m == 9 || m == 10 || m == 11) {
            season = 4;
        }
        var startDate = y + "-" + (season * 3 - 3 + 1) + "-01";
        var endDate = "";
        var temp = getDayNum(new Date(y, (season * 3 - 1), 1));
        endDate = y + "-" + (season * 3) + "-" + temp;

        return {start: startDate, end: endDate};
    },

    /*
     * Get Half Year from date
     */ 
    getHalfYearPeriod: function(now) {
        var y = now.getFullYear();
        var m = now.getMonth();
        var season = m;
        if (m == 0 || m == 1 || m == 2 || m == 3 || m == 4 || m == 5) {
            season = 1;
        } else if (m == 6 || m == 7 || m == 8 || m == 9 || m == 10 || m == 11) {
            season = 2;
        }
        var startDate = y + "-" + (season * 6 - 6 + 1) + "-01";
        var endDate = "";
        var temp = getDayNum(new Date(y, (season * 6 - 1), 1));
        endDate = y + "-" + (season * 6) + "-" + temp;

        return {start: startDate, end: endDate};
    },

    /*
     * Get Year from date
     */ 
    getYearPeriod: function(now) {
        var y = now.getFullYear();
        var m = now.getMonth();
        var startDate = y + "-01-01";
        var endDate = "";
        var temp = getDayNum(new Date(y, 11, 1));
        endDate = y + "-12-" + temp;

        return {start: startDate, end: endDate};
    },
}
