/******************************************
 *
 * application.js
 *
 * Yanjiao online (Shuiguo)
 *
 ******************************************/

// require jquery-1.11.3.min.js
// require bootstrap.min.js
// require jssor.slider.mini.js
// require bootstrap-notify.js

var theNotification = null;
var theApplication = {
    /*
    * show Error Message
    */
    showError:function( vMessage )
    {
        if( theNotification != null )
        {
            theNotification.hideNoDelay();
        }
        
        var position = '.bottom-center';
        var style = 'bangTidy';
        theNotification = $(position ).notify({ message: { text: vMessage }, type: style });
        theNotification.show();
    },
    
   /*
    * show Info Message
    */
    showInfo:function( vMessage )
    {
        if( theNotification != null )
        {
            theNotification.hideNoDelay();
        }
        
        var position = '.bottom-center';
        var style = 'info';
        theNotification = $(position ).notify({ message: { text: vMessage }, type: style });
        theNotification.show();
    },
}
