var waitingDialog = (function ($) {

    var $dialog = $(
        '<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:50%;margin-left: 40%; overflow-y:visible;">' +
        '<div class="modal-dialog modal-m">' +
        '<img src="/Public/static/img/loading.gif"></div></div>');

    return {
        /**
         * Opens our dialog
         * @param message Custom message
         * @param options Custom options:
         *                   options.dialogSize - bootstrap postfix for dialog size, e.g. "sm", "m";
         *                   options.progressType - bootstrap postfix for progress bar type, e.g. "success", "warning".
         */
        show: function (message, options) {
            // Assigning defaults
            var settings = $.extend({
                dialogSize: 'm',
                progressType: ''
            }, options);
            if (typeof message === 'undefined') {
                message = 'Loading';
            }
            if (typeof options === 'undefined') {
                options = {};
            }
            // Configuring dialog
            $dialog.find('.modal-dialog').attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
            $dialog.find('.progress-bar').attr('class', 'progress-bar');
            if (settings.progressType) {
                $dialog.find('.progress-bar').addClass('progress-bar-' + settings.progressType);
            }
            $dialog.find('h3').text(message);
            // Opening dialog
            $dialog.modal();
        },
        /**
         * Closes dialog
         */
        hide: function () {
            $dialog.modal('hide');
        }
    }

})(jQuery);

var messageBox = (function ($) {

    var $box = $('<div class="message-floor" id="messageBox" style="display: block;">' +
                    '<div class="messge-box" style="margin-top: 324px; width: 180px;">' +
                    '<div class="messge-box-icon">' +
                    '<i class="bottom-focus-icon succee-icon"></i>' +
                    '</div>' +
                    '<div class="messge-box-content">恭喜，已添至购物车</div>' +
                '</div>' +
                '</div>');

    return {
        show: function () {
            $('body').append($box);
            setTimeout(function() {
                $box.remove();
            }, 2000);
        },
    }

})(jQuery);

function isScrolledIntoView(elem)
{
    var $elem = $(elem);
    var $window = $(window);

    var docViewTop = $window.scrollTop();
    var docViewBottom = docViewTop + $window.height();

    var elemTop = $elem.offset().top;
    var elemBottom = elemTop + $elem.height();

    var ret = ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
    //if(ret == true) {
    //    console.log('docViewTop : ' + docViewTop + ', docViewBottom : ' + docViewBottom + ', elemTop : ' + elemTop + ', elemBottom : ' + elemBottom);
    //    console.log('result : ' + ((elemBottom <= docViewBottom) && (elemTop >= docViewTop)));
    //}
    return ret;
}



function getUrlVars()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

var agt = window.navigator.userAgent;
var isIE = agt.toLowerCase().indexOf("msie") != -1;

function onCheckbox(tbl_name, err_msg) {
    var type = 0;
    $(":checkbox", $("#" + tbl_name)).each(function(i, item) {
        if ($(item).is(":checked")) {
            type++;
        }
    });
    if (type === 0) {
        alert(err_msg);
        return false;
    }
    return true;
}



function doCheckedCheckbox(tbl_name) {
    var tbl = $("#" + tbl_name);
    var allCnt = $(":checkbox", tbl).length;
    var checkedCnt = $(":checkbox", tbl).filter(":checked").length;
    if (allCnt == checkedCnt) {
        $(":checkbox", tbl).removeAttr("checked");
    } else {
        $(":checkbox", tbl).attr("checked", "");
    }
    $(":checkbox", tbl).trigger("change");
}

function makeSingleLineString(string, pixels) {
    var strLength = string.length;
    if (strLength * 10 > pixels) {
        string = string.substr(0, pixels / 10) + "...";
    }
    return string;
}

function makeRemainedTimePart(divObject) {
    var endTimeVal = $(divObject).children("input").val();
    var currentTime = new Date().getTime();
    var endTime = new Date(endTimeVal).getTime();
    var timeInterval = parseInt((endTime / 1000) - (currentTime / 1000));
    var intervalObj = setInterval(function() {
        if (timeInterval >= 0) {
            var innerHtml = '';
            var dayCnt = parseInt(timeInterval / (3600 * 24));
            var hourCnt = parseInt((timeInterval % (3600 * 24)) / 3600);
            var minuteCnt = parseInt(((timeInterval % (3600 * 24)) % 3600) / 60);
            var secondCnt = timeInterval % 60;
            //var secondCnt = parseInt(((timeInterval % (3600 * 24)) % 3600) % 60);
            if (dayCnt > 0) {
                innerHtml += '<label class="btn yj-remained-time">' + dayCnt + '日</label>';
                innerHtml += '<label style="color: #ef641c">:</label>';
                innerHtml += '<label class="btn yj-remained-time">' + hourCnt + '时</label>';
            } else {
                innerHtml += '<label class="btn yj-remained-time">' + hourCnt + '时</label>';
                innerHtml += '<label style="color: #ef641c">:</label>';
                innerHtml += '<label class="btn yj-remained-time">' + minuteCnt + '分</label>';
                innerHtml += '<label style="color: #ef641c">:</label>';
                innerHtml += '<label class="btn yj-remained-time">' + secondCnt + '秒</label>';
            }
            $(divObject).children().remove();
            $(divObject).append(innerHtml);
        } else {
            clearInterval(intervalObj);
        }
        timeInterval--;
    }, 1000);
}

function refresh_cart_price() {
    $.post('/index.php/home/service/GetCartPrice', {}, function(resp) {
        // Success
        console.log(resp);
        if (resp.retCode == 200) {
            if (resp.price.length > 0) {
                $('#carNum').text('￥' + resp.price);
            } else {
                $('#carNum').text('');
            }
        }
    });
}

function date_format(date, format) {
    var pad = function(n, l) {
        for (n = String(n), l -= n.length; --l >= 0; n = '0' + n);
        return n;
    };
    var tz = function(n, s) {
        return ((n < 0) ? '+' : '-') + pad(Math.abs(n / 60), 2) + s + pad(Math.abs(n % 60), 2);
    };
    return format.replace(/([DdFHhKkMmSsyZ])\1*|'[^']*'|"[^"]*"/g, function(m) {
        l = m.length;
        switch (m.charAt(0)) {
            case 'D':
                return pad(date.getDayOfYear(), l);
            case 'd':
                return pad(date.getDate(), l);
            case 'F':
                return pad(date.getDayOfWeek(i18n), l);
            case 'H':
                return pad(date.getHours(), l);
            case 'h':
                return pad(date.getHours() % 12 || 12, l);
            case 'K':
                return pad(date.getHours() % 12, l);
            case 'k':
                return pad(date.getHours() || 24, l);
            case 'M':
                return pad(date.getMonth() + 1, l);
            case 'm':
                return pad(date.getMinutes(), l);
            case 'S':
                return pad(date.getMilliseconds(), l);
            case 's':
                return pad(date.getSeconds(), l);
            case 'y':
                return (l == 2) ? String(date.getFullYear()).substr(2) : pad(date.getFullYear(), l);
            case 'Z':
                return tz(date.getTimezoneOffset(), ' ');
            case 'w':
                return getWeekString(date.getDay());
            case "'":
            case '"':
                return m.substr(1, l - 2);
            default:
                throw new Error('Illegal pattern');
        }
    });
}

function getWeekString(index) {
    switch (index) {
        case 0:
            return '星期日';
        case 1:
            return '星期一';
        case 2:
            return '星期二';
        case 3:
            return '星期三';
        case 4:
            return '星期四';
        case 5:
            return '星期五';
        case 6:
            return '星期六';
    }
}