/******************************************
 *
 * string.js
 *
 * Yanjiao online (Shuiguo)
 *
 ******************************************/

// require jquery-1.11.3.min.js
// require bootstrap.min.js
// require jssor.slider.mini.js
// require bootstrap-notify.js

var theString = {
   
    /*
     * Trim
     */ 
    trim: function(value)
    {  
        return value.replace(/^\s+|\s+$/g, "");
    },
}
