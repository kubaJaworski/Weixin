<?php if (!defined('THINK_PATH')) exit();?>
<script>
    function onWxMenuTypeSelected(vOption, vKeyword, vUrl, vApp )
    {
        var ctrlKeyword = '#' + vKeyword;
        var ctrlUrl  = '#' + vUrl;
        var ctrlApp  = '#' + vApp;
        
        if( vOption == 'CLICK')
        {
            $(ctrlKeyword).show();
            $(ctrlUrl).hide();
            $(ctrlApp).hide();
        }
        else if( vOption == 'APP')
        {
            $(ctrlKeyword).hide();
            $(ctrlUrl).hide();
            $(ctrlApp).show();
        }
        else
        {
            $(ctrlKeyword).hide();
            $(ctrlUrl).show();
            $(ctrlApp).hide();
        }
    }
    
    function setWxMenu()
    {
        var types = new Array();
	types[0] = $('#type1_0').val();
	types[1] = $('#type1_1').val();
	types[2] = $('#type1_2').val();
        types[3] = $('#type1_3').val();
        types[4] = $('#type1_4').val();
        types[5] = $('#type1_5').val();
        
        types[6] = $('#type2_0').val();
	types[7] = $('#type2_1').val();
	types[8] = $('#type2_2').val();
        types[9] = $('#type2_3').val();
        types[10] = $('#type2_4').val();
        types[11] = $('#type2_5').val();
        
        types[12] = $('#type3_0').val();
        types[13] = $('#type3_1').val();
        types[14] = $('#type3_2').val();
        types[15] = $('#type3_3').val();
        types[16] = $('#type3_4').val();
        types[17] = $('#type3_5').val();
        
        var keywords = new Array();
	keywords[0] = $('#keyword1_0').val();
	keywords[1] = $('#keyword1_1').val();
	keywords[2] = $('#keyword1_2').val();
        keywords[3] = $('#keyword1_3').val();
        keywords[4] = $('#keyword1_4').val();
        keywords[5] = $('#keyword1_5').val();
        
        keywords[6] = $('#keyword2_0').val();
	keywords[7] = $('#keyword2_1').val();
	keywords[8] = $('#keyword2_2').val();
        keywords[9] = $('#keyword2_3').val();
        keywords[10] = $('#keyword2_4').val();
        keywords[11] = $('#keyword2_5').val();
        
        keywords[12] = $('#keyword3_0').val();
        keywords[13] = $('#keyword3_1').val();
        keywords[14] = $('#keyword3_2').val();
        keywords[15] = $('#keyword3_3').val();
        keywords[16] = $('#keyword3_4').val();
        keywords[17] = $('#keyword3_5').val();

	var urls = new Array();
	urls[0] = $('#url1_0').val();
	urls[1] = $('#url1_1').val();
	urls[2] = $('#url1_2').val();
        urls[3] = $('#url1_3').val();
        urls[4] = $('#url1_4').val();
        urls[5] = $('#url1_5').val();
        
        urls[6] = $('#url2_0').val();
	urls[7] = $('#url2_1').val();
	urls[8] = $('#url2_2').val();
        urls[9] = $('#url2_3').val();
        urls[10] = $('#url2_4').val();
        urls[11] = $('#url2_5').val();
        
        urls[12] = $('#url3_0').val();
        urls[13] = $('#url3_1').val();
        urls[14] = $('#url3_2').val();
        urls[15] = $('#url3_3').val();
        urls[16] = $('#url3_4').val();
        urls[17] = $('#url3_5').val();
        
        var names = new Array();
	names[0] = $('#name1_0').val();
	names[1] = $('#name1_1').val();
	names[2] = $('#name1_2').val();
        names[3] = $('#name1_3').val();
        names[4] = $('#name1_4').val();
        names[5] = $('#name1_5').val();
        
        names[6] = $('#name2_0').val();
	names[7] = $('#name2_1').val();
	names[8] = $('#name2_2').val();
        names[9] = $('#name2_3').val();
        names[10] = $('#name2_4').val();
        names[11] = $('#name2_5').val();
        
        names[12] = $('#name3_0').val();
        names[13] = $('#name3_1').val();
        names[14] = $('#name3_2').val();
        names[15] = $('#name3_3').val();
        names[16] = $('#name3_4').val();
        names[17] = $('#name3_5').val();
        
        var apps = new Array();
	apps[0] = $('#app1_0').val();
	apps[1] = $('#app1_1').val();
	apps[2] = $('#app1_2').val();
        apps[3] = $('#app1_3').val();
        apps[4] = $('#app1_4').val();
        apps[5] = $('#app1_5').val();
        
        apps[6] = $('#app2_0').val();
	apps[7] = $('#app2_1').val();
	apps[8] = $('#app2_2').val();
        apps[9] = $('#app2_3').val();
        apps[10] = $('#app2_4').val();
        apps[11] = $('#app2_5').val();
        
        apps[12] = $('#app3_0').val();
        apps[13] = $('#app3_1').val();
        apps[14] = $('#app3_2').val();
        apps[15] = $('#app3_3').val();
        apps[16] = $('#app3_4').val();
        apps[17] = $('#app3_5').val();
        
        var jsonObj = new Object() ; 
        jsonObj['types'] = types; 
        jsonObj['keywords'] = keywords; 
        jsonObj['urls'] = urls; 
        jsonObj['names'] = names; 
        jsonObj['apps'] = apps; 

        $.messager.progress({text:'处理中，请稍候...'});
        $.post('<?php echo U('Weixin/wxMenu');?>', jsonObj, function(res){
            $.messager.progress('close');            
            if(!res.status){
                $.app.method.tip('提示信息', res.info, 'error');
            }else{
                $.app.method.tip('提示信息', res.info, 'info');
            }
        }, 'json');
    }
</script>

<div class="easyui-panel" data-options="fit:true,title:'自定义菜单',border:false,onResize:function(){$('#wxmenu').portal({border:false,fit:true});}">
	<div id='wxmenu'>
		<div style="width:100%">

                    <div title="第一菜单" collapsible="true" style="padding:8px;line-height:1.8;" align="center">
				<table>
					<thead>
						<tr>
                                                    <th>级别</th>
                                                    <th>类型</th>
                                                    <th>名称</th>
                                                    <th>关键字及域名</th>
						</tr>
					<thead>
					<tbody>
                                            <?php if(is_array($wxmenu1)): foreach($wxmenu1 as $index=>$item): ?><tr>
                                                    <td><?php echo ($item['label']); ?></td>
                                                    <td>
                                                        <select id="type1_<?php echo ($index); ?>" name="type1[<?php echo ($index); ?>]" onchange="onWxMenuTypeSelected(this.value, 'keyword1_<?php echo ($index); ?>', 'url1_<?php echo ($index); ?>', 'app1_<?php echo ($index); ?>' );" >
                                                            <option value='NONE' <?php if(($item['type']) == "NONE"): ?>selected<?php endif; ?>>未设定</option>
                                                            <option value='CLICK' <?php if(($item['type']) == "CLICK"): ?>selected<?php endif; ?>>Click</option>
                                                            <option value='VIEW' <?php if(($item['type']) == "VIEW"): ?>selected<?php endif; ?>>View</option> 
                                                            <option value='APP' <?php if(($item['type']) == "APP"): ?>selected<?php endif; ?>>App</option>
                                                        </select>
                                                    </td>
                                                    <td><input id="name1_<?php echo ($index); ?>" name="menuname1[<?php echo ($index); ?>]" value="<?php echo ($item['name']); ?>" style="width:150px"></input></td>
                                                    <td>
                                                        <?php if( $item['type'] == 'CLICK' ) { ?>    
                                                            <input id="keyword1_<?php echo ($index); ?>" name='keyword1[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style="width:150px"></input>
                                                            <input id="url1_<?php echo ($index); ?>" name="url1[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style='display:none;width:150px'></input>
                                                            <select id="app1_<?php echo ($index); ?>" name="app1[<$index>]" style="display:none;width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$item): ?><option value="<?php echo ($item['id']); ?>"><?php echo ($item['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } else if( $item['type'] == 'APP' ) { ?> 
                                                            <input id="keyword1_<?php echo ($index); ?>" name='keyword1[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style='display:none;width:150px'></input>
                                                            <input id="url1_<?php echo ($index); ?>" name="url1[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style='display:none;width:150px'></input>
                                                            <select id="app1_<?php echo ($index); ?>" name="app1[<$index>]" style="width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$appitem): ?><option value="<?php echo ($appitem['id']); ?>" <?php if( $item['app'] == $appitem['id']) echo 'selected'; ?> ><?php echo ($appitem['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } else { ?>
                                                            <input id="keyword1_<?php echo ($index); ?>" name='keyword1[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style='display:none;width:150px'></input>
                                                            <input id="url1_<?php echo ($index); ?>" name="url1[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>"  style="width:150px"></input>
                                                            <select id="app1_<?php echo ($index); ?>" name="app1[<$index>]" style="display:none;width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$item): ?><option value="<?php echo ($item['id']); ?>"><?php echo ($item['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } ?>
                                                    </td>                                                    
						</tr><?php endforeach; endif; ?>                                                
					</tbody>
				</table>                
                        </div>
		

			<div title="第二菜单" collapsible="true" style="padding:8px;line-height:1.8;" align="center">
				<table title="第二菜单" >
					<thead>
						<tr>
							<th>级别</th>
							<th>类型</th>
							<th>名称</th>
							<th>关键字及域名</th>
						</tr>
					<thead>
					<tbody>
                                            <?php if(is_array($wxmenu2)): foreach($wxmenu2 as $index=>$item): ?><tr>
                                                    <td><?php echo ($item['label']); ?></td>
                                                    <td>
                                                        <select id="type2_<?php echo ($index); ?>" name="type2[<?php echo ($index); ?>]" onchange="onWxMenuTypeSelected(this.value, 'keyword2_<?php echo ($index); ?>', 'url2_<?php echo ($index); ?>', 'app2_<?php echo ($index); ?>');" >
                                                            <option value='NONE' <?php if(($item['type']) == "NONE"): ?>selected<?php endif; ?>>未设定</option>
                                                            <option value='CLICK' <?php if(($item['type']) == "CLICK"): ?>selected<?php endif; ?>>Click</option>
                                                            <option value='VIEW' <?php if(($item['type']) == "VIEW"): ?>selected<?php endif; ?>>View</option>
                                                            <option value='APP' <?php if(($item['type']) == "APP"): ?>selected<?php endif; ?>>App</option>
                                                        </select>
                                                    </td>
                                                    <td><input id="name2_<?php echo ($index); ?>" name="menuname2[<?php echo ($index); ?>]" value="<?php echo ($item['name']); ?>" style="width:150px"></input></td>
                                                    <td>
                                                        <?php if( $item['type'] == 'CLICK' ) { ?>    
                                                            <input id="keyword2_<?php echo ($index); ?>" name='keyword2[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style="width:150px"></input>
                                                            <input id="url2_<?php echo ($index); ?>" name="url2[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style='display:none;width:150px'></input>
                                                            <select id="app2_<?php echo ($index); ?>" name="app2[<$index>]" style="display:none;width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$item): ?><option value="<?php echo ($item['id']); ?>"><?php echo ($item['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } else if( $item['type'] == 'APP' ) { ?>        
                                                            <input id="keyword2_<?php echo ($index); ?>" name='keyword2[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style='display:none;width:150px'></input>
                                                            <input id="url2_<?php echo ($index); ?>" name="url2[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style="display:none;width:150px"></input>
                                                            <select id="app2_<?php echo ($index); ?>" name="app2[<$index>]" style="width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$appitem): ?><option value="<?php echo ($appitem['id']); ?>" <?php if( $item['app'] == $appitem['id']) echo 'selected'; ?> ><?php echo ($appitem['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } else { ?>        
                                                            <input id="keyword2_<?php echo ($index); ?>" name='keyword2[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style='display:none;width:150px'></input>
                                                            <input id="url2_<?php echo ($index); ?>" name="url2[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style="width:150px"></input>
                                                            <select id="app2_<?php echo ($index); ?>" name="app2[<$index>]" style="display:none;width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$item): ?><option value="<?php echo ($item['id']); ?>"><?php echo ($item['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } ?>
                                                    </td>                                                    
						</tr><?php endforeach; endif; ?>
					</tbody>
				</table>                
                        </div>
	
			<div title="第三菜单" collapsible="true" style="padding:8px;line-height:1.8;" align="center">
				<table title="第三菜单" >
					<thead>
						<tr>
							<th>级别</th>
							<th>类型</th>
							<th>名称</th>
							<th>关键字及域名</th>
						</tr>
					<thead>
					<tbody>
                                            <?php if(is_array($wxmenu3)): foreach($wxmenu3 as $index=>$item): ?><tr>
                                                    <td><?php echo ($item['label']); ?></td>
                                                    <td>
                                                        <select id="type3_<?php echo ($index); ?>" name="type3[<?php echo ($index); ?>]" onchange="onWxMenuTypeSelected(this.value, 'keyword3_<?php echo ($index); ?>', 'url3_<?php echo ($index); ?>', 'app3_<?php echo ($index); ?>');" >
                                                            <option value='NONE' <?php if(($item['type']) == "NONE"): ?>selected<?php endif; ?>>未设定</option>
                                                            <option value='CLICK' <?php if(($item['type']) == "CLICK"): ?>selected<?php endif; ?>>Click</option>
                                                            <option value='VIEW' <?php if(($item['type']) == "VIEW"): ?>selected<?php endif; ?>>View</option>
                                                            <option value='APP' <?php if(($item['type']) == "APP"): ?>selected<?php endif; ?>>App</option>
                                                        </select>
                                                    </td>
                                                    <td><input id="name3_<?php echo ($index); ?>" name="menuname3[<?php echo ($index); ?>]" value="<?php echo ($item['name']); ?>" style="width:150px"></input></td>
                                                    <td>
                                                        <?php if( $item['type'] == 'CLICK' ) { ?>    
                                                            <input id="keyword3_<?php echo ($index); ?>" name='keyword3[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style="width:150px"></input>
                                                            <input id="url3_<?php echo ($index); ?>" name="url3[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style='display:none;width:150px'></input>
                                                            <select id="app3_<?php echo ($index); ?>" name="app3[<$index>]" style="display:none;width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$item): ?><option value="<?php echo ($item['id']); ?>"><?php echo ($item['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } else if( $item['type'] == 'APP' ) { ?>        
                                                            <input id="keyword3_<?php echo ($index); ?>" name='keyword3[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style='display:none;width:150px'></input>
                                                            <input id="url3_<?php echo ($index); ?>" name="url3[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style="display:none;width:150px"></input>
                                                            <select id="app3_<?php echo ($index); ?>" name="app3[<$index>]" style="width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$appitem): ?><option value="<?php echo ($appitem['id']); ?>" <?php if( $item['app'] == $appitem['id']) echo 'selected'; ?> ><?php echo ($appitem['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } else { ?>        
                                                            <input id="keyword3_<?php echo ($index); ?>" name='keyword3[<?php echo ($index); ?>]' value="<?php echo ($item['keyword']); ?>" style='display:none;width:150px'></input>
                                                            <input id="url3_<?php echo ($index); ?>" name="url3[<?php echo ($index); ?>]" value="<?php echo ($item['url']); ?>" style="width:150px"></input>
                                                            <select id="app3_<?php echo ($index); ?>" name="app3[<$index>]" style="display:none;width:150px">
                                                                <?php if(is_array($applist)): foreach($applist as $index=>$item): ?><option value="<?php echo ($item['id']); ?>"><?php echo ($item['funcname']); ?></option><?php endforeach; endif; ?>
                                                            </select>
                                                        <?php } ?>
                                                    </td>                                                    
						</tr><?php endforeach; endif; ?>
					</tbody>
				</table>
			</div>

			<div  style="padding:8px;border:0px" align="center">
                            <button class="easyui-linkbutton" onclick="setWxMenu();" >自定义菜单 生成</button>
			</div>

		</div>
	</div>
</div>