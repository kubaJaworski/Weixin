<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="author" content="centiz">
<title><?php echo C('SYSTEM_NAME');?></title>
<link rel='shortcut icon' href='/Public/static/favicon.ico' />
<script type="text/javascript">var STATIC_URL = '/Public/static',UPLOAD_ROOT = '/Public/upload/';</script>
<script type="text/javascript" src="/Public/static/js/jquery.min.js"></script>
<script type="text/javascript" src="/Public/static/js/jquery.cookie.js"></script>
<script type="text/javascript" src="/Public/static/js/jquery.json.min.js"></script>
<script type="text/javascript" src="/Public/static/js/easyui/jquery.easyui.min.js"></script>
<script type="text/javascript" src="/Public/static/js/easyui/locale/easyui-lang-zh_CN.js"></script>
<script type="text/javascript" src="/Public/static/js/easyui/plugins/jquery.portal.js"></script>
<link rel="stylesheet" href="/Public/static/js/croppic/croppic.css"/>
<script type="text/javascript" src="/Public/static/js/croppic/croppic.min.js"></script>
<script type="text/javascript" src="/Public/static/js/jquery.app.js"></script>
<!--inserted by chui 2015.07.10 begin -->
<script type="text/javascript" src="/Public/static/js/custom.js"></script>
<!--inserted by chui 2015.07.10 end -->
<script type="text/javascript" src="/Public/static/js/highcharts.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/static/css/icons.css" />
<link rel="stylesheet" type="text/css" href="/Public/static/js/easyui/themes/default/easyui.css" title="default" />
<link rel="stylesheet" type="text/css" href="/Public/static/js/easyui/themes/gray/easyui.css" title="gray" />
<link rel="stylesheet" type="text/css" href="/Public/static/js/easyui/themes/bootstrap/easyui.css" title="bootstrap" />
<link rel="stylesheet" type="text/css" href="/Public/static/js/easyui/themes/metro/easyui.css" title="metro" />
<link rel="stylesheet" type="text/css" href="/Public/static/css/admin/default.css" title="default" />
<link rel="stylesheet" type="text/css" href="/Public/static/css/admin/gray.css" title="gray" />
<link rel="stylesheet" type="text/css" href="/Public/static/css/admin/bootstrap.css" title="bootstrap" />
<link rel="stylesheet" type="text/css" href="/Public/static/css/admin/metro.css" title="metro" />
<link rel="stylesheet" type="text/css" href="/Public/static/css/font-awesome.min.css"/>
<script type="text/javascript">
var theme = $.cookie('theme') || 'default'; //全局变量
$(document).ready(function(){
	$('link[rel*=style][title]').each(function(i){
		this.disabled = true;
		if (this.getAttribute('title') == theme) this.disabled = false;
	});
});
</script>
</head>
<body class="easyui-layout">

<!-- 头部 -->
<div id="toparea" data-options="region:'north',border:false,height:38">
	<div id="topmenu" class="easyui-panel" data-options="fit:true,border:false">
		<a class="logo"><?php echo C('SYSTEM_NAME');?></a>
		<ul class="nav">
			<?php if(is_array($menuList)): foreach($menuList as $key=>$menu): ?><li><a href="javascript:;" onclick="baseModule.getLeft(<?php echo ($menu["id"]); ?>,'<?php echo ($menu["name"]); ?>', this)"><?php echo ($menu["name"]); ?></a></li><?php endforeach; endif; ?>
		</ul>
		<ul class="nav-right">
                    <li>
                        <a href="javascript:;" class="easyui-splitbutton" data-options="menu:'#toparea-user-info-box',iconCls:'icons-user-user'"><?php echo ($userInfo["rolename"]); ?></a>
                        <a href="javascript:;" class="easyui-splitbutton" data-options="menu:'#toparea-help-box',iconCls:'icons-other-help'">帮助</a>
                        <div id="toparea-user-info-box">
                                <div><?php echo ($userInfo["username"]); ?></div>
                                <div class="menu-sep"></div>
                                <div onclick="baseModule.userinfo()">个人信息</div>
                                <div onclick="baseModule.password()">修改密码</div>
                                <div class="menu-sep"></div>
                                <div onclick="baseModule.logout()">退出登录</div>
                        </div>
                        <div id="toparea-help-box">										
                                <div onclick="baseModule.clearCache()">更新缓存</div>					
                                <div class="menu-sep"></div>
                                <div onclick="baseModule.systemInfo()">服务器信息</div>
                                <div onclick="$.messager.alert('关于', '版本号：<?php echo C('SYSTEM_VERSION');?><br /><br />联系QQ：3222563981', 'info');">关于</div>					
                        </div>
                    </li>
		</ul>
		<div style="clear:both;border-bottom:none;border-left:none;border-right:none"></div>
	</div>
</div>

<!-- 左侧菜单 -->
<div id="leftarea" data-options="iconCls:'icons-application-application_side_boxes',region:'west',title:'加载中...',split:true,width:220">
	<div id="leftmenu" class="easyui-accordion" data-options="fit:true,border:false"></div>
</div>

<!-- 内容 -->
<div id="mainarea" data-options="region:'center'">
	<div id="pagetabs" class="easyui-tabs" data-options="tabPosition:'bottom',fit:true,border:false,plain:false">
		<div title="后台首页" href="<?php echo U('Index/public_main');?>" data-options="cache:false"></div>
	</div>
</div>

<!-- 公共部分 -->
<div id="global-dialog-div" class="word-wrap" style="line-height:1.5"></div>
<div id="global-dialog2-div" class="word-wrap" style="line-height:1.5"></div> <!-- 特殊情况可能需要弹出第2个弹出层 -->

<div id ="alarmInfo" name="alarmInfo"></div>

<script type="text/javascript">
window.baseModule = {
	dialog:   '#global-dialog-div',
	
	//初始化
	init: function(){
		$('#topmenu > ul.nav > li:first > a:first').click(); //默认选中第一个菜单

		this.sessionLife();
		this.tip();
	},
	
	//登录默认提示
	tip: function(){
		$.messager.show({
			title:'登录提示',
			msg:'您好！<?php echo ($userInfo["username"]); ?> 欢迎回来！<br/>最后登录时间：<?php if($userInfo['lastlogintime']): echo (date('Y-m-d H:i:s',$userInfo["lastlogintime"])); else: ?>-<?php endif; ?><br/>最后登录IP：<?php echo ($userInfo["lastloginip"]); ?>',
			timeout:5000,
			showType:'slide'
		});	
	},
	
	//切换主题
	theme: function(that){
		var theme = that.getAttribute('theme');
		$('link[rel*=style][title]').each(function(i){
			this.disabled = true;
			if (this.getAttribute('title') == theme) this.disabled = false;
		});
		$('iframe').contents().find('link[rel*=style][title]').each(function(i){
			this.disabled = true;
			if (this.getAttribute('title') == theme) this.disabled = false;
		});
		$.cookie('theme', theme, {path:'/', expires:3650});
	},
	
	//移除左侧栏目  TODO 发现需要执行两次才能彻底清除
	removeLeft: function(stop, titles){
		var pp = $("#leftmenu").accordion("panels");
		$.each(pp, function(i, n) {
			if(n){
				var t = n.panel("options").title;
				if(titles && titles.length){
					for(var k = 0; k < titles.length; k++){
						if(titles[k] == t) $("#leftmenu").accordion("remove", t);
					}
				}else{
					$("#leftmenu").accordion("remove", t);
				}
			}
		});
		var pp = $('#leftmenu').accordion('getSelected');
		if(pp) {
			var t = pp.panel('options').title;
			if(titles && titles.length){
				for(var k = 0; k < titles.length; k++){
					if(titles[k] == t) $("#leftmenu").accordion("remove", t);
				}
			}else{
				$("#leftmenu").accordion("remove", t);
			}
		}
		if(!stop) this.removeLeft(true, titles);
	},
	
	//获取左侧栏目
	getLeft: function(menuid, title, object){
		var that = this;
		
		//加个判断，防止多次点击重复加载
		var options = $('body').layout('panel', 'west').panel('options');
		if(title == options.title) return false;
		
		//开始获取左侧栏目
		$.ajax({
			type: 'POST',
			url: '<?php echo U('Index/public_menuLeft');?>',
			data: {menuid: menuid},
			cache: false,
			beforeSend: function(){
				that.removeLeft();
				//更新标题名称
				$('body').layout('panel', 'west').panel({title: title});
				var loading = '<div class="panel-loading">Loading...</div>';
				$("#leftmenu").accordion("add", {content: loading});
			},
			success: function(data){
				that.removeLeft();
				//左侧内容更新
				$.each(data, function(i, menu) {
					var content = '';
					if(menu.son){
                                           	var treedata = $.toJSON(menu.son);
						content = '<ul class="easyui-tree" data-options=\'data:' + treedata + ',animate:true,lines:true,onClick:function(node){baseModule.openUrl(node.url, node.text)}\'></ul>';
					}
					$("#leftmenu").accordion("add", {title: menu.name, content: content, iconCls:'icons-application-application_side_list'});
				});
			}
		});
		//默认选中头部菜单
		if(object){
			$('#topmenu .nav li').each(function(){
				$(this).children().removeClass('focus');
			});
			$(object).addClass('focus');
		}

		//如果左侧隐藏则进行展开
		if($('body').layout('panel', 'west').panel("options").collapsed){
			$('body').layout('expand', 'west');
		}
	},
	
	//显示打开内容
	openUrl: function(url, title){	
		if($('#pagetabs').tabs('exists', title)){
                    $('#pagetabs').tabs('select', title);
		}else{
                    $('#pagetabs').tabs('add',{title: title, href: url, closable: true, cache: false});
		}
	},
	
	//更新缓存
	clearCache: function(){
		$.post('<?php echo U('Index/public_clearCatche');?>', function(data){
			var type = data.status ? 'info' : 'error';
			$.app.method.tip('提示信息', data.info, type);
		}, 'json');
	},
	
	//退出登录
	logout: function(){
		$.messager.confirm('提示信息', '确定要退出登录吗？', function(result){
			if(result) window.location.href = '<?php echo U('Index/logout');?>';
		});
	},

	//服务器信息
	systemInfo: function(type){
		var that = this;
		$(that.dialog).dialog({
			title: '服务器信息',
			iconCls: 'icons-application-application_view_detail',
			width: 550,
			height: 400,
			cache: false,
			href: '<?php echo U('Index/systemInfo');?>',
			modal: true,
			collapsible: false,
			minimizable: false,
			resizable: true,
			maximizable: true,
			buttons:[{
				text: '关闭',
				iconCls: 'icons-arrow-cross',
				handler: function(){
					$(that.dialog).dialog('close');
				}
			}]
		});
	},
	
	//防止登录超时
	sessionLife: function(){
		setInterval(function(){
			$.post('<?php echo U('Index/public_sessionLife');?>', function(data){
				if(!data.status){
					$.messager.show({
						title: '系统提示',
						msg: data.info,
						timeout:3000,
						showType:'slide'
					});
					setTimeout(function(){
						window.location.href = data.url;
					}, 3000);
				}
			}, 'json');
		}, 15000);
	},
	
	//个人信息
	userinfo: function(){
		var that = this;
		$(that.dialog).dialog({
			title: '个人信息',
			iconCls: 'icons-application-application_form_edit',
			width: 360,
			height: 270,
			cache: false,
			href: '<?php echo U('Admin/public_editInfo');?>',
			modal: true,
			collapsible: false,
			minimizable: false,
			resizable: false,
			maximizable: false,
			buttons:[{
				text: '确定',
				iconCls: 'icons-other-tick',
				handler: function(){
					$(that.dialog).find('form').eq(0).form('submit', {
						onSubmit: function(){
							var isValid = $(this).form('validate');
							if (!isValid) return false;
							
							$.messager.progress({text:'处理中，请稍候...'});
							$.post('<?php echo U('Admin/public_editInfo?dosubmit=1');?>', $(this).serialize(), function(res){
								$.messager.progress('close');
								if(!res.status){
									$.app.method.tip('提示信息', res.info, 'error');
								}else{
									$.app.method.tip('提示信息', res.info, 'info');
									$('#global-dialog-div').dialog('close');
								}
							}, 'json');
							
							return false;
						}
					});
				}
			},{
				text: '取消',
				iconCls: 'icons-arrow-cross',
				handler: function(){
					$(that.dialog).dialog('close');
				}
			}]
		});
	},

	
	
	//修改密码
	password: function(){
		var that = this;
		$(that.dialog).dialog({
			title: '修改密码',
			iconCls: 'icons-application-application_form_edit',
			width: 360,
			height: 270,
			cache: false,
			href: '<?php echo U('Admin/public_editPwd');?>',
			modal: true,
			collapsible: false,
			minimizable: false,
			resizable: false,
			maximizable: false,
			buttons:[{
				text: '确定',
				iconCls: 'icons-other-tick',
				handler: function(){
					$(that.dialog).find('form').eq(0).form('submit', {
						onSubmit: function(){
							var isValid = $(this).form('validate');
							if (!isValid) return false;
							
							$.messager.progress({text:'处理中，请稍候...'});
							$.post('<?php echo U('Admin/public_editPwd?dosubmit=1');?>', $(this).serialize(), function(res){
								$.messager.progress('close');
								if(!res.status){
									$.app.method.tip('提示信息', res.info, 'error');
								}else{
									$.messager.confirm('提示信息', res.info, function(result){
										if(result) window.location.href = res.url;
									});
								}
							}, 'json');
							
							return false;
						}
					});
				}
			},{
				text: '取消',
				iconCls: 'icons-arrow-cross',
				handler: function(){
					$(that.dialog).dialog('close');
				}
			}]
		});
	}
};

var agt =   window.navigator.userAgent;
var isIE = agt.toLowerCase().indexOf("msie") != -1;
var ieVer = isIE ? parseInt(agt.split(";")[1].replace(/(^\s*)|(\s*$)/g,"").split(" ")[1]) : 0;

function playWithAudio(alarmName){    
  if (isIE) {
    $('#alarmInfo').html('\
            <audio autoplay="autoplay"> <source src="' + alarmName + '.mp3"" type="audio/mp3"> </audio>');
  } else {
    $('#alarmInfo').html('\
            <audio autoplay="autoplay"> <source src="' + alarmName + '.wav"" type="audio/wav"> </audio>');
  }
} 

function playWithEmbed(alarmName){
    $('#alarmInfo').html('<object type="audio/mpeg" width="0" height="0">'+
                          '<param name="Filename" value="'+ alarmName +'.mp3" />'+
                          '<param name="AutoStart" value="1" />'+ '</object>');
}

function playAlarm(alarmName){    
    if ( isIE ) {      
      if (ieVer <= 8 ) {
        playWithEmbed(alarmName);
      } else {
        playWithAudio(alarmName);
      }
    } else {  //Firefox or Chrome, ...
      playWithAudio(alarmName);
    }
}

function checkorder(){
	var roleid = '<?php echo ($userInfo["roleid"]); ?>';
	var uid = '<?php echo ($userInfo["userid"]); ?>';
	//alert(uid);
	var url ="<?php echo U('Index/checkorder');?>";
	var data = {'roleid' : roleid, 'uid' : uid};
	$.post(url,data, function(mes){
		var mes = JSON.parse(mes);
		if(mes.order == 0 && mes.processing == 0 && mes.returnreq ==0 ){

		}else{
                    $.messager.show({
			title:'登录提示',
			height: '200',
			msg:'您好！目前您有<p style="font-size:14px;"><span style ="color:red;">'+mes.order+'</span>条未处理订单！</p><p style="font-size:14px;"><span style ="color:red">'+mes.processing+'</span>条完成订单！</p><p style="font-size:14px;"><span style ="color:red">'+mes.returnreq+'</span>条退货订单！</p>请尽快处理！',
			timeout:5000,
			showType:'slide'
                    });
		};	
	});
}

function checkneworder(){
	var roleid = '<?php echo ($userInfo["roleid"]); ?>';
	var uid = '<?php echo ($userInfo["userid"]); ?>';
	//alert(uid);
	var url ="<?php echo U('Index/checkneworder');?>";
	var data = {'roleid' : roleid, 'uid' : uid};
	$.post(url,data, function(mes){
		var mes = JSON.parse(mes);
		if(mes.order == 0){

		}else{
                    playAlarm('<?php echo ($rooturl); ?>/Public/alarm/neworder');
                    var messaging = '新订单出来了';
                    if (mes.payed != 0) {
                        messaging = messaging+'<p style="font-size:14px;">* 已支付(<span style ="color:red;">'+mes.payed+'</span>个订单)</p>'
                    }
                    if (mes.pay_later != 0) {
                        messaging = messaging+'<p style="font-size:14px;">* 货到付款(<span style ="color:red;">'+mes.pay_later+'</span>个订单)</p>'
                    }
                    if (mes.processing != 0) {
                        messaging = messaging+'<p style="font-size:14px;">* 处理中(<span style ="color:red;">'+mes.processing+'</span>个订单)</p>'
                    }
                    if (mes.shipping != 0) {
                        messaging = messaging+'<p style="font-size:14px;">* 配送中(<span style ="color:red;">'+mes.shipping+'</span>个订单)</p>'
                    }
                    if (mes.ready != 0) {
                        messaging = messaging+'<p style="font-size:14px;">* 未支付(<span style ="color:red;">'+mes.ready+'</span>个订单)</p>'
                    }
                    $.messager.show({
			title:'登录提示',
			height: '100',
			msg: messaging,
			timeout:1000,
			showType:'slide'                        
                    });
		};	
	});
}

$(function(){
	baseModule.init();
	setInterval(checkorder,   600000);
        setInterval(checkneworder,300000);
});
</script>
</body>
</html>