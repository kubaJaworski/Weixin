<?php if (!defined('THINK_PATH')) exit();?>
<script>
    

        function copyText(inputTag)
        {
            var Url2=document.getElementById(inputTag);
            Url2.select(); // 选择对象
            document.execCommand("Copy"); // 执行浏览器复制命令
            alert("已复制好，可贴粘。");
        }

        function panel_set_weixin_reload()
        {
            $.messager.progress({text:'处理中，请稍候...'});
            $.post('<?php echo U('Weixin/wxConnect');?>', {}, function(res){
                $.messager.progress('close');                
               
                $('#wx_app_id').val(res.wx_app_id);                
                $('#wx_app_secret').val( res.wx_app_secret );
                $('#wx_app_token').val( res.wx_app_token );
                $('#wx_app_encoding_key').val( res.wx_app_encoding_key );
                $('#wx_app_mchid').val( res.wx_app_mchid );
                $('#wx_app_paysignkey').val( res.wx_app_paysignkey );
                
            }, 'json');
        }
        
        function Set_Weixin()
	{
            var jsonObj = new Object() ;             
            jsonObj['wx_app_id'] = $('#wx_app_id').val(); 
            jsonObj['wx_app_secret'] = $('#wx_app_secret').val(); 
            jsonObj['wx_app_token'] = $('#wx_app_token').val(); 
            jsonObj['wx_app_encoding_key'] = $('#wx_app_encoding_key').val();             
            jsonObj['wx_app_mchid'] = $('#wx_app_mchid').val(); 
            jsonObj['wx_app_paysignkey'] = $('#wx_app_paysignkey').val(); 
            
            
            $.messager.progress({text:'处理中，请稍候...'});
            $.post('<?php echo U('Weixin/wxConnectSet');?>', {data: jsonObj}, function(res){
                   $.messager.progress('close');
			
                   if(!res.status){
                       $.app.method.tip('提示信息', res.info, 'error');
		   }else{
                       $.app.method.tip('提示信息', res.info, 'info');
		   }
                   panel_set_weixin_reload();
            }, 'json');
	}
        
</script>


<div class="easyui-panel" data-options="fit:true,title:'<?php echo ($title); ?>',border:false,onResize:function(){$('#panel_set_weixin').portal({border:false,fit:true});}">
    <div id="panel_set_weixin">
        <div style="width:100%">
            <div title="微信设置" collapsible="true" style="padding:8px;line-height:1.8;" align="center">
                <table>
                    <tr>
                        <td style="width:220px;vertical-align:middle">微信公众号 (App Id)：</td>
                        <td style="vertical-align:top"><input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,255]']" id="wx_app_id" name="wx_app_id" value="<?php echo ($wx_app_id); ?>"></input></td>
                    </tr>
                    <tr>
                        <td style="width:220px;vertical-align:middle">微信公众号 (App Secret)：</td>
                        <td style="vertical-align:top"><input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,255]']" id="wx_app_secret" name="wx_app_secret" value="<?php echo ($wx_app_secret); ?>"></input></td>
                    </tr>
                    <tr>
                        <td style="width:220px;vertical-align:middle">服务器接口 (URL)：</td>
                        <td style="vertical-align:top">
                            <input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,255]']" id="wx_app_url" name="wx_app_url" value="<?php echo ($wx_app_url); ?>"></input>
                            <button class="easyui-linkbutton" style="width:60px" onclick="copyText('wx_app_url');">复制</button>
                        </td>
                    </tr>
                    <tr>
                        <td style="width:220px;vertical-align:middle">令牌 (Token)：</td>
                        <td style="vertical-align:top">
                            <input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,255]']" id="wx_app_token" name="wx_app_token" value="<?php echo ($wx_app_token); ?>"></input>
			</td>
                    </tr>
                    <tr>
                        <td style="width:220px;vertical-align:middle">消息加解密密钥 (EncodingAESKey)：</td>
                        <td style="vertical-align:top">
                            <input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,255]']" id="wx_app_encoding_key" name="wx_app_encoding_key"  value="<?php echo ($wx_app_encoding_key); ?>"></input>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="height:20px;vertical-align:middle"></td>
                    </tr>   
                    <tr>
                        <td style="width:220px;vertical-align:middle">微信支付商户号(Mch Id)：</td>
                        <td style="vertical-align:top">
                            <input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,255]']" id="wx_app_mchid" name="wx_app_mchid"  value="<?php echo ($wx_app_mchid); ?>"></input>
                        </td>
                    </tr>                    
                    <tr>
                        <td style="width:220px;vertical-align:middle">通信密钥/商户支付密钥 (paySignKey/api密钥)：</td>
                        <td style="vertical-align:top">
                            <input type="text" class="easyui-validatebox textbox" style="width:350px" data-options="required:true,validType:['length[8,50]']" id="wx_app_paysignkey" name="wx_app_paysignkey"  value="<?php echo ($wx_app_paysignkey); ?>"></input>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align:center;">
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align:center;">
                            <button class="easyui-linkbutton" style="width:120px" onclick="Set_Weixin();">设定</button>
                        </td>
                    </tr>
                </table>
            </div>	

	</div>		
    </div>

</div>