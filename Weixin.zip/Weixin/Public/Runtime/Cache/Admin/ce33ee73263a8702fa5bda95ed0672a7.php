<?php if (!defined('THINK_PATH')) exit();?><div class="easyui-panel" data-options="fit:true,title:'后台首页',border:false,onResize:function(){$('#index-main-portal').portal({border:false,fit:true});}">
	<div id="index-main-portal">
		<div style="width:100%">
			<div title="系统消息" collapsible="true" style="padding:8px;line-height:1.8;height: 132px;">
				您好，<?php echo ($userInfo["username"]); ?><br />
				所属角色：<?php echo ($userInfo["rolename"]); ?> <br />
				最后登录时间：<?php if($userInfo['lastlogintime'] > 0): echo (date('Y-m-d H:i:s',$userInfo["lastlogintime"])); endif; ?><br />
				最后登录IP：<?php echo ($userInfo["lastloginip"]); ?> <br />
			</div>

			
			<div title="系统说明" collapsible="true" style="padding:8px;line-height:1.8">
				版本号：<?php echo C('SYSTEM_VERSION');?> （联系QQ：1697465916）<br />
				兼容性：IE9、IE10、IE11、FireFox、Chrome、Safari等主流浏览器<br/>
			</div>
		</div>

</div>